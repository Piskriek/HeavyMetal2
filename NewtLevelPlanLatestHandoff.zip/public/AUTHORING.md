> **Start with [PLAN.md](/PLAN.md)** — the single cohesive plan. This document is the preset-authoring detail behind it.

# HeavyMetal2 — Everything is an editable preset

## The correction

The creator is not a model-placement tool with a material editor bolted on. The same graph describes a world, a tree, a leaf, a texture recipe, a goblin, and a goblin part. Traversal changes the **brush's target and meaning**, not merely camera distance.

## Working workflows

- **World:** grow a biome with the gel volume, carve terrain, draw rails.
- **Tree:** use Grow leaves or Grow wood to add structural elements from the linked child recipes. Paint, push, and pull act on the hit wood/leaf surface, not on the ground below it.
- **Wood:** edit a UV-mapped wood object, paint grain pigment, sculpt branch surfaces, or add shapes.
- **Leaf:** a curved, subdivided leaf mesh replaces the generic tiny-planet proxy. Paint its UV surface, push/pull real vertices, add sculptable shapes, or adjust length, width, curl, and edge serration.
- **Texture:** a procedural PBR recipe controls pigment, branching veins, thickness, contrast, seeded fractal noise, normal strength, roughness, and normal-map composition. Paint writes UV-space commands; push/pull relief also affects height and normal maps.
- **Goblin lab:** the former 2D portrait creator is replaced in this prototype by a 3D socketed assembly: head/face, ears, torso, arms/hands, legs/boots, and armor. Select a slot, attach/detach a part, choose classic/long/chunky shape variants, paint/sculpt the actual mesh, transform the socket using Translate/Rotate/Scale, then enter that part's material preset.

Use V to orbit; B to paint; J/U to push/pull; A to add a shape. Hold Alt to orbit while another brush is active. Right-click reverses push/pull. Ctrl/Cmd Z and Shift Z use the studio-wide undo stack.

## What is saved

WorldSnapshot.authoring contains flat EditablePreset documents keyed by graph node ID. Each document has a kind, revision, linked texture, procedural shape parameters, optional goblin slot, replayable SurfaceMark commands, and optional bounded local reference mesh.

SurfaceMark stores object-local position, face normal, UV coordinate, UV radius, falloff/strength, operation, color, and stable mesh target. Brush work is replayed, not converted into an uneditable screenshot. Geometry deformation and texture paint are separate operations. Pigment painting does not spawn objects.

The PBR generator computes base color, tangent-space normals, roughness, and height. Leaf veins and wood grain are algorithms; seeded noise is deterministic. A normal-source preset contributes its own primitive height module before derivatives are taken, so normals can be composed without copying someone else's color. Normal dependencies are graph-pinned and cycle-checked. Normal-source evaluation is deliberately one level deep in this prototype, not arbitrary executable shader recursion.

## Saving and returning to the parent

**Replace in this branch** creates a new revision and updates pinned references in the current working branch. An existing immutable library package is never overwritten. **Save as a new preset** gives the edited node a new identity, retains the original document, and connects the current parent to the new variant. Go up a preset to inspect the change in the leaf, tree, or goblin. Saving the world persists those links and the complete working graph.

POST /api/presets stores an immutable dependency-locked package in hm2_authoring_presets; GET /api/presets lists the current session's private packages and public community packages. A package contains its root, dependency closure, revision lockfile, authoring documents, and SHA-256 checksum. The prototype checksum covers the serialized package; production should use a versioned canonical serialization scheme for cross-client content addressing.

The preset library only applies compatible kinds and matching goblin slots. Applied packages are copied into a working branch with isolated dependency identities. Old world revisions and old library packages remain unchanged.

## Local Hunyuan3D / model references

Import a static, split, embedded GLB under 4 MB. External URLs, required compression extensions, rigged-only scenes, oversized accessor/node budgets, and invalid GLB manifests are rejected. The first static mesh is transformed into world space, sampled to at most 2,000 triangles, normalized, and stored with UVs and a SHA-256 provenance hash.

This is a bounded **reference/conversion** step, not a replacement for offline retopology. Triangle sampling is a preview budget reduction, not topology-preserving decimation. For production, split parts and retopologize locally before import. The imported material is intentionally replaced by the editable linked PBR recipe; source meshes become editable procedural-preset foundations rather than opaque dropped models.

Toggle procedural/local source without discarding the reference. Imported geometry participates in the same UV paint, sculpt, and revision workflow. Default goblin parts and botanical meshes are procedural placeholders; no Hunyuan3D service is contacted or run in the browser.

## Baking without losing editability

Bake PBR maps downloads a ZIP with 512×512 baseColor.png (sRGB), normal.png (+Y tangent normals), roughness.png and height.png (linear data maps), plus preset.hm2.json and a usage note. The recipe, source information, and brush commands stay in the package. For a multi-surface goblin the bake covers the selected part's primary surface; extra named surfaces remain in the editable package. Production asset export needs an atlas or a separate map set for every named mesh.

## Parent rendering and LOD

The object-level tree is generated directly from its linked wood/leaf recipes. The world-level forest keeps inexpensive instanced LOD geometry, updates its authored PBR maps, and includes a detailed representative tree. Leaf shape/structure edits are fully visible in the object-level parent; distant world silhouettes remain approximations. Customized goblin assemblies are also used as the actual rail-sphere pilots.

## Safety budgets

256 authoring documents/world; 320 surface marks/preset; 1,400 surface marks/world; at most 48 added shapes/object; 64 additional structural marks/tree; local reference payload bounded to 60,000 numeric values/world; 750 KB request limit; 200 immutable saved presets/workspace. No community source code is executed. All numeric recipe, brush, reference and transform payloads are validated server-side through Drizzle-backed APIs.

## Production next steps

Rigged bone/socket constraints and animation retargeting; real topology-preserving sculpt/remesh; atlas-aware painting and seam-safe multi-part map export; per-face authoring materials; GPU compute texture generation and tile caches; volume/SDF wood and branch growth; offline retopology and Hunyuan3D automation; authoritative multiplayer editing and collision reconstruction. These are not represented as already complete.
