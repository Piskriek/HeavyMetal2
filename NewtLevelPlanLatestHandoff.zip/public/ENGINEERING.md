> **Start with [PLAN.md](/PLAN.md)** — the single cohesive plan. This document is the architecture deep-dive behind it.

# HeavyMetal2 — Fractal World Engine
## Technical specification and runnable prototype

This is a self-contained Next.js App Router / PostgreSQL implementation in the provided workspace. The reference repository is https://github.com/Piskriek/HeavyMetal2 (main); the requested baseline is arena/01a0ecba-heavymetal2, c0a0ea4 / PR #62. The repository was reviewed for context, not modified remotely. The original game is a React/Vite Canvas 2D Goblin Rally game; this prototype establishes an independent Three.js world-studio surface and reusable engine contracts. It is not a claim that a patch was applied to the remote branch.

## Authoring update — v0.3

The prototype now includes a contextual tree/leaf/texture workshop and a socketed 3D goblin creator. Read [AUTHORING.md](/AUTHORING.md) for the implemented surface brush, procedural PBR recipes, sculpting, normal-source blending, local GLB conversion, and immutable preset-library workflow. This supersedes the earlier generic material-preview description below.

## 0. Prototype scope

Implemented: live procedural floating island; three visual biomes; nested preset traversal; bounded scene graph validation; holographic gel-volume preview; deterministic seeded brush growth; terrain carving; undo/redo; arc-length Bezier rail generation; animated drive chain; goblin sphere motion; fixed-step detachment, gravity, proximity collision, debris and winch; adaptive rendering resolution; built-in render pipelines; safe declarative package import; trusted-worker diagnostic; private/public world storage; immutable database revisions; branching; revision restore; public share URLs; world archiving; JSON export.

Not production-complete: authoritative multiplayer, networked rigid-body destruction, astrophysical precision, automatic dependency migration, arbitrary shader/physics plugin execution, asset generation with Hunyuan3D, and an actually unbounded resident world. These have concrete architectural plans below. The standalone executable test is /prototype.html; the richer application uses src/lib/engine/scene.ts and the public worker.

## 1. Blindspot solutions

### 1.1 Recursive graph without recursive memory

Use a flat directed acyclic graph. No node contains an embedded child scene. The same node contract applies to a material and a universe. A child is an immutable reference plus a relative coordinate frame:

```ts
interface NodeTransform {
  position: [number, number, number];
  quaternion: [number, number, number, number];
  logScale: number; // base-10 exponent relative to parent; never multiply a 300-level chain
}
interface NodeReference {
  nodeId: string;
  revision: number;
  transform: NodeTransform;
  policy: 'pinned' | 'follow';
}
interface FractalNode {
  id: string; revision: number; seed: number;
  kind: 'universe' | 'planet' | 'terrain' | 'biome' | 'prop' | 'material' | 'rail';
  name: string;
  children: NodeReference[];
  parameters: Record<string, string | number | boolean>;
}
interface GraphSnapshot {
  schemaVersion: 1; rootId: string;
  nodes: Record<string, FractalNode>;
}
```

A production node identifier is SHA-256(canonical node body + pinned dependency hashes). The prototype uses stable IDs and explicit integer revisions. Reference identity is distinct from instance identity: an edge has its own transform; changing one rock instance does not change every instance.

Import validation: tri-color DFS detects cycles; cap 4,096 nodes, 16,384 edges, 128 children per node, 32 logical traversal levels; validate finite relative transforms and exact revision references. Traversal resolves the active path and a bounded visible frontier, not every descendant. FractalNodeGraph.get uses a bounded 128-node LRU.

Production residency: asynchronous breadth-first visible-frontier expansion with a per-frame 2 ms decode budget, maximum 2,048 active instances, and hardware-adjusted 256 MB GPU budget. Split above 2 px screen-space error; merge below 1 px. Defer newly split nodes if memory pressure exists. Cache immutable geometry by content hash; count references; dispose GPU buffers when evicted. A recursion/depth guard applies even if import validation was bypassed.

Coordinate addresses are (world hash, instance path, spatial cell, local position, log scale). Host arithmetic uses Float64 cells; render only relative to a camera origin in Float32. Scale exponents are added symbolically, not naively exponentiated across the full chain. Infinite logical nesting is served as finite streamed chunks; the prototype intentionally limits depth.

### 1.2 Physics independent of camera scale

Create activity-based physics islands. A player zooming to the galaxy changes render demand, never the activity of another player's simulation. Each active world's local coordinate frame remains meter-scale regardless of the observer's view.

Spatial hashing: 32 m cells, swept AABB broad phase, meter-scale Float64 origin per island. Step at 120 Hz with a six-substep catch-up ceiling. Continuous swept-sphere collision prevents tunneling; constrain rail-attached bodies to a spline with a bilateral hook constraint. Contact impulses exceeding hook capacity detach a rider. Detached bodies use gravity and CCD against terrain/props. Fracture assets into a fixed bounded set of convex proxy chunks; reclaim old cosmetic debris from a pool.

Inactive islands sleep, retaining mass, bounds and ownership. Faraway viewers receive aggregate transforms at 2–5 Hz, while nearby participants receive authoritative snapshots at 20 Hz with 120 Hz prediction. Physics never approximates a nearby participant because another camera is far away. Active-island migration copies pose, linear/angular momentum and contacts at a tick boundary. Adjacent islands share an authority handoff protocol. All collisions are computed in one canonical scale; galaxy objects are frame transforms, not millions of tiny colliders.

An orbital editor modifies a world frame. Existing occupants and their local constraints stay in local coordinates. Destructive frame edits are queued to a simulation barrier and require host permission.

The runnable local test uses arc-length rail kinematics, a fixed 120 Hz loop, proximity impulses, ballistic gravity, and a critically damped spring for the winch: F = k(anchor − position) − 2√(km) velocity, k = 32. This demonstrates the boundary but is not a general rigid-body engine. Use Rapier in a trusted worker for production, with host-side authority and physics package allowlisting for ranked matches.

### 1.3 Plugin sandbox security

A Web Worker is NOT a security sandbox. Same-origin workers have network and origin capabilities. Never execute community JS in a normal worker or the UI thread.

Prototype policy: allow only JSON EnginePackage descriptors. Reject unknown properties, source code, URL fields, imports, NaN, infinite values and excess payloads. Approved fields are schemaVersion, name, renderStyle, damping and maxParticles. Only the three built-in renderStyle values can select bundled rendering code. The import currently applies renderStyle; damping and particle-budget fields are validated metadata reserved for future worker configuration, not a promise that the prototype replaces its authoritative physics. The diagnostic worker is trusted bundled code and receives only typed buffers.

Production executable policy:
1. Host plugins at a different origin without application cookies. Load them into an opaque sandboxed iframe (sandbox=allow-scripts, never allow-same-origin). The trusted loader supplies an isolated worker runtime.
2. Enforce a response-header CSP: default-src 'none'; connect-src 'none'; frame-src 'none'; img-src 'none'; media-src 'none'; form-action 'none'; base-uri 'none'; worker-src approved-loader; script-src approved signed loader. A dedicated origin is mandatory; CSP does not protect a plugin with application authority.
3. Prefer WASM modules with no ambient imports. Expose deterministic math, read-only coordinate snapshots and capability-indexed buffers only. Never expose DOM, credentials, local storage, raw file handles or unrestricted fetch.
4. Validate a narrow MessageChannel protocol on both ends. Cap 64 KB messages, 60 messages/s, 64 MB linear memory, 2 ms per tick, and 128 cosmetic particles. Use watchdog termination; bounded fuel/instrumentation addresses modules that never yield. Terminate on unknown opcodes or invalid numbers.
5. Render plugins return a bounded declarative command buffer; a trusted renderer creates resources. Physics plugins return proposals; the authoritative host revalidates collisions and limits. Ranked play uses a signed trusted physics profile.
6. Content-address packages, verify signatures and permissions, scan releases, maintain a revocation list, and never let a plugin mint capabilities. Browser vulnerabilities remain outside the application sandbox guarantee.

PluginOrchestrator.dispose terminates workers and deadlines fail closed. A declarative pipeline is the only community package format enabled today.

### 1.4 Immutable dependencies and Git-like branches

Never overwrite a published material revision. A new revision changes its content hash. Worlds pin an exact dependency closure in a lockfile. An update to a material is a new candidate, not silent mutation of all branches.

The prototype persists hm2_worlds (branch head) and hm2_world_revisions (immutable snapshots, keyed by world ID and revision). Saving requires the expected base version. One database transaction updates the head using a version guard and inserts its revision. A concurrent save receives HTTP 409 and preserves the losing client's working draft. Branching creates a new world row with parentId and an independent snapshot. Restoring an old revision makes a working draft; saving adds a new immutable revision. Archiving retains reachable revisions.

Production adds preset_blobs(hash, canonicalJSON, ABI), branch_heads(id, headHash, ancestorHash), dependency_edges(parentHash, childHash), lockfiles(worldHash, refs), reverse_refs(childHash, branchId), and subscriptions(branchId, packageId, mode). Hash all dependency references, not only the top-level object. Follow subscriptions enqueue an upgrade proposal, compute the affected closure using the reverse index, and stage an isolated preview branch. Explicit acceptance rewrites the lockfile; pinned branches never change. Batch fan-out with a job queue, deduplicate by candidate hash, and apply monotonic revision guards.

Three-way merge uses stable instance IDs and the nearest common ancestor. Independent edits merge by field; conflicting transforms/material parameters and delete-vs-edit collisions require a choice. Do not use last-write-wins for physical layout. Retain published reachable hashes; mark-and-sweep only unreachable blobs after a retention interval. ABI changes require a new package major version and a migration node.

## 2. Implementation architecture

### FractalNodeGraph — src/lib/engine/graph.ts
- validate(snapshot): cycle checks, finite-transform validation, graph quotas, pinned-revision consistency.
- get(id): bounded LRU lookup.
- enter(path, childId): validates direct-child traversal and guards path length.
- pathTo(id): non-recursive breadth-first navigation.
- Future: resolveFrontier(camera, budget), acquire(hash), release(hash), cancel pending loaders by traversal epoch.

### GelBrushSystem / AutoSizeEngine — src/lib/engine/brush.ts
- stroke(position, settings, style, carve): serializable seeded brush command.
- samples(stroke): deterministic evenly distributed bounded samples.
- resolve(diameter, enabled): scale, placement spacing, and tier (micro, biome, landform).
- Preview: transparent sphere, fine line grid, contact ring, holographic wobbling trees.
- Grow: terrain-following miniature vegetation. Carve: vertex depression and removal of vegetation in the stroke volume. Edit commands are reversible snapshots.
- Production placement: signed-distance field brush; blend triplanar PBR materials by normal slope and elevation; local occupancy grid repels props to nearest valid free cell. Fixed density and instance quotas prevent brush-radius explosions. AutoSize changes preset scale, not the resident-object budget.

### SlottedRailSystem — src/lib/engine/rail.ts
- Convert anchors to C1 cubic Bezier segments with Catmull-Rom tangent estimates; use an arc-length table.
- point(distance), tangent(distance), nearest(point), winchForce(position, velocity, anchor, mass).
- Instanced plates/rivets/chain links; center-slot ribbon; continuous link positions advance modulo rail length.
- Separate rail graph topology from curve geometry. Junctions need stable ports, tangent continuity, switch state and host tick ordering. The prototype supports a closed default route and a user-painted open curve, not full routed junction editing.
- Sphere hook state machine: ATTACHED → DETACHED → WINCHING → ATTACHED. W applies the damped cable force; attach below a capture-distance threshold. Space demonstrates ejection/debris, Shift boosts the player.

### PluginOrchestrator — src/lib/engine/plugins.ts
- validate(unknown): strict declarative contract, fixed known fields and bounded values.
- diagnose(): creates a trusted bundled Worker, validates response, enforces a three-second deadline, transfers a bounded Float32 buffer.
- dispose(): terminate and revoke capabilities.
- Production phases: immutable manifest verification → per-origin isolation → handshake with ABI → capability grant → bounded command buffer → watchdog → revoke/terminate.

### SandboxScene — src/lib/engine/scene.ts
The Three.js scene owns all rendering resources, controls, picking, graph-depth view transitions, instanced trees, procedural terrain, Bezier rails and a fixed-step simulation. React sends coordinate snapshots and context; renderer output never enters the world storage format. Scene disposal cancels the loop, observers, listeners, controls and GPU allocations. Painted vegetation is grouped into at most nine instanced meshes with a 1,024-tree resident frontier; full stroke commands remain in the saved snapshot. Pro mode uses real Three.js TransformControls with persisted translation, rotation, uniform scale and geometry-detail levels. Rendering metrics come from the real renderer rather than hardcoded FPS claims. Graphics Auto lowers device-pixel ratio under sustained budget pressure.

### Backend routes
- GET /api/worlds: session-owned non-archived worlds; ?scope=community for public worlds.
- POST /api/worlds: validated snapshot and optional accessible parent; insert initial immutable revision.
- GET /api/worlds/:id: owner/private or public access; ?revisions=1 returns history.
- PATCH /api/worlds/:id: owner-only optimistic update, visibility, name, archive, or snapshot.

Anonymous workspace ownership is a cryptographically random HttpOnly same-site cookie. Private snapshots never leave owner-scoped routes. This is local-studio ownership, not user authentication; production needs accounts, CSRF Origin validation, API rate limiting, moderation, malware scanning for uploaded assets and storage quotas. Existing quotas: 100 worlds/session, 600 strokes/world, 64 rail anchors/world, 750 KB JSON request limit.

## 3. Development order and acceptance criteria
1. Graph/schema/storage: cycle rejection, missing revision rejection, atomic branch creation, conflict response, ownership checks.
2. Procedural renderer: immutable seeded terrain; draw-call budgeting; explicit GPU disposal; graceful WebGL fallback.
3. Brush: finite bounded samples; resize preview; growth/carving; undo/redo; exact snapshot replay.
4. Rails/physics: continuous tangent joins, arc-length speed, fixed tick under render slowdown, detachment, bounded chunks and W capture.
5. Traversal: macro world, visible biome focus, microscopic sub-mesh material world; only leaf levels unlock Pro.
6. Community: shareable public worlds, private branches, retained history, explicit dependency pins.
7. Authority: activity-based physics islands, coordinate/seed deltas, host validation, rollback reconciliation.
8. Executable plugins: separate-origin loader, signed WASM, budget enforcement and revocation tests.

Production acceptance needs graph fuzzing, physics contact and migration tests, plugin hostile-message tests, 10k-branch dependency upgrade tests, bounded memory soak testing, cross-device profiling, and multiplayer reconciliation tests. The prototype must not advertise production multiplayer simply because it can publish worlds.

## 4. Hunyuan3D-2.1 local asset pipeline

Generation stays offline: concept → Hunyuan3D-2.1 rough mesh → split moving parts/material groups → retopology and UV unwrap → bake PBR maps → convex collision proxies → four LODs → GLB manifest with pivot/scale/material hashes. Normalize to meters, Y-up, linear-color data maps and sRGB base color. Use GPU instancing for repeated props, drive-chain links and track plates. Chunk fracture proxies are authored, not arbitrarily generated during a frame. Never ship rough AI topology directly to ranked runtime physics.

## 5. Codex/downstream generative art prompts

### A. Pro-mode fundamental manipulators
Create an orthographic, production-ready 3D modeling and UI asset brief for HeavyMetal2 material-level manipulators. Translate: three tapered axis arrows; rotate: concentric segmented rings; scale: hollow endpoint cubes; decimate: a faceted icosahedron transitioning from dense to coarse topology. X muted coral, Y electric sage, Z icy blue; active handles luminous chartreuse. Brushed graphite housings, ultra-thin emissive edges, no ornamental fantasy clutter. Maintain 18 px screen-space handles, 6 px invisible hit padding, color-independent axis labels, and separate depth-tested and overlay passes. Deliver clean named meshes, pivot origins, GLB assets, PBR maps, wireframe topology references, and hover/active/disabled states. Hunyuan3D rough geometry must be split, retopologized, and reduced to less than 1,200 triangles per tool; use shared instanced materials.

### B. Iron-riveted rail, chain and winch
Design a functional iron-riveted continuous slotted rail for HeavyMetal2, a chaotic goblin sphere arcade sandbox. A 0.8 m dark wrought-iron plate deck, 0.13 m recessed central slot, articulated brass-and-steel drive chain, beveled plates, countersunk rivets, grease-packed bearings, modular spline-ready 0.38 m sections. Show underside chain return, plate cross section, clamp hook engagement, and a transparent 0.96 m sphere with a pedaling goblin pilot. Add an internal winch spool, cable fairlead, spring-loaded hook and recoil mount. Weathered ochre metal, charcoal steel, pale sage goblin skin; deliberately readable, not photorealistic noise. Produce exploded orthographic diagrams, 2K packed ORM textures, pivot/rig specification, four LODs, collision proxy geometry, debris chunks, and tileable chain animation. Hunyuan3D output is concept geometry only: split moving components, retopologize, preserve mechanism clearances, and instance plates/rivets/links.

### C. Styles & Presets fractal navigation drawer
Create a high-fidelity interface and motion brief for the HeavyMetal2 Styles & Presets fractal navigation drawer. A premium developer-grade creative studio in deep pine-black and graphite, hairline cool-gray dividers, chartreuse active accents, restrained lavender cosmic tags, crisp Inter typography and Space Grotesk world titles. Show a Universe → Planet → Terrain → Biome → Prop → Material path using miniature procedural world previews, stable indented hierarchy, pin badges for immutable revisions, and a luminous enter-preset arrow. The gel-brush preview is a translucent sage volume with holographic miniature trees suspended inside. Pro Mode reveals precise three-axis manipulators only at the material/shape level. Provide 280 px desktop drawer, narrow tablet sheet, keyboard focus, reduced-motion states, empty/loading/error states, branching and public/private actions. No baked-in text in image assets; use accessible real text and icons.

## 6. Run / verify

Use npm install; configure DATABASE_URL; apply tables with npx drizzle-kit push; run npm run dev. For production run npx next typegen; npm exec tsc -- --noEmit --pretty false; npm run build. Platform preview uses build_and_start and /api/health. No third-party API keys are required.

Open /prototype.html for a standalone import-map Three.js scene with contextual tree/leaf/texture traversal, direct UV paint, real vertex sculpting, and editable vein/normal controls. It requires CDN access; the main app bundles Three.js locally and does not use that CDN.
