# HeavyMetal² — The Plan

> **Picking this up fresh?** Start at **[/handoff](/handoff)** — the agent brief with
> repo context, prioritised tasks and acceptance criteria. Markdown: [HANDOFF.md](/HANDOFF.md).

One document. What this is, what is actually built, and what comes next.
Supersedes the scattered notes in `ENGINEERING.md` (architecture deep-dive) and
`AUTHORING.md` (preset authoring detail), both of which remain as references.

---

## 1. The one idea

**Everything is a preset.** A cube, a bark texture, a leaf, a branch, a tree, a
goblin's ear, a race rule, and *the interface you are reading this in* are all
the same kind of object: a recipe with a revision, a dependency closure, and a
share code.

If something can be seen, it can be entered. If it can be entered, it can be
sculpted, painted, saved, forked and shared. There is no privileged "engine
content" tier that users cannot reach.

The chain that proves it:

```
cube ──▶ + bark texture ──▶ save as "bark cylinder"
                                  │
                                  ▼
                          branch preset ──▶ + leaves ──▶ tree preset ──▶ biome ──▶ world
```

Every arrow is a click. Every box is shareable as one line of text.

---

## 2. Status at a glance

| Layer | State |
|---|---|
| Fractal preset graph, revisions, forking | Built |
| Primitive shapes → materials → objects → composed presets | Built |
| Procedural PBR recipes (colour, normal, roughness, height) | Built |
| Surface painting + vertex sculpting at every depth | Built |
| 3D goblin assembly from socketed parts | Built |
| Compact share codes (77% smaller than raw JSON) | Built |
| Share incentives + reputation ledger | Built |
| Context-aware material shelf + next-brush (`E`) | Built |
| Auto-hiding drawers, branching preset network | Built |
| **Interface as a sculptable, shareable preset** | **Built** |
| **Swappable icon sets** | **Built** |
| **Phone layout (bottom sheets, thumb rail)** | **Built** |
| **PBR showcase vignette (rock · tree · bush)** | **Built** |
| **PBR material palette (clickable paint wells)** | **Built** |
| Low-poly PBR texture set (art pipeline) | Art done — wiring pending, §9 |
| Reactive preset chemistry (dirt + water = mud) | Designed, not built — §10 |
| Race planet, betting, chin-check spectating | Built |
| Open-source mod registry | Built |
| Authoritative multiplayer | Not built — see §8 |
| Executable community plugins | Not built — see §8 |

---

## 3. The preset ladder

Depth is the organising principle. Going *down* narrows scope and changes what
the brush means; going *up* composes.

| Depth | Preset kind | Brush does | Shelf offers |
|---|---|---|---|
| 0 | `texture` | Paints pigment into a recipe; push/pull writes relief into the normal map | All six PBR families |
| 1 | `shape` | Sculpts a raw primitive — cube, cylinder, sphere, cone, plane, torus | Enamel, iron, bark, basalt |
| 2 | `object` / `part` | Primitive + pinned material; the reusable building block | Material families for that slot |
| 3 | `wood` / `leaf` | Sculpts the specific member; paint routes to its linked texture | Bark / foliage families |
| 4 | `tree` / `goblin` | Grows structural members from child presets | Composition materials |
| 5 | world | Gel brush grows biomes, carves terrain, draws rail | Biome presets |

**Rule:** the brush always acts on the preset you are *inside*, never the one
above it. Painting a leaf edits the leaf's texture recipe, not the tree.

### Navigation
- **Radial depth menu** — six tactile PBR wedges, click to descend by material family.
- **Preset network** — full-screen branching timeline, laid out left→right by depth with live dependency curves. Drag to pan, scroll to zoom, **Edit** on any node to jump straight in.
- **Per-preset edit buttons** — a pencil on every hierarchy row and shelf entry.

---

## 4. The interface is a preset

This is the piece that closes the loop. The studio chrome is not hardcoded; it
is an `InterfaceRecipe` with exactly the same lifecycle as a leaf.

**Sculpt** — icon set, icon stroke weight, corner softness, hairline thickness,
panel radius, control density.
**Paint** — backdrop, panel, ink, accent, accent strength, surface grain.
**Share** — one line, `HM2UI-…`, 65 characters. Short enough to paste in chat.

Applying a recipe rewrites CSS custom properties on the root element, so the
whole studio re-skins live with no reload and no rebuild.

### Icon sets
Icons are path data, never bitmaps, so a set travels inside the share code and
inherits the sculpted stroke weight.

| Set | Character |
|---|---|
| **Hairline** | Thin charcoal strokes. Quiet and precise. The default. |
| **Stencil** | Cut-out blocks with spray-stencil weight. |
| **Chisel** | Angular facets, carved from stone. |
| **Tag** | Loose marker lines, hand-sprayed. |

All four cover the full 26-icon vocabulary, verified by test. A missing icon
falls back to Hairline rather than rendering an empty box.

### Safety
Every value is clamped on the way in (`normaliseInterface`) and strictly
validated on the way across the wire (`validateInterface`). A hostile code
cannot inject colour strings, oversized radii, or unknown icon sets — it is
clamped to a safe recipe or rejected outright. The interface code carries
*only* presentation values, so it is safe to paste from a stranger.

---

## 5. Phone layout

Not a scaled-down desktop. A different arrangement of the same parts.

- **The viewport is the page.** Side panels are gone; the island fills the screen.
- **Bottom sheets.** Explorer and Inspector slide up from the bottom, with a grab handle, a scrim, and a tap-to-dismiss. Hover never opens a sheet on a touch device.
- **Thumb rail.** The tool rail rotates to a horizontal strip across the bottom of the viewport with 42px targets.
- **Launcher bar.** Four persistent destinations — World, Tools, Presets, Skin.
- **Safe areas.** `env(safe-area-inset-*)` on every fixed edge, `viewportFit: cover`, `100dvh` so the browser chrome collapsing does not clip controls.
- **Landscape.** Below 480px tall the title and dock drop out so the viewport stays dominant.
- **Coarse pointer.** `@media (hover: none)` forces every hover-revealed affordance permanently visible.

Touch targets: sliders 22px tall, toggles 38×22, tree rows 44px, sheet buttons 50px.

---

## 6. Sharing and incentives

A share code is a deflated, key-shortened, base64url package containing a
preset and its entire dependency closure. Measured: **2,875 B → 659 B, 77%
smaller**. Small enough for a chat message or a URL.

| Action | Reward |
|---|---|
| Publish a preset | +40 Scrap |
| Someone *uses* your preset | +15 Scrap |
| Someone *remixes* your preset | +35 Scrap + 1 remix credit |

Rewards pay only when **someone else** picks it up, so the loop rewards useful
presets rather than self-farming. Remix credits convert to island space, which
ties sharing back into the building game.

**Share settings:** auto-share on save · share on planet entry · attach active
preset to chat messages. All three persist server-side per session.

---

## 7. The showcase room

The white room is a material showroom, not a racetrack. The old sleeping-goblin
vignette and the slotted rail have been removed from the presentation scene so
nothing competes with the materials.

In the centre, on a plinth of damp forest soil:

- **Weathered granite boulder** — mineral speckle, fracture lines that bite into the normal map, lichen blooms that are visibly rougher than the polished facets.
- **Fissured bark tree** — deep vertical ridges, root flare, tapering limbs, damp moss in the crevices reading rougher than the ridges.
- **Waxy broadleaf bush and canopy** — branching veins raised in the normal map, specular sheen patches where roughness drops.

Every material is a real `MeshStandardMaterial` with albedo, tangent-space
normal, roughness and AO maps generated procedurally at 512². Lighting is a
three-point studio rig — warm key with soft shadows, cool fill, bright rim —
so roughness and normal detail are legible rather than implied.

**Dark mode is now just the "Dark Room" interface preset.** There is no second
stylesheet; the theme toggle swaps an `InterfaceRecipe`, which is the same
mechanism a user gets when they paint their own.

### The palette
A paint holder docks to the right of the viewport. Each well is a circular
blob rendered from the *same generator* that textures the scene, lit with an
inset highlight and shadow so it reads as wet material rather than a flat
colour chip. Clicking loads that material onto the brush. Collapses to a grip
when you need the viewport. On phones it becomes a horizontal tray.

---

## 8. What is deliberately not built

Stated plainly so the prototype is not mistaken for a product.

- **Authoritative multiplayer.** The race planet, chat, leaderboard and mod registry are real and database-backed, but there is no server-authoritative physics or anti-cheat. Spectator chin-checks resolve client-side.
- **Executable community plugins.** The mod registry stores *declarative* hooks — numbers and flags validated against a schema. No user code is executed. Running untrusted code needs a separate origin, a signed WASM loader, and capability-based buffers; that is designed in `ENGINEERING.md` §1.3 but not implemented.
- **Topology-preserving remesh.** Sculpting moves existing vertices. Imported GLBs are sampled to a triangle budget, which is a preview reduction, not real decimation. Retopologise offline.
- **Atlas-aware multi-surface bake.** PBR export covers the selected surface; a goblin's six parts need six bakes or a packed atlas.
- **Unbounded scale.** Hard caps: 4,096 graph nodes, 32 traversal levels, 256 authoring documents, 1,400 surface marks, 200 saved presets. These are real limits, not placeholders.

---

## 9. Next, in order

1. **Low-poly PBR texture set.** The art is already produced; this is wiring, not redesign. Each incoming set lands as a `TexturePattern` entry plus a `PbrSet` of albedo/normal/roughness/AO canvases or image URLs. The swap-in point is `pbr-showcase.ts` — `GENERATORS` and `SHOWCASE_MATERIALS` already define the slots, UV repeat and normal strength per material, so a set drops in without touching the scene graph. Palette wells pick it up automatically. Acceptance: a low-poly set renders in the showcase and appears in the palette with no scene-code change.
2. **Interface presets to the server.** They currently persist to `localStorage` and travel by code. Give them a row in `hm2_authoring_presets` with `kind = "interface"` so they appear in the community list and earn Scrap like any other preset.
3. **Icon set authoring.** The four sets are authored in code. The same sculpt/paint panel should let a user fork a set and redraw individual glyphs — closing the loop fully.
4. **Reactive preset chemistry.** See §10 — the biggest gameplay unlock on this list.
5. **Per-surface bake atlas**, so multi-part presets export cleanly.
6. **Server-authoritative race tick**, the precondition for everything in §8's first bullet.

---

## 10. Reactive presets — preset chemistry

A toggle you switch on in Play mode. Presets stop being inert materials and
start **reacting to each other** on contact.

```
dirt + water   ──▶ mud          (slows spheres, splatters, dries back to dirt)
flame + wood   ──▶ burning wood ──▶ ash   (spreads along connected wood)
water + flame  ──▶ steam        (flame extinguished, brief vision cover)
lava + water   ──▶ basalt       (permanent new terrain)
moss + stone   ──▶ mossy stone  (slippery, grows slowly over time)
sand + flame   ──▶ glass        (hard, reflective, shatters on impact)
```

### Why this fits the architecture
A reaction is **just another preset edge**. Both inputs are presets, the output
is a preset, and the rule is a small declarative record — no user code, so it
rides the existing validation and share-code machinery.

```ts
interface ReactionRule {
  a: string;            // preset id or tag, e.g. "tag:liquid"
  b: string;
  produces: string;     // resulting preset id
  threshold: number;    // contact amount needed, 0–1
  rate: number;         // how fast it converts
  spreads: boolean;     // does it propagate along touching cells?
  reversible: boolean;  // mud dries back to dirt; basalt does not
}
```

### Design constraints, decided up front
- **Opt-in per world.** A `reactions: boolean` flag in `IslandEconomy`, surfaced as a Play-mode switch. Build mode stays deterministic so authoring is never surprising.
- **Tag-based, not pair-explosion.** Rules match on tags (`liquid`, `combustible`, `mineral`) so N materials do not need N² rules.
- **Bounded propagation.** Fire spreads through the existing spatial hash with a per-tick cell budget and a hard cap on active reactions, the same discipline as the physics islands.
- **Reversible by default where plausible.** Mud dries, moss regrows, steam dissipates. Irreversible reactions (basalt, glass, ash) are flagged explicitly because they permanently rewrite someone's build.
- **Shareable.** A reaction table is a preset like anything else, so a community can publish a "wet season" rule set or a "tinderbox" rule set and others can wear it.

### Open questions to settle before building
- Does a reaction create a *new* preset instance, or mutate the existing one's revision? Leaning new instance, so undo and history stay intact.
- How do reactions interact with the share economy — does the author of `mud` earn when two other people's presets combine into it?
- Should reactions run in Build mode behind a "preview" toggle, or stay strictly Play-only?

---

## 11. Working agreements

---

- **Preserve the flat language.** Zero rounded corners by default, hairline charcoal, warm white. Tactile PBR belongs in the radial wedges and small previews, not flooded across the chrome.
- **Clamp, then validate.** Anything crossing a boundary gets clamped client-side for resilience and validated server-side for safety. Never trust a share code.
- **Context over configuration.** The shelf and the next-brush suggestion derive from where the user is standing. Prefer inference to another settings toggle.
- **Say what is not built.** Every surface that looks multiplayer-ready must be honest in its copy about being a prototype.
