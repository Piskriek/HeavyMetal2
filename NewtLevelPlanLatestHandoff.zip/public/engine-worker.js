"use strict";
// Trusted bundled worker: no eval, imports, network, or user-supplied source.
self.onmessage = function (event) {
  const message = event.data;
  if (!message || message.type !== "diagnose" || message.count !== 128) return;
  const positions = new Float32Array(128 * 3);
  for (let i = 0; i < 128; i++) {
    positions[i * 3] = Math.sin(i) * 16;
    positions[i * 3 + 1] = Math.cos(i) * 4;
    positions[i * 3 + 2] = Math.sin(i * 2) * 16;
  }
  self.postMessage({ type: "ready", budget: 128, positions: positions.buffer }, [positions.buffer]);
};
