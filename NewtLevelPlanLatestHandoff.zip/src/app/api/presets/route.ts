import { NextResponse } from "next/server";
import { and, desc, eq, or, sql } from "drizzle-orm";
import { createHash } from "node:crypto";
import { db } from "@/db";
import { authoringPresets, presetUses, shareProfiles } from "@/db/schema";
import { apiError, readBody, sessionToken } from "@/lib/world-api";
import { validatePresetPackage } from "@/lib/engine/authoring-validation";

export const dynamic = "force-dynamic";

/** Sharing rewards: give a preset away, get Scrap + remix credits back. */
const REWARD_PUBLISH = 40;
const REWARD_PER_USE = 15;
const REWARD_PER_REMIX = 35;

async function loadProfile(token: string) {
  const [existing] = await db.select().from(shareProfiles).where(eq(shareProfiles.ownerToken, token)).limit(1);
  if (existing) return existing;
  const [created] = await db.insert(shareProfiles).values({ ownerToken: token }).onConflictDoNothing().returning();
  if (created) return created;
  const [again] = await db.select().from(shareProfiles).where(eq(shareProfiles.ownerToken, token)).limit(1);
  return again;
}

export async function GET(request: Request) {
  try {
    const token = await sessionToken();
    const url = new URL(request.url);
    const scope = url.searchParams.get("scope");
    const profile = await loadProfile(token);
    const rows = await db
      .select()
      .from(authoringPresets)
      .where(scope === "community" ? eq(authoringPresets.visibility, "public") : or(eq(authoringPresets.ownerToken, token), eq(authoringPresets.visibility, "public")))
      .orderBy(desc(authoringPresets.useCount), desc(authoringPresets.createdAt))
      .limit(80);
    return NextResponse.json({
      presets: rows.map(({ ownerToken, ...p }) => ({ ...p, owned: ownerToken === token })),
      profile: profile ? { ...profile, ownerToken: undefined } : null,
    });
  } catch (error) {
    return apiError(error);
  }
}

export async function POST(request: Request) {
  try {
    const token = await sessionToken();
    const body = await readBody(request);
    const action = typeof body.action === "string" ? body.action : "save";
    const profile = await loadProfile(token);

    // --- Update share preferences ---
    if (action === "settings") {
      const patch: Record<string, unknown> = { updatedAt: new Date() };
      if (typeof body.handle === "string" && body.handle.trim()) patch.handle = body.handle.trim().slice(0, 48);
      for (const key of ["autoShare", "shareOnEntry", "shareWhenTalking"] as const) {
        if (typeof body[key] === "boolean") patch[key] = body[key];
      }
      const [updated] = await db.update(shareProfiles).set(patch).where(eq(shareProfiles.ownerToken, token)).returning();
      return NextResponse.json({ profile: { ...updated, ownerToken: undefined } });
    }

    // --- Record a use or a remix, and pay the original author ---
    if (action === "use" || action === "remix") {
      const presetId = String(body.presetId ?? "");
      if (!/^[0-9a-f-]{36}$/i.test(presetId)) throw new Error("Invalid preset reference");
      const [preset] = await db.select().from(authoringPresets).where(eq(authoringPresets.id, presetId)).limit(1);
      if (!preset) throw new Error("That preset is no longer available");
      if (preset.visibility !== "public" && preset.ownerToken !== token) throw new Error("That preset is private");

      await db.insert(presetUses).values({ presetId, userToken: token, action: action === "remix" ? "remix" : "use" });
      const [counted] = await db
        .update(authoringPresets)
        .set(action === "remix"
          ? { remixCount: sql`${authoringPresets.remixCount} + 1` }
          : { useCount: sql`${authoringPresets.useCount} + 1` })
        .where(eq(authoringPresets.id, presetId))
        .returning();

      // Author earns only when someone else picks it up
      if (preset.ownerToken !== token) {
        const reward = action === "remix" ? REWARD_PER_REMIX : REWARD_PER_USE;
        await db
          .update(shareProfiles)
          .set({
            scrapFromSharing: sql`${shareProfiles.scrapFromSharing} + ${reward}`,
            remixCredits: sql`${shareProfiles.remixCredits} + ${action === "remix" ? 1 : 0}`,
            updatedAt: new Date(),
          })
          .where(eq(shareProfiles.ownerToken, preset.ownerToken));
      }
      const { ownerToken: _o, ...safe } = counted;
      return NextResponse.json({ preset: { ...safe, owned: counted.ownerToken === token }, reward: preset.ownerToken === token ? 0 : action === "remix" ? REWARD_PER_REMIX : REWARD_PER_USE });
    }

    // --- Save (and optionally auto-share) a preset package ---
    if (typeof body.name !== "string" || !body.name.trim() || body.name.trim().length > 80) {
      throw new Error("Choose a preset name between 1 and 80 characters");
    }
    validatePresetPackage(body.package);
    const [count] = await db.select({ total: sql<number>`count(*)::int` }).from(authoringPresets).where(eq(authoringPresets.ownerToken, token));
    if (count.total >= 200) throw new Error("This workspace has reached its 200 saved-preset limit");

    const pkg = body.package;
    const contentHash = createHash("sha256").update(JSON.stringify(pkg)).digest("hex");
    const shareCode = typeof body.shareCode === "string" && body.shareCode.length <= 60000 ? body.shareCode : null;
    // Auto-share preference wins unless the request is explicit
    const wantsPublic = body.visibility === "public" || (body.visibility === undefined && profile?.autoShare);

    const [preset] = await db
      .insert(authoringPresets)
      .values({
        ownerToken: token,
        name: body.name.trim(),
        kind: pkg.presets[pkg.rootId].kind,
        package: pkg,
        contentHash,
        shareCode,
        authorHandle: profile?.handle ?? "Goblin builder",
        visibility: wantsPublic ? "public" : "private",
      })
      .returning();

    let awarded = 0;
    if (wantsPublic) {
      awarded = REWARD_PUBLISH;
      await db
        .update(shareProfiles)
        .set({
          sharesGiven: sql`${shareProfiles.sharesGiven} + 1`,
          scrapFromSharing: sql`${shareProfiles.scrapFromSharing} + ${REWARD_PUBLISH}`,
          updatedAt: new Date(),
        })
        .where(eq(shareProfiles.ownerToken, token));
    }

    const { ownerToken: _owner, ...safe } = preset;
    return NextResponse.json({ preset: { ...safe, owned: true }, reward: awarded }, { status: 201 });
  } catch (error) {
    return apiError(error);
  }
}
