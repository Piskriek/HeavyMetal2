import { NextResponse } from "next/server";
import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { communityMods, planetChat, planetRuleVotes, raceLeaderboard } from "@/db/schema";
import { apiError, readBody, sessionToken } from "@/lib/world-api";
import { MAJORITY_RULES, type MajorityRuleId } from "@/lib/engine/types";

export const dynamic = "force-dynamic";

async function ensureSeeded(token: string) {
  const existingVotes = await db.select().from(planetRuleVotes);
  if (existingVotes.length === 0) {
    await db.insert(planetRuleVotes).values([
      { ruleId: "chin_check", votes: 14 },
      { ruleId: "standard", votes: 11 },
      { ruleId: "turbo_chain", votes: 9 },
      { ruleId: "low_gravity", votes: 8 },
      { ruleId: "free_anarchy", votes: 6 },
    ]).onConflictDoNothing();
  }
  const existingLeaders = await db.select().from(raceLeaderboard).limit(1);
  if (existingLeaders.length === 0) {
    await db.insert(raceLeaderboard).values([
      { ownerToken: "seed-1", goblinName: "Rivet the Chin-Checker", wins: 9, scrapEarned: 1420, chinHits: 17, islandScale: "2.25" },
      { ownerToken: "seed-2", goblinName: "Sprocket & Nix Co-Op", wins: 7, scrapEarned: 1180, chinHits: 12, islandScale: "1.50" },
      { ownerToken: "seed-3", goblinName: "Grub (Aqua Scrapdome)", wins: 5, scrapEarned: 890, chinHits: 21, islandScale: "1.75" },
    ]);
  }
  const existingChat = await db.select().from(planetChat).limit(1);
  if (existingChat.length === 0) {
    await db.insert(planetChat).values([
      { sender: "Rivet", message: "Standing on the north turn! Bet on Nix, I am about to take Sprocket's sphere to the chin!", presetName: "Forged brass", presetKind: "texture" },
      { sender: "Sprocket", message: "Joined islands with @Nix for 1.5x space each — our track loop now spans the whole cliff!", presetName: "Alpine leaf", presetKind: "leaf" },
      { sender: "Grub", message: "Vote Bloodsport Chin-Check for 2x hazard scrap on the Water Race Planet!", presetName: "Rivet, the rail gremlin", presetKind: "goblin" },
    ]);
  }
  const existingMods = await db.select().from(communityMods).limit(1);
  if (existingMods.length === 0) {
    await db.insert(communityMods).values([
      {
        ownerToken: token,
        title: "Chin-Ricochet Shockwave Hook",
        author: "RivetLabs (Open Source MIT)",
        hookTarget: "race.spectatorChinHit",
        description: "Multiplies ball deflection impulse by 1.65x when a spectator takes a sphere to the chin and awards +40 bonus Scrap.",
        configJson: { impulseMultiplier: 1.65, bonusScrap: 40, ragdollLift: 1.4 },
        upvotes: 19,
      },
      {
        ownerToken: token,
        title: "Bioluminescent Vein Shader Recipe",
        author: "MossWorks (Open Source MIT)",
        hookTarget: "texture.procedural",
        description: "Adds glowing cyan-lime vein contrast and bark normal blending to procedural leaf presets.",
        configJson: { veinContrast: 0.92, normalStrength: 1.45, veinCount: 18 },
        upvotes: 15,
      },
      {
        ownerToken: token,
        title: "Co-Op Mega-Island 1.5x Linker",
        author: "ScrapdomeCore (Open Source MIT)",
        hookTarget: "island.expand",
        description: "Upstream hook that grants 1.5x island terrain radius to both builders when linking friend codes.",
        configJson: { friendMultiplier: 1.5, bonusRailAnchors: 32 },
        upvotes: 24,
      },
    ]);
  }
}

export async function GET() {
  try {
    const token = await sessionToken();
    await ensureSeeded(token);
    const [leaders, chat, votes, mods] = await Promise.all([
      db.select().from(raceLeaderboard).orderBy(desc(raceLeaderboard.scrapEarned)).limit(15),
      db.select().from(planetChat).orderBy(desc(planetChat.createdAt)).limit(25),
      db.select().from(planetRuleVotes),
      db.select().from(communityMods).orderBy(desc(communityMods.upvotes), desc(communityMods.createdAt)).limit(20),
    ]);
    const voteMap: Record<string, number> = {};
    for (const r of MAJORITY_RULES) voteMap[r.id] = 1;
    for (const v of votes) voteMap[v.ruleId] = v.votes;
    let majorityRule: MajorityRuleId = "standard";
    let topVotes = -1;
    for (const r of MAJORITY_RULES) {
      if ((voteMap[r.id] ?? 0) > topVotes) {
        topVotes = voteMap[r.id] ?? 0;
        majorityRule = r.id;
      }
    }
    return NextResponse.json({
      leaderboard: leaders,
      chat: chat.reverse(),
      votes: voteMap,
      majorityRule,
      mods,
    });
  } catch (error) {
    return apiError(error);
  }
}

export async function POST(request: Request) {
  try {
    const token = await sessionToken();
    await ensureSeeded(token);
    const body = await readBody(request);
    const action = String(body.action ?? "");

    if (action === "vote") {
      const ruleId = String(body.ruleId ?? "") as MajorityRuleId;
      if (!MAJORITY_RULES.some(r => r.id === ruleId)) throw new Error("Invalid planet rule");
      await db
        .insert(planetRuleVotes)
        .values({ ruleId, votes: 1 })
        .onConflictDoUpdate({
          target: planetRuleVotes.ruleId,
          set: { votes: sql`${planetRuleVotes.votes} + 1`, updatedAt: new Date() },
        });
    } else if (action === "chat") {
      const sender = String(body.sender ?? "Goblin Spectator").trim().slice(0, 48) || "Goblin Spectator";
      const message = String(body.message ?? "").trim().slice(0, 280);
      if (!message) throw new Error("Enter a message to send to the planet");
      const presetName = typeof body.presetName === "string" ? body.presetName.slice(0, 80) : null;
      const presetKind = typeof body.presetKind === "string" ? body.presetKind.slice(0, 32) : null;
      await db.insert(planetChat).values({ sender, message, presetName, presetKind });
    } else if (action === "score") {
      const goblinName = String(body.goblinName ?? "Rivet").trim().slice(0, 60) || "Rivet";
      const wins = Math.max(0, Math.min(10000, Number(body.wins ?? 0)));
      const scrapEarned = Math.max(0, Math.min(10000000, Math.round(Number(body.scrapEarned ?? 250))));
      const chinHits = Math.max(0, Math.min(100000, Math.round(Number(body.chinHits ?? 0))));
      const islandScale = Number(body.islandScale ?? 1).toFixed(2);
      const existing = await db.select().from(raceLeaderboard).where(eq(raceLeaderboard.ownerToken, token)).limit(1);
      if (existing.length > 0) {
        await db.update(raceLeaderboard).set({
          goblinName,
          wins,
          scrapEarned,
          chinHits,
          islandScale,
          updatedAt: new Date(),
        }).where(eq(raceLeaderboard.id, existing[0].id));
      } else {
        await db.insert(raceLeaderboard).values({ ownerToken: token, goblinName, wins, scrapEarned, chinHits, islandScale });
      }
    } else if (action === "mod") {
      const title = String(body.title ?? "").trim().slice(0, 80);
      const author = String(body.author ?? "Community Modder").trim().slice(0, 60) || "Community Modder";
      const hookTarget = String(body.hookTarget ?? "race.spectatorChinHit").trim().slice(0, 48);
      const description = String(body.description ?? "").trim().slice(0, 240);
      if (!title || !description) throw new Error("Provide a mod title and description");
      const rawConfig = body.configJson && typeof body.configJson === "object" ? body.configJson as Record<string, unknown> : {};
      const configJson: Record<string, string | number | boolean> = {};
      for (const [k, v] of Object.entries(rawConfig).slice(0, 12)) {
        if (typeof v === "string" || typeof v === "number" || typeof v === "boolean") configJson[k] = v;
      }
      await db.insert(communityMods).values({ ownerToken: token, title, author, hookTarget, description, configJson, upvotes: 1 });
    } else if (action === "upvoteMod") {
      const modId = String(body.modId ?? "");
      await db.update(communityMods).set({ upvotes: sql`${communityMods.upvotes} + 1` }).where(eq(communityMods.id, modId));
    } else {
      throw new Error("Unknown race planet action");
    }

    return GET();
  } catch (error) {
    return apiError(error);
  }
}
