import { NextResponse } from "next/server";
import { and, desc, eq, or } from "drizzle-orm";
import { db } from "@/db";
import { worlds, worldRevisions } from "@/db/schema";
import { apiError, readBody, serializeWorld, sessionToken, validId } from "@/lib/world-api";
import { validateSnapshot } from "@/lib/engine/graph";

type Context = { params: Promise<{ id: string }> };
export async function GET(request: Request, context: Context) {
  try {
    const { id } = await context.params;
    if (!validId(id)) throw new Error("Invalid world ID");
    const token = await sessionToken();
    const [world] = await db.select().from(worlds).where(and(eq(worlds.id, id), or(eq(worlds.ownerToken, token), eq(worlds.visibility, "public")))).limit(1);
    if (!world) return NextResponse.json({ error: "World not found or private" }, { status: 404 });
    if (new URL(request.url).searchParams.has("revisions")) {
      const revisions = await db.select().from(worldRevisions).where(eq(worldRevisions.worldId, id)).orderBy(desc(worldRevisions.version)).limit(30);
      return NextResponse.json({ revisions });
    }
    return NextResponse.json({ world: serializeWorld(world, token) });
  } catch (error) { return apiError(error); }
}
export async function PATCH(request: Request, context: Context) {
  try {
    const { id } = await context.params;
    if (!validId(id)) throw new Error("Invalid world ID");
    const token = await sessionToken();
    const body = await readBody(request);
    if (!Number.isInteger(body.version) || Number(body.version) < 1) throw new Error("A valid base revision is required");
    if (body.snapshot !== undefined) validateSnapshot(body.snapshot);
    if (body.name !== undefined && (typeof body.name !== "string" || !body.name.trim() || body.name.trim().length > 80)) throw new Error("Invalid world name");
    const row = await db.transaction(async tx => {
      const [current] = await tx.select().from(worlds).where(and(eq(worlds.id, id), eq(worlds.ownerToken, token))).limit(1);
      if (!current) throw new Error("Only the owner can update this world. Branch it to make your own copy.");
      if (current.version !== body.version) return null;
      const snapshot = body.snapshot as typeof current.snapshot | undefined ?? current.snapshot;
      const nextVersion = current.version + 1;
      const [saved] = await tx.update(worlds).set({
        snapshot, version: nextVersion, updatedAt: new Date(),
        name: typeof body.name === "string" ? body.name.trim() : current.name,
        visibility: body.visibility === "public" ? "public" : body.visibility === "private" ? "private" : current.visibility,
        archived: typeof body.archived === "boolean" ? body.archived : current.archived,
      }).where(and(eq(worlds.id, id), eq(worlds.ownerToken, token), eq(worlds.version, current.version))).returning();
      if (!saved) return null;
      await tx.insert(worldRevisions).values({ worldId: id, version: nextVersion, snapshot, message: typeof body.message === "string" ? body.message.slice(0, 160) : "World saved" });
      return saved;
    });
    if (!row) return NextResponse.json({ error: "Another save changed this world. Reopen it or create a branch to preserve your edits." }, { status: 409 });
    return NextResponse.json({ world: serializeWorld(row, token) });
  } catch (error) { return apiError(error); }
}
