import { NextResponse } from "next/server";
import { and, desc, eq, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { worlds, worldRevisions } from "@/db/schema";
import { apiError, readBody, serializeWorld, sessionToken, validId } from "@/lib/world-api";
import { validateSnapshot } from "@/lib/engine/graph";

export const dynamic = "force-dynamic";
export async function GET(request: Request) {
  try {
    const token = await sessionToken();
    const community = new URL(request.url).searchParams.get("scope") === "community";
    const rows = await db.select().from(worlds).where(and(eq(worlds.archived, false), community ? eq(worlds.visibility, "public") : eq(worlds.ownerToken, token))).orderBy(desc(worlds.updatedAt)).limit(100);
    return NextResponse.json({ worlds: rows.map(row => serializeWorld(row, token)) });
  } catch (error) { return apiError(error); }
}
export async function POST(request: Request) {
  try {
    const token = await sessionToken();
    const body = await readBody(request);
    const name = typeof body.name === "string" ? body.name.trim() : "";
    if (!name || name.length > 80) throw new Error("Choose a world name between 1 and 80 characters");
    validateSnapshot(body.snapshot);
    const parentId = typeof body.parentId === "string" ? body.parentId : null;
    if (parentId) {
      if (!validId(parentId)) throw new Error("Invalid parent world");
      const [parent] = await db.select({ id: worlds.id }).from(worlds).where(and(eq(worlds.id, parentId), or(eq(worlds.ownerToken, token), eq(worlds.visibility, "public")))).limit(1);
      if (!parent) throw new Error("Parent world is unavailable");
    }
    const [count] = await db.select({ total: sql<number>`count(*)::int` }).from(worlds).where(eq(worlds.ownerToken, token));
    if (count.total >= 100) throw new Error("This studio has reached its 100-world limit");
    const snapshot = body.snapshot;
    const row = await db.transaction(async tx => {
      const [saved] = await tx.insert(worlds).values({ ownerToken: token, name, snapshot, parentId, visibility: body.visibility === "public" ? "public" : "private" }).returning();
      await tx.insert(worldRevisions).values({ worldId: saved.id, version: 1, snapshot, message: parentId ? "Branched from parent world" : "World created" });
      return saved;
    });
    return NextResponse.json({ world: serializeWorld(row, token) }, { status: 201 });
  } catch (error) { return apiError(error); }
}
