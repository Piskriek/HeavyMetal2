import type { Metadata } from "next";
import "../handoff.css";
import Link from "next/link";
import { AGREEMENTS, BUDGETS, BUILT, MARKETING, REPO, TASKS, TRUTH } from "@/lib/handoff";

export const metadata: Metadata = {
  title: "HeavyMetal² — Agent handoff & feature brief",
  description: "Everything a new agent needs to pick up HeavyMetal², plus the full feature summary.",
};

const SIZE_LABEL: Record<string, string> = { S: "Small", M: "Medium", L: "Large" };

export default function HandoffPage() {
  return (
    <main className="handoff">
      <header className="ho-head">
        <div className="ho-head-inner">
          <div>
            <div className="ho-eyebrow">AGENT HANDOFF · HEAVYMETAL²</div>
            <h1>Pick this up and keep building.</h1>
            <p>
              A procedural world studio where every rock, leaf, texture, goblin part — and the
              interface itself — is a preset you can enter, sculpt, paint, fork and share.
              This page is the complete brief: what exists, what is honestly unfinished,
              and exactly what to do next.
            </p>
          </div>
          <nav className="ho-jump" aria-label="Sections">
            {[["truth", "Read first"], ["state", "What exists"], ["next", "Do next"], ["rules", "Agreements"], ["pitch", "The pitch"]].map(([id, label]) => (
              <a key={id} href={`#${id}`}>{label}</a>
            ))}
            <Link href="/" className="ho-back">Open the studio →</Link>
          </nav>
        </div>
      </header>

      <div className="ho-body">
        {/* ---------- Read first ---------- */}
        <section id="truth" className="ho-section">
          <h2><span className="ho-num">01</span>Read this before you touch anything</h2>
          <p className="ho-lede">
            Four facts that will waste days if you assume otherwise. None of them are blockers —
            they are just not what a reasonable person would guess.
          </p>
          <div className="ho-truths">
            {TRUTH.map(t => (
              <article key={t.label} className="ho-truth">
                <h3>{t.label}</h3>
                <p>{t.body}</p>
              </article>
            ))}
          </div>
          <div className="ho-repo">
            <div><span>REPOSITORY</span><a href={REPO.url} target="_blank" rel="noreferrer">{REPO.url}</a></div>
            <div><span>REFERENCED BRANCH</span><code>{REPO.branch}</code></div>
            <div><span>THIS WORKSPACE</span><code>{REPO.stack}</code></div>
          </div>
        </section>

        {/* ---------- What exists ---------- */}
        <section id="state" className="ho-section">
          <h2><span className="ho-num">02</span>What is actually built</h2>
          <p className="ho-lede">
            All of this runs today and is covered by <code>npm run verify</code> —
            typegen, TypeScript, a production build and 20 engine assertions.
          </p>
          <div className="ho-built">
            {BUILT.map(b => (
              <article key={b.area} className="ho-built-row">
                <h3>{b.area}</h3>
                <p>{b.detail}</p>
                <ul className="ho-files">{b.files.map(f => <li key={f}><code>{f}</code></li>)}</ul>
              </article>
            ))}
          </div>

          <h3 className="ho-sub">Hard budgets</h3>
          <p className="ho-lede ho-lede-tight">Real limits, not placeholders. Exceeding them throws rather than degrading silently.</p>
          <div className="ho-budgets">
            {BUDGETS.map(b => (
              <div key={b.limit}><strong>{b.value}</strong><span>{b.limit}</span></div>
            ))}
          </div>

          <h3 className="ho-sub">Getting it running</h3>
          <ol className="ho-steps">
            <li><code>npm install</code></li>
            <li>Set <code>DATABASE_URL</code> in <code>.env</code> (PostgreSQL)</li>
            <li><code>npx drizzle-kit push</code> — creates the nine <code>hm2_*</code> tables</li>
            <li><code>npm run dev</code>, or <code>npm run verify</code> before every claim of done</li>
          </ol>
        </section>

        {/* ---------- Do next ---------- */}
        <section id="next" className="ho-section">
          <h2><span className="ho-num">03</span>What to do next, in order</h2>
          <p className="ho-lede">
            Ordered by dependency, not excitement. Task 1 gates everything else;
            task 2 is the fastest visible win once it is unblocked.
          </p>
          <div className="ho-tasks">
            {TASKS.map(t => (
              <article key={t.n} className="ho-task">
                <div className="ho-task-head">
                  <span className="ho-task-n">{String(t.n).padStart(2, "0")}</span>
                  <h3>{t.title}</h3>
                  <span className={`ho-size size-${t.size}`}>{SIZE_LABEL[t.size]}</span>
                </div>
                <p className="ho-why"><strong>Why.</strong> {t.why}</p>
                <ol className="ho-how">{t.how.map(h => <li key={h}>{h}</li>)}</ol>
                <p className="ho-accept"><strong>Done when.</strong> {t.acceptance}</p>
                <ul className="ho-files">{t.touches.map(f => <li key={f}><code>{f}</code></li>)}</ul>
              </article>
            ))}
          </div>
        </section>

        {/* ---------- Agreements ---------- */}
        <section id="rules" className="ho-section">
          <h2><span className="ho-num">04</span>Working agreements</h2>
          <p className="ho-lede">These kept the codebase coherent across many sessions. Break them deliberately, not accidentally.</p>
          <div className="ho-rules">
            {AGREEMENTS.map(a => (
              <article key={a.rule}><h3>{a.rule}</h3><p>{a.detail}</p></article>
            ))}
          </div>
          <div className="ho-docs">
            <a href="/PLAN.md" target="_blank" rel="noreferrer"><strong>PLAN.md</strong><span>The single cohesive plan — status, ladder, roadmap</span></a>
            <a href="/ENGINEERING.md" target="_blank" rel="noreferrer"><strong>ENGINEERING.md</strong><span>Architecture deep-dive — graph, physics, sandboxing</span></a>
            <a href="/AUTHORING.md" target="_blank" rel="noreferrer"><strong>AUTHORING.md</strong><span>Preset authoring detail — brushes, recipes, bakes</span></a>
          </div>
        </section>

        {/* ---------- Marketing ---------- */}
        <section id="pitch" className="ho-section ho-pitch">
          <div className="ho-pitch-head">
            <div className="ho-eyebrow">THE PITCH</div>
            <h2 className="ho-pitch-title">{MARKETING.headline}</h2>
            <p className="ho-pitch-sub">{MARKETING.sub}</p>
          </div>
          <div className="ho-features">
            {MARKETING.features.map((f, i) => (
              <article key={f.name} className="ho-feature">
                <span className="ho-feature-n">{String(i + 1).padStart(2, "0")}</span>
                <h3>{f.name}</h3>
                <p>{f.pitch}</p>
              </article>
            ))}
          </div>
          <p className="ho-closer">{MARKETING.closer}</p>
        </section>
      </div>

      <footer className="ho-foot">
        <span>HeavyMetal² · agent handoff</span>
        <Link href="/">Open the studio →</Link>
      </footer>
    </main>
  );
}
