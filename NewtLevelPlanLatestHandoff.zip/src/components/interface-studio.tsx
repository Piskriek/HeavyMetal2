"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Check, Copy, Upload, X } from "lucide-react";
import UIIcon from "./ui-icon";
import { ICON_SETS, ICON_SET_IDS, type IconName, type IconSetId } from "@/lib/engine/icon-sets";
import {
  DEFAULT_INTERFACE, INTERFACE_PRESETS, decodeInterface, encodeInterface,
  normaliseInterface, type InterfaceDensity, type InterfaceRecipe,
} from "@/lib/engine/interface-preset";

interface Props {
  recipe: InterfaceRecipe;
  onChange: (next: InterfaceRecipe) => void;
  onClose: () => void;
  notify: (msg: string, err?: boolean) => void;
}

const PREVIEW_ICONS: IconName[] = ["select", "brush", "carve", "rail", "walk", "shape", "texture", "tree", "goblin", "network", "share", "save"];

function Row({ label, value, min, max, step = 0.01, onChange, format }: {
  label: string; value: number; min: number; max: number; step?: number;
  onChange: (v: number) => void; format?: (v: number) => string;
}) {
  const id = `ui-${label.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`;
  return (
    <div className="slider-field author-range">
      <label htmlFor={id}>{label}<span>{format ? format(value) : value.toFixed(2)}</span></label>
      <input id={id} type="range" min={min} max={max} step={step} value={value}
        style={{ "--range-fill": `${((value - min) / (max - min)) * 100}%` } as React.CSSProperties}
        onChange={e => onChange(Number(e.target.value))} />
    </div>
  );
}

export default function InterfaceStudio({ recipe, onChange, onClose, notify }: Props) {
  const [tab, setTab] = useState<"sculpt" | "paint" | "share">("sculpt");
  const [importCode, setImportCode] = useState("");
  const [copied, setCopied] = useState(false);
  const r = normaliseInterface(recipe);
  const code = useMemo(() => encodeInterface(r), [r]);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const key = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, [onClose]);

  const set = (patch: Partial<InterfaceRecipe>) => onChange(normaliseInterface({ ...r, ...patch }));

  return (
    <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal wide interface-studio" role="dialog" aria-modal="true" aria-labelledby="ui-title" ref={ref}>
        <div className="modal-heading">
          <div>
            <div className="eyebrow lime">THE INTERFACE IS A PRESET</div>
            <h2 id="ui-title">Sculpt it. Paint it. Share it.</h2>
            <p>Icon geometry, stroke weight, density, hairlines and colour are one recipe — the same contract as a leaf or a goblin. Share it as a code and someone else wears your workshop.</p>
          </div>
          <button type="button" className="icon-button" aria-label="Close interface studio" onClick={onClose}><X size={19} /></button>
        </div>

        <div className="guide-tabs">
          {([["sculpt", "Sculpt"], ["paint", "Paint"], ["share", "Share"]] as const).map(([id, label]) => (
            <button key={id} type="button" className={tab === id ? "active" : ""} onClick={() => setTab(id)}>{label}</button>
          ))}
        </div>

        {/* Live specimen — always visible, reacts to every change */}
        <div className="ui-specimen" aria-label="Live icon specimen">
          {PREVIEW_ICONS.map(name => (
            <span key={name} className="ui-specimen-cell" title={name}>
              <UIIcon name={name} set={r.iconSet} size={20} weight={r.iconWeight} round={r.iconRound} />
            </span>
          ))}
        </div>

        <div className="guide-content">
          {tab === "sculpt" && (
            <>
              <div className="section-label">ICON SET</div>
              <div className="icon-set-grid">
                {ICON_SET_IDS.map(id => (
                  <button key={id} type="button" className={`icon-set-card ${r.iconSet === id ? "active" : ""}`} onClick={() => set({ iconSet: id, iconWeight: ICON_SETS[id].defaultWeight })}>
                    <span className="icon-set-row">
                      {(["brush", "tree", "goblin", "network"] as IconName[]).map(n => (
                        <UIIcon key={n} name={n} set={id} size={17} weight={ICON_SETS[id].defaultWeight} />
                      ))}
                    </span>
                    <strong>{ICON_SETS[id].name}</strong>
                    <small>{ICON_SETS[id].blurb}</small>
                  </button>
                ))}
              </div>
              <div className="section-label">GEOMETRY</div>
              <Row label="Icon weight" value={r.iconWeight} min={0.75} max={3.5} onChange={v => set({ iconWeight: v })} format={v => `${v.toFixed(2)} px`} />
              <Row label="Corner softness" value={r.iconRound} min={0} max={1} onChange={v => set({ iconRound: v })} format={v => (v > 0.5 ? "Round" : "Square")} />
              <Row label="Hairline" value={r.hairline} min={0.5} max={3} step={0.1} onChange={v => set({ hairline: v })} format={v => `${v.toFixed(1)} px`} />
              <Row label="Panel radius" value={r.radius} min={0} max={14} step={1} onChange={v => set({ radius: v })} format={v => (v === 0 ? "Flat cut-out" : `${v} px`)} />
              <div className="section-label">DENSITY</div>
              <div className="density-row">
                {(["compact", "regular", "roomy"] as InterfaceDensity[]).map(d => (
                  <button key={d} type="button" className={r.density === d ? "active" : ""} onClick={() => set({ density: d })}>{d}</button>
                ))}
              </div>
            </>
          )}

          {tab === "paint" && (
            <>
              <div className="section-label">SURFACES</div>
              <div className="ui-paint-grid">
                {([["surface", "Backdrop"], ["panel", "Panels"], ["ink", "Ink"], ["accent", "Accent"]] as const).map(([key, label]) => (
                  <label key={key} className="ui-paint-swatch">
                    <input type="color" aria-label={`${label} colour`} value={r[key]} onChange={e => set({ [key]: e.target.value } as Partial<InterfaceRecipe>)} />
                    <span><strong>{label}</strong><small>{r[key].toUpperCase()}</small></span>
                  </label>
                ))}
              </div>
              <Row label="Accent strength" value={r.accentStrength} min={0} max={1} onChange={v => set({ accentStrength: v })} format={v => `${Math.round(v * 100)}%`} />
              <Row label="Surface grain" value={r.grain} min={0} max={1} onChange={v => set({ grain: v })} format={v => (v < 0.05 ? "Clean enamel" : `${Math.round(v * 100)}%`)} />
              <div className="section-label">START FROM A SHIPPED PRESET</div>
              <div className="ui-preset-row">
                {INTERFACE_PRESETS.map(p => (
                  <button key={p.id} type="button" className="ui-preset-card" onClick={() => { onChange(p.recipe); notify(`${p.name} interface applied.`); }}>
                    <span className="ui-preset-chips">
                      <i style={{ background: p.recipe.surface }} />
                      <i style={{ background: p.recipe.panel }} />
                      <i style={{ background: p.recipe.ink }} />
                      <i style={{ background: p.recipe.accent }} />
                    </span>
                    <strong>{p.name}</strong>
                    <small>{p.blurb}</small>
                  </button>
                ))}
              </div>
            </>
          )}

          {tab === "share" && (
            <>
              <div className="section-label">YOUR INTERFACE CODE</div>
              <div className="share-code-row">
                <textarea className="text-input share-code-box" readOnly value={code} aria-label="Interface share code" onFocus={e => e.currentTarget.select()} />
                <div className="share-code-actions">
                  <span className="code-size">{code.length} chars</span>
                  <button type="button" className="button button-primary" onClick={async () => {
                    try { await navigator.clipboard.writeText(code); setCopied(true); setTimeout(() => setCopied(false), 2000); }
                    catch { notify("Select the code to copy it.", true); }
                  }}>{copied ? <Check size={13} /> : <Copy size={13} />}{copied ? "Copied" : "Copy"}</button>
                </div>
              </div>
              <div className="section-label">WEAR SOMEONE ELSE&rsquo;S</div>
              <div className="share-code-row">
                <textarea className="text-input share-code-box" placeholder="HM2UI-…" value={importCode} onChange={e => setImportCode(e.target.value)} aria-label="Paste interface code" />
                <div className="share-code-actions">
                  <button type="button" className="button button-secondary" disabled={!importCode.trim()} onClick={() => {
                    try { onChange(decodeInterface(importCode)); setImportCode(""); notify("Interface preset applied."); }
                    catch (error) { notify((error as Error).message, true); }
                  }}><Upload size={13} />Apply</button>
                </div>
              </div>
              <p className="chain-hint">
                An interface code is one line. It carries the icon set, every sculpted value and every painted colour — nothing else, so it stays safe to paste anywhere.
              </p>
            </>
          )}
        </div>

        <div className="modal-footer">
          <button type="button" className="button button-secondary" onClick={() => { onChange(DEFAULT_INTERFACE); notify("Interface reset to Compact Build."); }}>Reset</button>
          <button type="button" className="button button-primary" onClick={onClose}>Done</button>
        </div>
      </div>
    </div>
  );
}
