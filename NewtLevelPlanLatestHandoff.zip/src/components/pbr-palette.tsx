"use client";

import { useEffect, useRef, useState } from "react";
import { paletteSwatch, SHOWCASE_MATERIALS, type ShowcaseMaterialId } from "@/lib/engine/pbr-showcase";
import { MATERIAL_WEDGES, materialSwatch, type SwatchKind } from "@/lib/engine/swatches";

export interface PaletteEntry {
  id: string;
  name: string;
  blurb: string;
  url: string;
  kind: "showcase" | "wedge";
}

interface Props {
  activeId: string | null;
  onPick: (entry: PaletteEntry) => void;
  collapsed?: boolean;
  onToggle?: () => void;
}

/**
 * The paint holder: a physical-feeling palette of PBR materials.
 * Swatches are rendered from the same generators that texture the scene,
 * so what you click is genuinely what you get.
 */
export default function PbrPalette({ activeId, onPick, collapsed = false, onToggle }: Props) {
  const [entries, setEntries] = useState<PaletteEntry[]>([]);
  const built = useRef(false);

  useEffect(() => {
    if (built.current) return;
    built.current = true;
    const showcase: PaletteEntry[] = SHOWCASE_MATERIALS.map(m => ({
      id: m.id,
      name: m.name,
      blurb: m.blurb,
      url: paletteSwatch(m.id as ShowcaseMaterialId, 112).toDataURL("image/png"),
      kind: "showcase",
    }));
    const wedges: PaletteEntry[] = MATERIAL_WEDGES.map(w => ({
      id: w.id,
      name: w.name,
      blurb: w.scope,
      url: materialSwatch(w.id as SwatchKind, 112).toDataURL("image/png"),
      kind: "wedge",
    }));
    setEntries([...showcase, ...wedges]);
  }, []);

  return (
    <aside className={`pbr-palette ${collapsed ? "collapsed" : ""}`} aria-label="PBR material palette">
      <button type="button" className="palette-grip" onClick={onToggle} aria-expanded={!collapsed}>
        <span className="palette-grip-dots" aria-hidden="true"><i /><i /><i /></span>
        <span className="palette-grip-label">Materials</span>
      </button>

      <div className="palette-body">
        <div className="palette-section-label">SCENE PBR</div>
        <div className="palette-wells">
          {entries.filter(e => e.kind === "showcase").map(e => (
            <button
              key={e.id}
              type="button"
              className={`palette-well ${activeId === e.id ? "active" : ""}`}
              title={`${e.name} — ${e.blurb}`}
              onClick={() => onPick(e)}
            >
              <span className="palette-blob" style={{ backgroundImage: `url(${e.url})` }} />
              <span className="palette-name">{e.name}</span>
            </button>
          ))}
        </div>

        <div className="palette-section-label">QUICK MATERIALS</div>
        <div className="palette-wells compact">
          {entries.filter(e => e.kind === "wedge").map(e => (
            <button
              key={e.id}
              type="button"
              className={`palette-well ${activeId === e.id ? "active" : ""}`}
              title={`${e.name} — ${e.blurb}`}
              onClick={() => onPick(e)}
            >
              <span className="palette-blob" style={{ backgroundImage: `url(${e.url})` }} />
              <span className="palette-name">{e.name}</span>
            </button>
          ))}
        </div>

        <p className="palette-note">
          Low-poly PBR set from the art pipeline drops into these wells next — same slots, higher fidelity.
        </p>
      </div>
    </aside>
  );
}
