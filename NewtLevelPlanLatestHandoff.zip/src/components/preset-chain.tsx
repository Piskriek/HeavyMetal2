"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Boxes, Check, Copy, Download, Gift, LoaderCircle, Share2, Sparkles, Upload, X } from "lucide-react";
import { PRIMITIVES, makePresetPackage, type EditablePreset, type PrimitiveKind, type SavedPreset } from "@/lib/engine/authoring";
import { decodeShareCode, encodeShareCode, shareCodeSize } from "@/lib/engine/share-codes";
import type { WorldSnapshot } from "@/lib/engine/types";

export interface ShareProfile {
  handle: string;
  autoShare: boolean;
  shareOnEntry: boolean;
  shareWhenTalking: boolean;
  sharesGiven: number;
  remixCredits: number;
  scrapFromSharing: number;
}

interface Props {
  snapshot: WorldSnapshot;
  nodeId: string;
  onClose: () => void;
  onPickPrimitive: (primitive: PrimitiveKind) => void;
  onImportPackage: (pkg: ReturnType<typeof makePresetPackage>, name: string) => void;
  notify: (msg: string, err?: boolean) => void;
}

export default function PresetChainPanel({ snapshot, nodeId, onClose, onPickPrimitive, onImportPackage, notify }: Props) {
  const [tab, setTab] = useState<"chain" | "share" | "settings">("chain");
  const [profile, setProfile] = useState<ShareProfile | null>(null);
  const [community, setCommunity] = useState<SavedPreset[]>([]);
  const [busy, setBusy] = useState(false);
  const [code, setCode] = useState("");
  const [importCode, setImportCode] = useState("");
  const [copied, setCopied] = useState(false);
  const preset: EditablePreset | undefined = snapshot.authoring?.presets[nodeId];
  const loaded = useRef(false);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/presets?scope=community");
      if (!res.ok) return;
      const data = await res.json();
      setCommunity(data.presets ?? []);
      if (data.profile) setProfile(data.profile);
    } catch { /* offline is fine */ }
  }, []);

  useEffect(() => { if (!loaded.current) { loaded.current = true; void refresh(); } }, [refresh]);

  useEffect(() => {
    if (!preset || !snapshot.authoring) return;
    try { setCode(encodeShareCode(makePresetPackage(snapshot, preset.id))); } catch { setCode(""); }
  }, [preset, snapshot]);

  const saveSettings = async (patch: Partial<ShareProfile>) => {
    const next = { ...(profile ?? { handle: "Goblin builder", autoShare: false, shareOnEntry: false, shareWhenTalking: true, sharesGiven: 0, remixCredits: 0, scrapFromSharing: 0 }), ...patch };
    setProfile(next);
    try {
      const res = await fetch("/api/presets", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "settings", ...patch }) });
      if (res.ok) {
        const data = await res.json();
        if (data.profile) setProfile(data.profile);
        notify(patch.autoShare !== undefined && patch.autoShare ? "Auto-share on. Every preset you save goes public and earns Scrap." : "Share settings saved.");
      }
    } catch { notify("Could not save share settings", true); }
  };

  const copyCode = async () => {
    try { await navigator.clipboard.writeText(code); setCopied(true); setTimeout(() => setCopied(false), 2200); }
    catch { notify("Select the code below to copy it.", true); }
  };

  const applyImport = () => {
    try {
      const pkg = decodeShareCode(importCode);
      onImportPackage(pkg, pkg.presets[pkg.rootId]?.name ?? "Shared preset");
      setImportCode("");
      notify("Preset code decoded and loaded into your branch.");
    } catch (error) { notify((error as Error).message, true); }
  };

  const usePreset = async (p: SavedPreset, remix: boolean) => {
    setBusy(true);
    try {
      const res = await fetch("/api/presets", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: remix ? "remix" : "use", presetId: p.id }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onImportPackage(p.package, p.name);
      notify(data.reward ? `Loaded "${p.name}". ${p.authorHandle ?? "The author"} earned +${data.reward} Scrap for sharing.` : `Loaded "${p.name}".`);
      void refresh();
    } catch (error) { notify((error as Error).message, true); }
    finally { setBusy(false); }
  };

  const chain = snapshot.authoring
    ? ["shape", "texture", "object", "wood", "leaf", "tree"].map(kind => {
        const match = Object.values(snapshot.authoring!.presets).find(p => p.kind === kind);
        return { kind, name: match?.name ?? "—", id: match?.id };
      })
    : [];

  return (
    <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal wide preset-chain-modal" role="dialog" aria-modal="true" aria-labelledby="chain-title">
        <div className="modal-heading">
          <div>
            <div className="eyebrow lime">EVERYTHING IS A PRESET</div>
            <h2 id="chain-title">Cube to canopy. Click by click.</h2>
            <p>Start from a raw primitive, add a material, save it as an object, then compose objects into branches, trees and worlds. Every step is a preset you can share as one compact code.</p>
          </div>
          <button type="button" className="icon-button" aria-label="Close dialog" onClick={onClose}><X size={19} /></button>
        </div>

        <div className="guide-tabs">
          {([["chain", "Build chain"], ["share", "Share & remix"], ["settings", "Share settings"]] as const).map(([id, label]) => (
            <button key={id} type="button" className={tab === id ? "active" : ""} onClick={() => setTab(id)}>{label}</button>
          ))}
          {profile && (
            <span className="share-reward-pill" title="Scrap earned by sharing presets">
              <Gift size={12} />{profile.scrapFromSharing} Scrap · {profile.sharesGiven} shared
            </span>
          )}
        </div>

        <div className="guide-content">
          {tab === "chain" && (
            <>
              <div className="chain-rail" aria-label="Preset composition chain">
                {chain.map((step, i) => (
                  <div key={step.kind} className="chain-step">
                    <span className="chain-index">{i + 1}</span>
                    <strong>{step.kind}</strong>
                    <small>{step.name}</small>
                  </div>
                ))}
              </div>
              <div className="section-label">START FROM A RAW PRIMITIVE</div>
              <div className="primitive-grid">
                {PRIMITIVES.map(prim => (
                  <button key={prim.id} type="button" className="primitive-card" onClick={() => { onPickPrimitive(prim.id); onClose(); }}>
                    <span className={`primitive-glyph glyph-${prim.id}`} aria-hidden="true" />
                    <strong>{prim.name}</strong>
                    <small>{prim.blurb}</small>
                  </button>
                ))}
              </div>
              <p className="chain-hint">
                <Sparkles size={13} />
                Pick a shape, apply a texture preset, tweak it, then <strong>Save as new preset</strong>. Your saved object becomes a click-to-use building block for branches and trees.
              </p>
            </>
          )}

          {tab === "share" && (
            <>
              <div className="section-label">COMPACT SHARE CODE · {preset?.name ?? "current preset"}</div>
              <div className="share-code-row">
                <textarea className="text-input share-code-box" readOnly value={code} aria-label="Preset share code" onFocus={e => e.currentTarget.select()} />
                <div className="share-code-actions">
                  <span className="code-size">{code ? `${(shareCodeSize(code) / 1024).toFixed(1)} KB` : "—"}</span>
                  <button type="button" className="button button-primary" onClick={copyCode} disabled={!code}>
                    {copied ? <Check size={13} /> : <Copy size={13} />}{copied ? "Copied" : "Copy code"}
                  </button>
                </div>
              </div>
              <div className="section-label">PASTE A CODE TO LOAD IT</div>
              <div className="share-code-row">
                <textarea className="text-input share-code-box" placeholder="HM2-…" value={importCode} onChange={e => setImportCode(e.target.value)} aria-label="Paste preset share code" />
                <div className="share-code-actions">
                  <button type="button" className="button button-secondary" onClick={applyImport} disabled={!importCode.trim()}>
                    <Upload size={13} />Load preset
                  </button>
                </div>
              </div>
              <div className="section-label">COMMUNITY PRESETS · CLICK TO USE</div>
              <div className="community-preset-list">
                {community.length === 0 && <p className="chain-hint">No shared presets yet. Publish one and you will be first.</p>}
                {community.map(p => (
                  <div key={p.id} className="community-preset-row">
                    <span className="community-kind">{p.kind}</span>
                    <div>
                      <strong>{p.name}</strong>
                      <small>by {p.authorHandle ?? "Goblin builder"} · {p.useCount ?? 0} uses · {p.remixCount ?? 0} remixes</small>
                    </div>
                    <button type="button" className="button button-secondary" disabled={busy} onClick={() => usePreset(p, false)}>
                      {busy ? <LoaderCircle size={12} className="spin" /> : <Download size={12} />}Use
                    </button>
                    <button type="button" className="button button-primary" disabled={busy} onClick={() => usePreset(p, true)}>
                      <Boxes size={12} />Remix
                    </button>
                  </div>
                ))}
              </div>
            </>
          )}

          {tab === "settings" && (
            <>
              <div className="share-incentive-banner">
                <Gift size={20} />
                <div>
                  <strong>Sharing pays.</strong>
                  <p>+40 Scrap when you publish a preset · +15 every time someone uses it · +35 every time someone remixes it. Remix credits unlock island space.</p>
                </div>
                {profile && <span className="share-stat">{profile.scrapFromSharing}<small>SCRAP EARNED</small></span>}
              </div>
              <label className="form-label" htmlFor="share-handle">AUTHOR HANDLE</label>
              <input
                id="share-handle"
                className="text-input"
                value={profile?.handle ?? ""}
                placeholder="Goblin builder"
                onChange={e => setProfile(p => ({ ...(p ?? { autoShare: false, shareOnEntry: false, shareWhenTalking: true, sharesGiven: 0, remixCredits: 0, scrapFromSharing: 0 }), handle: e.target.value } as ShareProfile))}
                onBlur={e => saveSettings({ handle: e.target.value })}
              />
              <div className="share-toggle-list">
                {([
                  ["autoShare", "Auto-share my presets", "Every preset you save is published publicly and starts earning Scrap immediately."],
                  ["shareOnEntry", "Share on entry", "When you arrive on a planet, your newest presets are offered to everyone there."],
                  ["shareWhenTalking", "Share when talking", "Attach your active preset to chat messages so people can click to use it."],
                ] as const).map(([key, title, blurb]) => (
                  <div key={key} className="share-toggle-row">
                    <div>
                      <strong>{title}</strong>
                      <small>{blurb}</small>
                    </div>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={Boolean(profile?.[key])}
                      aria-label={title}
                      className={`toggle ${profile?.[key] ? "on" : ""}`}
                      onClick={() => saveSettings({ [key]: !profile?.[key] } as Partial<ShareProfile>)}
                    >
                      <span />
                    </button>
                  </div>
                ))}
              </div>
              {profile && (
                <div className="share-stats-grid">
                  <div><strong>{profile.sharesGiven}</strong><small>PRESETS SHARED</small></div>
                  <div><strong>{profile.remixCredits}</strong><small>REMIX CREDITS</small></div>
                  <div><strong>{profile.scrapFromSharing}</strong><small>SCRAP FROM SHARING</small></div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
