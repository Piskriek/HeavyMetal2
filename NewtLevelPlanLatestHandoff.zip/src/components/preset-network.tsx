"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Crosshair, Minus, Pencil, Plus, X } from "lucide-react";
import type { EditablePreset, PresetKind } from "@/lib/engine/authoring";
import type { WorldSnapshot } from "@/lib/engine/types";

interface Props {
  snapshot: WorldSnapshot;
  activeId: string;
  onEnter: (id: string) => void;
  onClose: () => void;
}

interface Placed {
  preset: EditablePreset;
  x: number;
  y: number;
  depth: number;
}

/** Depth columns: the chain reads left (raw) to right (composed). */
const DEPTH_OF: Record<PresetKind, number> = {
  texture: 0, shape: 1, object: 2, part: 2, wood: 3, leaf: 3, goblin: 4, tree: 4,
};
const COL_W = 196;
const ROW_H = 92;

export default function PresetNetwork({ snapshot, activeId, onEnter, onClose }: Props) {
  const [zoom, setZoom] = useState(0.92);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [hover, setHover] = useState<string | null>(null);
  const drag = useRef<{ x: number; y: number; px: number; py: number } | null>(null);
  const state = snapshot.authoring;

  const { placed, links, bounds } = useMemo(() => {
    const presets = Object.values(state?.presets ?? {});
    const columns = new Map<number, EditablePreset[]>();
    for (const p of presets) {
      const d = DEPTH_OF[p.kind] ?? 2;
      if (!columns.has(d)) columns.set(d, []);
      columns.get(d)!.push(p);
    }
    const out: Record<string, Placed> = {};
    let maxRows = 0;
    for (const [depth, list] of [...columns.entries()].sort((a, b) => a[0] - b[0])) {
      list.sort((a, b) => a.name.localeCompare(b.name));
      maxRows = Math.max(maxRows, list.length);
      list.forEach((preset, row) => {
        out[preset.id] = { preset, depth, x: depth * COL_W, y: row * ROW_H - ((list.length - 1) * ROW_H) / 2 };
      });
    }
    // Edges follow real graph dependencies, so this is the live network
    const edges: { from: Placed; to: Placed; active: boolean }[] = [];
    for (const node of Object.values(snapshot.graph.nodes)) {
      const parent = out[node.id];
      if (!parent) continue;
      for (const ref of node.children) {
        const child = out[ref.nodeId];
        if (!child) continue;
        edges.push({ from: child, to: parent, active: node.id === activeId || ref.nodeId === activeId });
      }
    }
    const depths = [...columns.keys()];
    return {
      placed: out,
      links: edges,
      bounds: { w: (Math.max(...depths, 0) + 1) * COL_W, h: Math.max(maxRows, 1) * ROW_H },
    };
  }, [state, snapshot.graph, activeId]);

  // Frame the active preset when the network opens
  useEffect(() => {
    const node = placed[activeId];
    if (node) setPan({ x: -node.x + bounds.w / 4, y: -node.y });
  }, [activeId, placed, bounds]);

  const onWheel = useCallback((e: React.WheelEvent) => {
    setZoom(z => Math.max(0.4, Math.min(2.2, z - e.deltaY * 0.0012)));
  }, []);

  // Keep the graph reachable: never let it drift fully outside the canvas
  const clampPan = useCallback((next: { x: number; y: number }) => {
    const limitX = bounds.w / 2 + 260;
    const limitY = bounds.h / 2 + 200;
    return { x: Math.max(-limitX, Math.min(limitX, next.x)), y: Math.max(-limitY, Math.min(limitY, next.y)) };
  }, [bounds]);

  useEffect(() => {
    const key = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, [onClose]);

  if (!state) return null;

  return (
    <div className="network-overlay" role="dialog" aria-modal="true" aria-label="Preset network">
      <div className="network-head">
        <div>
          <div className="eyebrow lime">BRANCHING PRESET NETWORK</div>
          <h2>Move through the chain. Edit live.</h2>
        </div>
        <div className="network-head-actions">
          <button type="button" className="icon-button" aria-label="Zoom out" onClick={() => setZoom(z => Math.max(0.4, z - 0.18))}><Minus size={16} /></button>
          <span className="network-zoom">{Math.round(zoom * 100)}%</span>
          <button type="button" className="icon-button" aria-label="Zoom in" onClick={() => setZoom(z => Math.min(2.2, z + 0.18))}><Plus size={16} /></button>
          <button type="button" className="icon-button" aria-label="Recentre on active preset" onClick={() => { const n = placed[activeId]; if (n) { setPan({ x: -n.x + bounds.w / 4, y: -n.y }); setZoom(0.92); } }}><Crosshair size={16} /></button>
          <button type="button" className="icon-button" aria-label="Close preset network" onClick={onClose}><X size={18} /></button>
        </div>
      </div>

      <div
        className="network-canvas"
        onWheel={onWheel}
        onPointerDown={e => { drag.current = { x: e.clientX, y: e.clientY, px: pan.x, py: pan.y }; (e.target as HTMLElement).setPointerCapture?.(e.pointerId); }}
        onPointerMove={e => {
          if (!drag.current) return;
          setPan(clampPan({ x: drag.current.px + (e.clientX - drag.current.x) / zoom, y: drag.current.py + (e.clientY - drag.current.y) / zoom }));
        }}
        onPointerUp={() => { drag.current = null; }}
        onPointerLeave={() => { drag.current = null; }}
      >
        <div className="network-world" style={{ transform: `scale(${zoom}) translate(${pan.x}px, ${pan.y}px)` }}>
          <svg
            className="network-links"
            width={bounds.w + COL_W * 2}
            height={bounds.h + ROW_H * 2}
            viewBox={`${-COL_W} ${-(bounds.h / 2) - ROW_H} ${bounds.w + COL_W * 2} ${bounds.h + ROW_H * 2}`}
            style={{ left: -COL_W, top: -(bounds.h / 2) - ROW_H }}
          >
            {links.map((l, i) => {
              const x1 = l.from.x + 68, y1 = l.from.y;
              const x2 = l.to.x - 68, y2 = l.to.y;
              const mid = (x1 + x2) / 2;
              return (
                <path
                  key={i}
                  d={`M ${x1} ${y1} C ${mid} ${y1}, ${mid} ${y2}, ${x2} ${y2}`}
                  className={l.active ? "network-link active" : "network-link"}
                />
              );
            })}
          </svg>
          {Object.values(placed).map(node => {
            const isActive = node.preset.id === activeId;
            return (
              <div
                key={node.preset.id}
                className={`network-node ${isActive ? "active" : ""} ${hover === node.preset.id ? "hover" : ""}`}
                style={{ transform: `translate(${node.x}px, ${node.y}px)` }}
                onMouseEnter={() => setHover(node.preset.id)}
                onMouseLeave={() => setHover(null)}
                onDoubleClick={() => { onEnter(node.preset.id); onClose(); }}
              >
                <span className="network-kind">{node.preset.kind}</span>
                <strong>{node.preset.name}</strong>
                <small>r{node.preset.revision} · {node.preset.marks.length} edits</small>
                <button
                  type="button"
                  className="network-edit"
                  onClick={e => { e.stopPropagation(); onEnter(node.preset.id); onClose(); }}
                >
                  <Pencil size={11} />Edit
                </button>
              </div>
            );
          })}
        </div>
      </div>

      <div className="network-foot">
        <span>Drag to pan · Scroll to zoom · Double-click a node to jump in</span>
        <span className="network-legend">
          {["texture", "shape", "object", "wood · leaf", "tree · goblin"].map((l, i) => (
            <em key={l}><i>{i}</i>{l}</em>
          ))}
        </span>
      </div>
    </div>
  );
}
