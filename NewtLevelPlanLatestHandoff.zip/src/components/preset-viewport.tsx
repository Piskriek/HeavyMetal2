"use client";
import { useEffect, useRef, useState, type RefObject } from "react";
import { PresetScene, type PresetSceneOptions } from "@/lib/engine/preset-scene";
import type { GoblinPart, SurfaceMark } from "@/lib/engine/authoring";
import type { WorldSnapshot } from "@/lib/engine/types";

export interface PresetViewportHandle { reset: () => void; zoom: (direction: number) => void; }
interface Props {
  snapshot: WorldSnapshot;
  options: PresetSceneOptions;
  apiRef: RefObject<PresetViewportHandle | null>;
  onMark: (id: string, mark: SurfaceMark) => void;
  onPartTransform: (id: string, part: GoblinPart) => void;
  onMetrics: (triangles: number, fps: number) => void;
}
export default function PresetViewport(props: Props) {
  const mount = useRef<HTMLDivElement>(null), engine = useRef<PresetScene | null>(null), latest = useRef(props); latest.current = props;
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    if (!mount.current) return;
    try {
      const p = latest.current;
      const instance = new PresetScene(mount.current, p.snapshot, p.options, { onMark: (id, mark) => latest.current.onMark(id, mark), onPartTransform: (id, part) => latest.current.onPartTransform(id, part), onMetrics: (triangles, fps) => latest.current.onMetrics(triangles, fps) }); engine.current = instance;
      p.apiRef.current = { reset: () => instance.reset(), zoom: direction => instance.zoom(direction) };
      return () => { instance.dispose(); engine.current = null; p.apiRef.current = null; };
    } catch (cause) { console.error(cause); setError("This device cannot start WebGL. Recipe editing and saving are still available."); }
  }, []);
  useEffect(() => { engine.current?.update(props.snapshot, props.options); }, [props.snapshot, props.options]);
  return <div ref={mount} className="webgl-mount preset-webgl">{error && <div className="preset-webgl-error">{error}</div>}</div>;
}
