"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowRight, Pencil } from "lucide-react";
import { swatchDataUrl } from "@/lib/engine/swatches";
import { shelfForContext, suggestNextBrush, suggestNextPreset, type ShelfEntry } from "@/lib/engine/brush-context";
import type { AuthorTool, EditablePreset, PresetKind, TexturePattern } from "@/lib/engine/authoring";

interface Props {
  kind: PresetKind;
  tool: AuthorTool;
  preset: EditablePreset;
  activePattern?: TexturePattern | null;
  onApply: (entry: ShelfEntry) => void;
  onNextBrush: (tool: AuthorTool) => void;
  onEditChild: (kind: PresetKind) => void;
}

/** Context shelf: materials that make sense here, plus the logical next brush (E). */
export default function QuickShelf({ kind, tool, preset, activePattern, onApply, onNextBrush, onEditChild }: Props) {
  const entries = shelfForContext(kind, tool);
  const next = suggestNextBrush(kind, tool, preset);
  const nextPreset = suggestNextPreset(kind);
  const [swatches, setSwatches] = useState<Record<string, string>>({});
  const cache = useRef<Record<string, string>>({});

  useEffect(() => {
    const out: Record<string, string> = { ...cache.current };
    for (const e of entries) {
      if (!out[e.swatch]) out[e.swatch] = swatchDataUrl(e.swatch, 72);
    }
    cache.current = out;
    setSwatches(out);
  }, [entries]);

  // E cycles to the suggested next brush
  useEffect(() => {
    const key = (event: KeyboardEvent) => {
      if (event.key.toLowerCase() !== "e" || event.ctrlKey || event.metaKey || event.altKey) return;
      const target = event.target as Element | null;
      // `target` can be `document` when focus was removed by a drawer re-render
      if (target && typeof target.matches === "function" && target.matches("input,textarea,select")) return;
      event.preventDefault();
      onNextBrush(next.tool);
    };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, [next.tool, onNextBrush]);

  return (
    <div className="quick-shelf" role="region" aria-label="Quick materials shelf">
      <div className="shelf-head">
        <span className="eyebrow">{kind.toUpperCase()} SHELF</span>
        {nextPreset && (
          <button type="button" className="shelf-edit-child" onClick={() => onEditChild(nextPreset.kind)} title={nextPreset.reason}>
            <Pencil size={10} />Edit {nextPreset.kind}
          </button>
        )}
      </div>
      <div className="shelf-strip">
        {entries.map(entry => (
          <button
            key={entry.id}
            type="button"
            className={`shelf-chip ${activePattern && entry.pattern === activePattern ? "active" : ""}`}
            title={entry.hint}
            onClick={() => onApply(entry)}
          >
            <span className="shelf-swatch" style={{ backgroundImage: swatches[entry.swatch] ? `url(${swatches[entry.swatch]})` : undefined }} />
            <span>{entry.label}</span>
          </button>
        ))}
      </div>
      <button type="button" className="shelf-next" onClick={() => onNextBrush(next.tool)}>
        <kbd>E</kbd>
        <span><strong>{next.tool}</strong>{next.reason}</span>
        <ArrowRight size={12} />
      </button>
    </div>
  );
}
