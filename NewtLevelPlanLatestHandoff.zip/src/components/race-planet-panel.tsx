"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Award, Check, Coins, Code2, Compass, Crown, Eye, Flame, Footprints, GitBranch, Globe2,
  HeartHandshake, Layers3, Megaphone, MessageSquare, Plus, RotateCcw, Send, ShieldAlert,
  Sparkles, ThumbsUp, Trophy, Users, Waves, Zap, X,
} from "lucide-react";
import {
  DEFAULT_ECONOMY, MAJORITY_RULES, RACER_ROSTER,
  type AvatarStatus, type IslandEconomy, type MajorityRuleId, type WorldSnapshot,
} from "@/lib/engine/types";

export interface LeaderboardRow {
  id: string;
  goblinName: string;
  wins: number;
  scrapEarned: number;
  chinHits: number;
  islandScale: string;
}
export interface PlanetChatRow {
  id: string;
  sender: string;
  message: string;
  presetName: string | null;
  presetKind: string | null;
  createdAt: string;
}
export interface CommunityModRow {
  id: string;
  title: string;
  author: string;
  hookTarget: string;
  description: string;
  configJson: Record<string, string | number | boolean>;
  upvotes: number;
}

interface Props {
  snapshot: WorldSnapshot;
  avatar: AvatarStatus;
  playing: boolean;
  activeBet: { riderId: string; amount: number } | null;
  activeMods: string[];
  hubModal: "planet" | "expand" | "mods" | null;
  onCloseModal: () => void;
  onOpenModal: (modal: "planet" | "expand" | "mods") => void;
  onUpdateEconomy: (updater: (prev: IslandEconomy) => IslandEconomy) => void;
  onPlaceBet: (riderId: string, amount: number) => void;
  onTogglePlay: (play: boolean) => void;
  onSpawnSurface: (mode?: "third" | "first") => void;
  onCheer: (riderId?: string) => void;
  onStepOntoTrack: () => void;
  onRespawn: () => void;
  onToggleMod: (modTitle: string, modConfig: Record<string, string | number | boolean>, hookTarget: string) => void;
  onEnterGoblinLab: () => void;
  notify: (msg: string, err?: boolean) => void;
}

export default function RacePlanetOverlay({
  snapshot,
  avatar,
  playing,
  activeBet,
  activeMods,
  hubModal,
  onCloseModal,
  onOpenModal,
  onUpdateEconomy,
  onPlaceBet,
  onTogglePlay,
  onSpawnSurface,
  onCheer,
  onStepOntoTrack,
  onRespawn,
  onToggleMod,
  onEnterGoblinLab,
  notify,
}: Props) {
  const economy = snapshot.economy ?? DEFAULT_ECONOMY;
  const [leaderboard, setLeaderboard] = useState<LeaderboardRow[]>([]);
  const [chat, setChat] = useState<PlanetChatRow[]>([]);
  const [votes, setVotes] = useState<Record<string, number>>({});
  const [mods, setMods] = useState<CommunityModRow[]>([]);
  const [planetTab, setPlanetTab] = useState<"race" | "rules" | "chat" | "leaderboard">("race");
  const [chatInput, setChatInput] = useState("");
  const [attachPreset, setAttachPreset] = useState(true);
  const [friendCode, setFriendCode] = useState("");
  const [modTitle, setModTitle] = useState("");
  const [modAuthor, setModAuthor] = useState("");
  const [modHook, setModHook] = useState("race.spectatorChinHit");
  const [modDesc, setModDesc] = useState("");
  const [betAmount, setBetAmount] = useState(50);

  const fetchPlanetState = useCallback(async () => {
    try {
      const res = await fetch("/api/race-planet");
      if (!res.ok) return;
      const data = await res.json();
      setLeaderboard(data.leaderboard ?? []);
      setChat(data.chat ?? []);
      setVotes(data.votes ?? {});
      setMods(data.mods ?? []);
    } catch {
      // ignore transient network errors
    }
  }, []);

  useEffect(() => {
    void fetchPlanetState();
  }, [fetchPlanetState, hubModal]);

  const tradeScrapForSpace = () => {
    const cost = 150;
    if (economy.raceMoneys < cost) {
      notify(`Need ${cost} Scrap Moneys to buy +0.25x island space — win a race bet or join with a friend for 1.5x space!`, true);
      return;
    }
    onUpdateEconomy(prev => ({
      ...prev,
      raceMoneys: prev.raceMoneys - cost,
      islandScale: Math.min(4.5, +(prev.islandScale + 0.25).toFixed(2)),
    }));
    notify("Expanded island by +0.25x! More space unlocked for rails, trees, and arenas.");
  };

  const joinWithFriend = (friendName: string) => {
    const clean = friendName.trim();
    if (!clean) {
      notify("Enter a friend's goblin crew name or pick a co-op partner below.", true);
      return;
    }
    if (economy.joinedFriends.includes(clean)) {
      notify(`Already merged islands with ${clean}!`, true);
      return;
    }
    onUpdateEconomy(prev => ({
      ...prev,
      joinedFriends: [...prev.joinedFriends, clean],
      islandScale: Math.min(4.5, +(prev.islandScale * 1.5).toFixed(2)),
    }));
    setFriendCode("");
    notify(`Joined islands with ${clean}! Both builders now get 1.5x island space (${(economy.islandScale * 1.5).toFixed(2)}x total)!`);
  };

  const toggleWaterRacePlanet = (enable?: boolean) => {
    const nextState = enable !== undefined ? enable : !economy.isWaterRacePlanet;
    onUpdateEconomy(prev => ({
      ...prev,
      isWaterRacePlanet: nextState,
    }));
    if (nextState) {
      onTogglePlay(true);
      notify("Arrived at the Water Race Planet! Live races, betting, majority rules, and chin-checking active.");
    } else {
      notify("Returned to your home floating island.");
    }
  };

  const voteForRule = async (ruleId: MajorityRuleId) => {
    onUpdateEconomy(prev => ({ ...prev, majorityRule: ruleId }));
    try {
      const res = await fetch("/api/race-planet", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "vote", ruleId }),
      });
      if (res.ok) {
        const data = await res.json();
        setVotes(data.votes ?? {});
        const ruleMeta = MAJORITY_RULES.find(r => r.id === ruleId);
        notify(`Voted for ${ruleMeta?.name ?? ruleId}! Planet majority rule updated.`);
      }
    } catch {
      notify("Rule applied locally.");
    }
  };

  const sendPlanetChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    const goblinPreset = snapshot.authoring?.presets[snapshot.authoring.bindings.goblin];
    try {
      const res = await fetch("/api/race-planet", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "chat",
          sender: goblinPreset?.name ?? "Rivet",
          message: chatInput.trim(),
          presetName: attachPreset ? (goblinPreset?.name ?? "Custom 3D Goblin") : null,
          presetKind: attachPreset ? "goblin" : null,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setChat(data.chat ?? []);
        setChatInput("");
        notify(attachPreset ? "Message & 3D Goblin preset shared to the Race Planet!" : "Message posted to the Race Planet!");
      }
    } catch {
      notify("Could not send message", true);
    }
  };

  const syncLeaderboardScore = async () => {
    const goblinPreset = snapshot.authoring?.presets[snapshot.authoring.bindings.goblin];
    try {
      const res = await fetch("/api/race-planet", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "score",
          goblinName: goblinPreset?.name ?? "Rivet",
          wins: economy.wins,
          scrapEarned: economy.raceMoneys,
          chinHits: economy.chinHits,
          islandScale: economy.islandScale,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setLeaderboard(data.leaderboard ?? []);
        notify("Synced your Race Moneys, Chin Hits & Island Scale to the Planet Leaderboard!");
      }
    } catch {
      notify("Could not sync score", true);
    }
  };

  const submitCommunityMod = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!modTitle.trim() || !modDesc.trim()) return;
    try {
      const res = await fetch("/api/race-planet", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "mod",
          title: modTitle.trim(),
          author: modAuthor.trim() || "Open-Source Builder",
          hookTarget: modHook,
          description: modDesc.trim(),
          configJson: { impulseMultiplier: 1.5, bonusScrap: 35, openSource: true },
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setMods(data.mods ?? []);
        setModTitle("");
        setModDesc("");
        notify("Published open-source mod hook to the shared ecosystem!");
      }
    } catch {
      notify("Could not publish mod", true);
    }
  };

  const activeRuleMeta = MAJORITY_RULES.find(r => r.id === economy.majorityRule) ?? MAJORITY_RULES[0];
  const standings = avatar.standings?.length
    ? avatar.standings
    : RACER_ROSTER.map((r, i) => ({ id: r.id, name: r.name, color: r.color, odds: r.odds, laps: 0, distance: 0, attached: true, rank: i + 1 }));

  return (
    <>
      {/* Top-Right Compact Economy, Island Scale, Water Race Planet & Modding Strip */}
      <div className="planet-economy-bar" role="region" aria-label="Race moneys, island space, and water race planet">
        <button type="button" className="scrap-pill" title="Your Race Moneys — Bet on races or trade for island space" onClick={() => onOpenModal("planet")}>
          <Coins size={12} />
          <strong>{economy.raceMoneys}</strong>
          <span>SCRAP</span>
        </button>
        <button type="button" className="space-pill" title="Trade Race Moneys for space or join with a friend for 1.5x space" onClick={() => onOpenModal("expand")}>
          <Users size={12} />
          <strong>{economy.islandScale.toFixed(2)}×</strong>
          <span>SPACE</span>
        </button>
        <button
          type="button"
          className={`water-planet-pill ${economy.isWaterRacePlanet ? "active" : ""}`}
          title="Teleport to the Water Race Planet hub with live betting, leaderboards, chat, and majority rules"
          onClick={() => toggleWaterRacePlanet()}
        >
          <Waves size={12} />
          <span>{economy.isWaterRacePlanet ? "Ocean Race Planet" : "Water Race Planet"}</span>
        </button>
        <button type="button" className="mod-hub-pill" title="Open-Source Mod Registry & Hook Hub" onClick={() => onOpenModal("mods")}>
          <Code2 size={12} />
          <span>Mods ({activeMods.length})</span>
        </button>
      </div>

      {/* Spectator Chin-Hit / Wasted Alert Banner */}
      {avatar.wasted && (
        <div className="chin-wasted-banner" role="alert">
          <Flame size={18} />
          <div>
            <strong>TOOK IT TO THE CHIN!</strong>
            <span>Your goblin body derailed {avatar.lastChinHitBy ?? "a racing sphere"} &amp; changed the race! (Chin hits: {economy.chinHits})</span>
          </div>
          <button type="button" className="button button-primary" onClick={onRespawn}>
            <RotateCcw size={13} />Respawn now
          </button>
        </div>
      )}

      {/* Live Racing, Betting & Spectator Interference Strip (shown when Play or Water Race Planet or Avatar active) */}
      {(playing || economy.isWaterRacePlanet || avatar.mode !== "orbit") && (
        <div className="live-race-ticker" role="region" aria-label="Live race standings and spectator betting">
          <div className="ticker-head">
            <Trophy size={13} />
            <strong>{economy.isWaterRacePlanet ? "AQUA SCRAPDOME LIVE" : "ISLAND RACE"}</strong>
            <span className="rule-badge" onClick={() => { setPlanetTab("rules"); onOpenModal("planet"); }} title="Click to vote on Planet Majority Rules">
              {activeRuleMeta.badge} · {activeRuleMeta.name}
            </span>
          </div>
          <div className="ticker-racers">
            {standings.map(r => {
              const isBet = activeBet?.riderId === r.id;
              return (
                <button
                  key={r.id}
                  type="button"
                  className={`racer-bet-chip ${isBet ? "bet-active" : ""} ${!r.attached ? "derailed" : ""}`}
                  title={`Click to bet 50 Scrap on ${r.name} (${r.odds}x payout)`}
                  onClick={() => onPlaceBet(r.id, 50)}
                >
                  <span className="racer-dot" style={{ background: r.color }} />
                  <strong>#{r.rank} {r.name}</strong>
                  <small>{r.odds}× · L{r.laps}</small>
                  {isBet && <span className="bet-tag">BET {activeBet.amount}</span>}
                </button>
              );
            })}
          </div>
          <div className="ticker-spectator-actions">
            <button type="button" className="spectator-action-btn cheer" title="Cheer with your 3D goblin to boost your favored ball! (F)" onClick={() => onCheer(activeBet?.riderId)}>
              <Megaphone size={12} />Cheer
            </button>
            <button type="button" className="spectator-action-btn chin" title="Jump onto the track to take the lead ball to the chin and derail it!" onClick={onStepOntoTrack}>
              <ShieldAlert size={12} />Take to Chin
            </button>
            <button type="button" className="spectator-action-btn hub" onClick={() => onOpenModal("planet")}>
              <MessageSquare size={12} />Planet Hub
            </button>
          </div>
        </div>
      )}

      {/* Modal 1: Island Space Expansion & 1.5x Friend Co-Op Merger */}
      {hubModal === "expand" && (
        <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onCloseModal(); }}>
          <div className="modal wide" role="dialog" aria-modal="true" aria-labelledby="expand-modal-title">
            <div className="modal-heading">
              <div>
                <div className="eyebrow lime">ISLAND SPACE &amp; CO-OP MERGER</div>
                <h2 id="expand-modal-title">More people together. More space.</h2>
                <p>Trade your Race Moneys for extra island space, or join with a friend to give you both <strong>1.5× space</strong> so you can build massive tracks and games.</p>
              </div>
              <button type="button" className="icon-button" aria-label="Close dialog" onClick={onCloseModal}><X size={19} /></button>
            </div>

            <div className="expand-stats-grid">
              <div className="expand-stat-card">
                <span className="eyebrow">CURRENT ISLAND SPACE</span>
                <strong>{economy.islandScale.toFixed(2)}×</strong>
                <small>{Math.round(economy.islandScale * 100)}% buildable area &amp; track radius</small>
              </div>
              <div className="expand-stat-card">
                <span className="eyebrow">RACE MONEYS</span>
                <strong>{economy.raceMoneys} Scrap</strong>
                <small>Earned from race bets, wins &amp; chin-checks</small>
              </div>
              <div className="expand-stat-card">
                <span className="eyebrow">CO-OP CREW JOINED</span>
                <strong>{economy.joinedFriends.length} {economy.joinedFriends.length === 1 ? "friend" : "friends"}</strong>
                <small>Each friend multiplies space by 1.5×</small>
              </div>
            </div>

            <div className="expand-options-grid">
              <div className="expand-option-box">
                <div className="eyebrow lime">SOLO EXPANSION</div>
                <h3>Trade Race Moneys for Space</h3>
                <p>Spend <strong>150 Scrap</strong> from your race winnings or spectator bets to expand your floating island radius by <strong>+0.25×</strong>.</p>
                <button type="button" className="button button-secondary" onClick={tradeScrapForSpace}>
                  <Coins size={14} />Trade 150 Scrap → +0.25× Space
                </button>
              </div>

              <div className="expand-option-box highlight">
                <div className="eyebrow lime">CO-OP MULTIPLIER · 1.5× EACH</div>
                <h3>Join Islands with a Friend</h3>
                <p>Merging with a friend gives <strong>both of you 1.5× island space</strong> immediately and spawns their goblin crew onto your island.</p>
                <form className="friend-merge-form" onSubmit={e => { e.preventDefault(); joinWithFriend(friendCode); }}>
                  <input
                    className="text-input"
                    placeholder="Enter friend's goblin or crew code…"
                    aria-label="Friend crew code"
                    value={friendCode}
                    onChange={e => setFriendCode(e.target.value)}
                  />
                  <button type="submit" className="button button-primary">
                    <HeartHandshake size={14} />Join (1.5× Space)
                  </button>
                </form>
                <div className="quick-friend-list">
                  <span>Online friend crews ready to merge:</span>
                  <div>
                    {["@Nix-Ironforge", "@Sprocket-Crew", "@Grub-Speedway"].map(crew => (
                      <button
                        key={crew}
                        type="button"
                        disabled={economy.joinedFriends.includes(crew)}
                        onClick={() => joinWithFriend(crew)}
                      >
                        <Plus size={11} />{crew} {economy.joinedFriends.includes(crew) ? "✓" : "(1.5×)"}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="modal-footer">
              <button type="button" className="button button-secondary" onClick={() => { toggleWaterRacePlanet(true); onCloseModal(); }}>
                <Waves size={14} />Visit Water Race Planet
              </button>
              <button type="button" className="button button-primary" onClick={onCloseModal}>Back to island</button>
            </div>
          </div>
        </div>
      )}

      {/* Modal 2: Water Race Planet Hub (Betting, Majority Rules, Live Chat + Preset Share, Leaderboards) */}
      {hubModal === "planet" && (
        <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onCloseModal(); }}>
          <div className="modal wide" role="dialog" aria-modal="true" aria-labelledby="planet-modal-title">
            <div className="modal-heading">
              <div>
                <div className="eyebrow lime">WATER RACE PLANET · AQUA SCRAPDOME</div>
                <h2 id="planet-modal-title">One mega-island. Majority rules.</h2>
                <p>Spawn on the water-covered race planet to watch live races, bet Scrap Moneys, take spheres to the chin, share presets in chat, and vote on planet-wide rules.</p>
              </div>
              <button type="button" className="icon-button" aria-label="Close dialog" onClick={onCloseModal}><X size={19} /></button>
            </div>

            <div className="guide-tabs">
              {([
                ["race", "Betting & Spectating"],
                ["rules", "Majority Rules Vote"],
                ["chat", "Planet Chat & Presets"],
                ["leaderboard", "Leaderboards"],
              ] as const).map(([id, label]) => (
                <button key={id} type="button" className={planetTab === id ? "active" : ""} onClick={() => setPlanetTab(id)}>
                  {label}
                </button>
              ))}
              <button
                type="button"
                className="button button-primary"
                style={{ marginLeft: "auto", minHeight: 28, fontSize: 10 }}
                onClick={() => { toggleWaterRacePlanet(true); onSpawnSurface("third"); onCloseModal(); }}
              >
                <Footprints size={13} />Spawn on Race Planet
              </button>
            </div>

            <div className="guide-content">
              {planetTab === "race" && (
                <div className="planet-race-tab">
                  <div className="betting-banner">
                    <div>
                      <span className="eyebrow lime">YOUR WALLET &amp; RECORD</span>
                      <h3>{economy.raceMoneys} Scrap Moneys · {economy.wins} Wins · {economy.chinHits} Taken to the Chin</h3>
                      <p>Cheering boosts your favored ball. Stepping onto the track lets you take the rival ball to the chin—knocking it off the rail while your goblin wipes out!</p>
                    </div>
                    <div className="bet-stake-selector">
                      <span>Bet Stake:</span>
                      {[25, 50, 100].map(amt => (
                        <button key={amt} type="button" className={betAmount === amt ? "active" : ""} onClick={() => setBetAmount(amt)}>
                          {amt} Scrap
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="racer-cards-grid">
                    {RACER_ROSTER.map(r => {
                      const standing = standings.find(s => s.id === r.id);
                      const isBacked = activeBet?.riderId === r.id;
                      return (
                        <div key={r.id} className={`racer-bet-card ${isBacked ? "active" : ""}`}>
                          <div className="racer-card-top">
                            <span className="racer-sphere-badge" style={{ background: r.color }} />
                            <div>
                              <strong>{r.name}</strong>
                              <small>{r.tagline}</small>
                            </div>
                            <span className="odds-pill">{r.odds}× PAYOUT</span>
                          </div>
                          <div className="racer-card-meta">
                            <span>Rank #{standing?.rank ?? 1}</span>
                            <span>Lap {standing?.laps ?? 0}</span>
                            <span>{standing?.attached !== false ? "On Rail" : "Derailed!"}</span>
                          </div>
                          <div className="racer-card-actions">
                            <button type="button" className="button button-primary" onClick={() => onPlaceBet(r.id, betAmount)}>
                              <Coins size={13} />{isBacked ? `Backed (${activeBet.amount} Scrap)` : `Bet ${betAmount} Scrap`}
                            </button>
                            <button type="button" className="button button-secondary" onClick={() => { onCheer(r.id); onCloseModal(); }}>
                              <Megaphone size={13} />Cheer
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className="chin-action-callout">
                    <ShieldAlert size={20} />
                    <div>
                      <strong>Spectators are physical bodies on the track.</strong>
                      <p>Customize your 3D goblin in the Goblin Lab, spawn on the surface, and either cheer from the sidelines or step onto the slotted rail to take a speeding sphere to the chin.</p>
                    </div>
                    <button type="button" className="button button-secondary" onClick={onEnterGoblinLab}>
                      Customize 3D Goblin
                    </button>
                    <button type="button" className="button button-primary" onClick={() => { onTogglePlay(true); onStepOntoTrack(); onCloseModal(); }}>
                      <Flame size={14} />Step onto Track (Chin-Check)
                    </button>
                  </div>
                </div>
              )}

              {planetTab === "rules" && (
                <div className="planet-rules-list">
                  <div className="prototype-notice">
                    <Crown size={18} />
                    <div>
                      <strong>Planet Majority Rules: {activeRuleMeta.name}</strong>
                      <p>Everyone on the Water Race Planet plays by the rule with the most community votes. Cast your vote to shift gravity, chain speed, or chin-check payouts in real time.</p>
                    </div>
                  </div>
                  {MAJORITY_RULES.map(rule => {
                    const count = votes[rule.id] ?? 1;
                    const isSelected = economy.majorityRule === rule.id;
                    return (
                      <div key={rule.id} className={`majority-rule-row ${isSelected ? "active" : ""}`}>
                        <span className="rule-vote-badge">{rule.badge}</span>
                        <div>
                          <strong>{rule.name}</strong>
                          <p>{rule.description}</p>
                        </div>
                        <span className="vote-tally">{count} votes</span>
                        <button type="button" className={`button ${isSelected ? "button-primary" : "button-secondary"}`} onClick={() => voteForRule(rule.id)}>
                          <ThumbsUp size={13} />{isSelected ? "Active Rule" : "Vote Rule"}
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}

              {planetTab === "chat" && (
                <div className="planet-chat-box">
                  <div className="chat-messages-list">
                    {chat.map(row => (
                      <div key={row.id} className="chat-message-row">
                        <div className="chat-sender">
                          <strong>{row.sender}</strong>
                          {row.presetName && (
                            <button
                              type="button"
                              className="shared-preset-chip"
                              onClick={() => {
                                notify(`Loaded shared preset "${row.presetName}" into your studio inspector!`);
                              }}
                            >
                              <Layers3 size={11} />Shared {row.presetKind}: {row.presetName}
                            </button>
                          )}
                        </div>
                        <p>{row.message}</p>
                      </div>
                    ))}
                  </div>
                  <form className="chat-input-form" onSubmit={sendPlanetChat}>
                    <input
                      className="text-input"
                      placeholder="Talk to spectators, call your bets, or share your preset…"
                      aria-label="Planet chat message"
                      value={chatInput}
                      onChange={e => setChatInput(e.target.value)}
                    />
                    <label className="attach-preset-toggle">
                      <input type="checkbox" checked={attachPreset} onChange={e => setAttachPreset(e.target.checked)} />
                      <span>Attach my 3D Goblin preset</span>
                    </label>
                    <button type="submit" className="button button-primary">
                      <Send size={13} />Post
                    </button>
                  </form>
                </div>
              )}

              {planetTab === "leaderboard" && (
                <div className="planet-leaderboard-box">
                  <div className="leaderboard-header-bar">
                    <span>Top Racers, Spectators &amp; Co-Op Island Builders</span>
                    <button type="button" className="button button-secondary" onClick={syncLeaderboardScore}>
                      <Trophy size={13} />Sync My Score ({economy.raceMoneys} Scrap)
                    </button>
                  </div>
                  <div className="leaderboard-rows">
                    {leaderboard.map((row, idx) => (
                      <div key={row.id} className="leaderboard-row">
                        <span className="leader-rank">#{idx + 1}</span>
                        <div>
                          <strong>{row.goblinName}</strong>
                          <small>Island Scale {row.islandScale}× · {row.wins} Wins · {row.chinHits} Taken to Chin</small>
                        </div>
                        <span className="leader-scrap">{row.scrapEarned} Scrap</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Modal 3: Open-Source Modding Ecosystem & Upstream Hook Hub */}
      {hubModal === "mods" && (
        <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onCloseModal(); }}>
          <div className="modal wide" role="dialog" aria-modal="true" aria-labelledby="mods-modal-title">
            <div className="modal-heading">
              <div>
                <div className="eyebrow lime">OPEN-SOURCE MOD REGISTRY &amp; UPSTREAM HOOKS</div>
                <h2 id="mods-modal-title">Mod the crap out of it. Together.</h2>
                <p>HeavyMetal² is open-source by design. Register declarative physics hooks, procedural texture generators, and custom race rules right inside the shared planet ecosystem so your mods live where everyone plays.</p>
              </div>
              <button type="button" className="icon-button" aria-label="Close dialog" onClick={onCloseModal}><X size={19} /></button>
            </div>

            <div className="guide-content">
              <div className="mods-list-grid">
                {mods.map(mod => {
                  const isEnabled = activeMods.includes(mod.title);
                  return (
                    <div key={mod.id} className={`mod-card ${isEnabled ? "active" : ""}`}>
                      <div className="mod-card-head">
                        <span className="mod-hook-tag">{mod.hookTarget}</span>
                        <span className="mod-upvotes">★ {mod.upvotes}</span>
                      </div>
                      <h3>{mod.title}</h3>
                      <small>By {mod.author}</small>
                      <p>{mod.description}</p>
                      <div className="mod-card-actions">
                        <button
                          type="button"
                          className={`button ${isEnabled ? "button-primary" : "button-secondary"}`}
                          onClick={() => onToggleMod(mod.title, mod.configJson, mod.hookTarget)}
                        >
                          {isEnabled ? <Check size={13} /> : <Zap size={13} />}
                          {isEnabled ? "Active in Engine" : "Enable Mod Hook"}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              <form className="publish-mod-form" onSubmit={submitCommunityMod}>
                <div className="eyebrow lime">CONTRIBUTE UPSTREAM MOD HOOK</div>
                <div className="mod-form-row">
                  <input
                    className="text-input"
                    placeholder="Mod title (e.g., Explosive Chin-Check 3x)"
                    aria-label="Mod title"
                    value={modTitle}
                    onChange={e => setModTitle(e.target.value)}
                    required
                  />
                  <input
                    className="text-input"
                    placeholder="Author / GitHub handle"
                    aria-label="Mod author"
                    value={modAuthor}
                    onChange={e => setModAuthor(e.target.value)}
                  />
                  <select className="quality-select" style={{ marginBottom: 0, maxWidth: 210 }} aria-label="Mod hook target" value={modHook} onChange={e => setModHook(e.target.value)}>
                    <option value="race.spectatorChinHit">race.spectatorChinHit</option>
                    <option value="texture.procedural">texture.procedural</option>
                    <option value="island.expand">island.expand</option>
                    <option value="physics.step">physics.step</option>
                  </select>
                </div>
                <div className="mod-form-row" style={{ marginTop: 8 }}>
                  <input
                    className="text-input"
                    placeholder="Describe what your open-source hook adds to the planet…"
                    aria-label="Mod description"
                    value={modDesc}
                    onChange={e => setModDesc(e.target.value)}
                    required
                  />
                  <button type="submit" className="button button-primary">
                    <GitBranch size={14} />Publish Upstream Mod
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
