"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { MATERIAL_WEDGES, swatchDataUrl, type SwatchKind } from "@/lib/engine/swatches";

interface Props {
  depthLabel: string;
  depthIndex: number;
  activeKind: SwatchKind | null;
  onPick: (kind: SwatchKind) => void;
  onUp: () => void;
}

const R_OUT = 78;
const R_IN = 34;
const CENTER = 84;

function wedgePath(i: number, total: number) {
  const gap = 0.035;
  const a0 = (i / total) * Math.PI * 2 - Math.PI / 2 + gap;
  const a1 = ((i + 1) / total) * Math.PI * 2 - Math.PI / 2 - gap;
  const p = (r: number, a: number) => `${CENTER + Math.cos(a) * r} ${CENTER + Math.sin(a) * r}`;
  return `M ${p(R_IN, a0)} L ${p(R_OUT, a0)} A ${R_OUT} ${R_OUT} 0 0 1 ${p(R_OUT, a1)} L ${p(R_IN, a1)} A ${R_IN} ${R_IN} 0 0 0 ${p(R_IN, a0)} Z`;
}

export default function RadialDepthMenu({ depthLabel, depthIndex, activeKind, onPick, onUp }: Props) {
  const [swatches, setSwatches] = useState<Record<string, string>>({});
  const [hover, setHover] = useState<SwatchKind | null>(null);
  const built = useRef(false);

  useEffect(() => {
    if (built.current) return;
    built.current = true;
    const next: Record<string, string> = {};
    for (const w of MATERIAL_WEDGES) next[w.id] = swatchDataUrl(w.id, 96);
    setSwatches(next);
  }, []);

  const focus = useMemo(() => MATERIAL_WEDGES.find(w => w.id === (hover ?? activeKind)) ?? null, [hover, activeKind]);

  return (
    <div className="radial-depth" role="group" aria-label="Radial depth menu">
      <svg viewBox="0 0 168 168" width="168" height="168" aria-hidden="true">
        <defs>
          {MATERIAL_WEDGES.map(w => (
            <pattern key={w.id} id={`sw-${w.id}`} patternUnits="objectBoundingBox" width="1" height="1">
              {swatches[w.id] && <image href={swatches[w.id]} x="0" y="0" width="168" height="168" preserveAspectRatio="xMidYMid slice" />}
            </pattern>
          ))}
        </defs>
        {MATERIAL_WEDGES.map((w, i) => {
          const on = (hover ?? activeKind) === w.id;
          return (
            <path
              key={w.id}
              d={wedgePath(i, MATERIAL_WEDGES.length)}
              fill={swatches[w.id] ? `url(#sw-${w.id})` : "#e9e7e1"}
              stroke="#23231f"
              strokeWidth={on ? 2 : 0.9}
              opacity={on ? 1 : 0.9}
              className="radial-wedge"
              onMouseEnter={() => setHover(w.id)}
              onMouseLeave={() => setHover(null)}
              onClick={() => onPick(w.id)}
            />
          );
        })}
        <circle cx={CENTER} cy={CENTER} r={R_IN - 2} fill="#fbfaf7" stroke="#23231f" strokeWidth="1" />
      </svg>

      <button type="button" className="radial-core" onClick={onUp} title="Go up one preset level">
        <span className="radial-core-depth">L{depthIndex}</span>
        <span className="radial-core-label">{depthLabel}</span>
      </button>

      <div className="radial-readout" aria-live="polite">
        {focus ? (
          <>
            <span className="radial-swatch" style={{ backgroundImage: swatches[focus.id] ? `url(${swatches[focus.id]})` : undefined }} />
            <span><strong>{focus.name}</strong><small>{focus.scope}</small></span>
          </>
        ) : (
          <span><strong>Adaptive build</strong><small>Pick a depth</small></span>
        )}
      </div>
    </div>
  );
}
