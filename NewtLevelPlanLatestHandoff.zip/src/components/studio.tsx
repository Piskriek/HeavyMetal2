"use client";

import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import dynamic from "next/dynamic";
import {
  ArrowDownLeft, ArrowDownRight, Boxes, ArrowLeft, ArrowRight, ArrowUpRight, AudioLines, Box, Check, CheckCheck, ChevronDown, ChevronRight,
  CircleHelp, CirclePlus, Cloud, Code2, Compass, Copy, Cpu, Download, ExternalLink, Eye, EyeOff, Footprints, FolderOpen, GitBranch, Globe2,
  Grip, Layers2, Layers3, Leaf, Link2, LoaderCircle, LockKeyhole, Maximize2, Minus, MoreHorizontal, Mountain, MousePointer2,
  Move3D, Paintbrush, Palette, Pause, Pencil, Play, Plus, Redo2, RotateCcw, RotateCw, Save, Search, Settings2, ShieldCheck,
  SlidersHorizontal, Sparkles, Sprout, Square, SquareStack, Target, Trash2, Trees, Undo2, UserRound, Waves, Waypoints, X, Zap,
} from "lucide-react";
import type { ViewportHandle } from "./world-viewport";
import RacePlanetOverlay from "./race-planet-panel";
import type { SwatchKind } from "@/lib/engine/swatches";
import { DARK_INTERFACE, DEFAULT_INTERFACE, interfaceVars, normaliseInterface, type InterfaceRecipe } from "@/lib/engine/interface-preset";
import type { PaletteEntry } from "./pbr-palette";
import { attachAuthoringGraph, editPreset, useSavedPreset, type PrimitiveKind } from "@/lib/engine/authoring";
import { upgradeSnapshot } from "@/lib/engine/authoring";
import { AutoSizeEngine } from "@/lib/engine/brush";
import { FractalNodeGraph, validateSnapshot } from "@/lib/engine/graph";
import { ENGINE_PACKAGES, PluginOrchestrator } from "@/lib/engine/plugins";
import { ARCHITECTURE, ART_BRIEFS, MILESTONES } from "@/lib/specification";
import { createDefaultSnapshot, DEFAULT_ECONOMY, MAJORITY_RULES, RACER_ROSTER, STYLE_META, type AvatarStatus, type BrushStroke, type FractalNode, type IslandEconomy, type RacerStanding, type SavedWorld, type SceneMetrics, type StudioSettings, type StudioTool, type Vec3, type WorldSnapshot, type WorldStyle } from "@/lib/engine/types";

function isTypingTarget(target: EventTarget | null) {
  const el = target as Element | null;
  return Boolean(el && typeof el.matches === "function" && el.matches("input,textarea,select"));
}

const WorldViewport = dynamic(() => import("./world-viewport"), { ssr: false, loading: () => <div className="viewport-loading"><div className="loading-orbit"><Globe2 size={27} /></div><span>Growing your little world…</span></div> });
const RadialDepthMenu = dynamic(() => import("./radial-depth-menu"), { ssr: false });
const PresetChainPanel = dynamic(() => import("./preset-chain"), { ssr: false });
const PresetNetwork = dynamic(() => import("./preset-network"), { ssr: false });
const InterfaceStudio = dynamic(() => import("./interface-studio"), { ssr: false });
const PbrPalette = dynamic(() => import("./pbr-palette"), { ssr: false });
const PresetWorkbench = dynamic(() => import("./preset-workbench"), { ssr: false, loading: () => <div className="viewport-loading"><div className="loading-orbit"><Leaf size={24} /></div><span>Opening the preset within…</span></div> });
type ModalKind = "save" | "branch" | "publish" | "share" | "presets" | "guide" | "menu" | "new" | "history" | null;
type LibraryView = "studio" | "discover" | "worlds";

function IconButton({ title, children, onClick, active, disabled, className = "" }: { title: string; children: ReactNode; onClick?: () => void; active?: boolean; disabled?: boolean; className?: string }) {
  return <button type="button" className={`icon-button ${active ? "active" : ""} ${className}`} aria-label={title} title={title} data-tooltip={title} onClick={onClick} disabled={disabled}>{children}</button>;
}
function Toggle({ value, onChange, label }: { value: boolean; onChange: () => void; label: string }) { return <button type="button" className={`toggle ${value ? "on" : ""}`} role="switch" aria-checked={value} aria-label={label} onClick={onChange}><span /></button>; }
function Modal({ title, subtitle, onClose, children, wide }: { title: string; subtitle?: string; onClose: () => void; children: ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement;
    const target = ref.current?.querySelector<HTMLElement>("input, button, select, textarea, a[href]"); target?.focus();
    const key = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
      if (event.key === "Tab") {
        const elements = Array.from(ref.current?.querySelectorAll<HTMLElement>("button:not(:disabled), input, select, textarea, a[href]") ?? []);
        const first = elements[0], last = elements[elements.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
      }
    };
    document.addEventListener("keydown", key); return () => { document.removeEventListener("keydown", key); previous?.focus(); };
  }, [onClose]);
  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><div className={`modal ${wide ? "wide" : ""}`} ref={ref} role="dialog" aria-modal="true" aria-labelledby="modal-title"><div className="modal-heading"><div><div className="eyebrow lime">HEAVYMETAL² WORKSPACE</div><h2 id="modal-title">{title}</h2>{subtitle && <p>{subtitle}</p>}</div><IconButton title="Close dialog" onClick={onClose}><X size={19} /></IconButton></div>{children}</div></div>;
}
async function api<T>(url: string, method = "GET", body?: unknown): Promise<T> {
  const response = await fetch(url, { method, headers: body ? { "Content-Type": "application/json" } : undefined, body: body ? JSON.stringify(body) : undefined });
  const data = await response.json(); if (!response.ok) throw new Error(data.error ?? "Something went wrong. Please try again."); return data as T;
}
function startingPath(snapshot: WorldSnapshot) {
  const path = [snapshot.graph.rootId];
  for (const kind of ["planet", "terrain"]) {
    const node = snapshot.graph.nodes[path[path.length - 1]];
    const ref = node.children.find(ref => snapshot.graph.nodes[ref.nodeId].kind === kind) ?? node.children[0];
    if (!ref) break; path.push(ref.nodeId);
  }
  return path;
}
function startingSelection(snapshot: WorldSnapshot) {
  const path = startingPath(snapshot), current = snapshot.graph.nodes[path[path.length - 1]];
  return current.children.find(ref => snapshot.graph.nodes[ref.nodeId].kind === "biome")?.nodeId ?? current.id;
}
function nodeIcon(node: FractalNode) {
  if (node.id === "forest" || node.id === "pine") return <Trees size={15} />;
  if (node.id === "water") return <Waves size={15} />;
  if (node.kind === "universe") return <OrbitLogo />;
  if (node.kind === "planet") return <Globe2 size={15} />;
  if (node.kind === "terrain" || node.id === "canyon") return <Mountain size={15} />;
  if (node.kind === "rail") return <Waypoints size={15} />;
  if (node.kind === "material") return <Layers3 size={15} />;
  return <Box size={15} />;
}
function OrbitLogo() { return <svg width="16" height="16" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="3" fill="currentColor" /><ellipse cx="10" cy="10" rx="8.5" ry="4.5" transform="rotate(-35 10 10)" stroke="currentColor" strokeWidth="1.25" /></svg>; }
function BrandMark() { return <svg width="34" height="34" viewBox="0 0 36 36" fill="none"><path d="M18 2 32 10v16l-14 8L4 26V10L18 2Z" stroke="currentColor" strokeWidth="1.5" /><path d="m9 23 6-12 5 9 3-6 5 9H9Z" fill="currentColor" /><path d="m14 23 4-7 4 7" stroke="#151a16" strokeWidth="1.7" /></svg>; }

export default function Studio() {
  const [snapshot, setSnapshot] = useState<WorldSnapshot>(() => createDefaultSnapshot());
  const snapshotRef = useRef(snapshot); snapshotRef.current = snapshot;
  const [worldName, setWorldName] = useState("Verdant Isle");
  const [currentWorld, setCurrentWorld] = useState<SavedWorld | null>(null);
  const currentRef = useRef(currentWorld); currentRef.current = currentWorld;
  const [view, setView] = useState<LibraryView>("studio");
  const [pathState, setPath] = useState(["universe", "planet", "terrain"]);
  const [selected, setSelected] = useState("forest");
  const [expanded, setExpanded] = useState<Record<string, boolean>>({ universe: true, planet: true, terrain: true });
  const [tool, setTool] = useState<StudioTool>("brush");
  const [playing, setPlaying] = useState(false);
  const [pro, setPro] = useState(false);
  const [rightTab, setRightTab] = useState<"presets" | "engine">("presets");
  const [inspectorOpen, setInspectorOpen] = useState(false);
  const [leftTab, setLeftTab] = useState<"hierarchy" | "layers">("hierarchy");
  const [layers, setLayers] = useState<Record<string, boolean>>({});
  const [searchOpen, setSearchOpen] = useState(false);
  const [nodeSearch, setNodeSearch] = useState("");
  const [modal, setModal] = useState<ModalKind>(null);
  const closeModal = useCallback(() => setModal(null), []);
  const [tempName, setTempName] = useState("");
  const [visibility, setVisibility] = useState<"private" | "public">("private");
  const [saving, setSaving] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [ready, setReady] = useState(false);
  const [toast, setToast] = useState<{ message: string; error?: boolean } | null>(null);
  const [copied, setCopied] = useState(false);
  const [worlds, setWorlds] = useState<SavedWorld[]>([]);
  const [loadingWorlds, setLoadingWorlds] = useState(false);
  const [librarySearch, setLibrarySearch] = useState("");
  const [filter, setFilter] = useState("All worlds");
  const [guideTab, setGuideTab] = useState("Architecture");
  const [diagnostics, setDiagnostics] = useState<{ latency: number; isolated: boolean; budget: number } | null>(null);
  const [diagnosing, setDiagnosing] = useState(false);
  const [revisions, setRevisions] = useState<{ version: number; snapshot: WorldSnapshot; message: string; createdAt: string }[]>([]);
  const [metrics, setMetrics] = useState<SceneMetrics>({ fps: 0, triangles: 0, calls: 0, objects: 0, activeCells: 0 });
  const [avatar, setAvatar] = useState<AvatarStatus>({ spawned: false, mode: "orbit", position: [-2.4, 1.2, 3.6], spectateRail: false, activeCells: 0 });
  const avatarModeRef = useRef(avatar.mode); avatarModeRef.current = avatar.mode;
  const [theme, setTheme] = useState<"deep" | "paper">("paper");
  const themeRef = useRef(theme); themeRef.current = theme;
  const [chainOpen, setChainOpen] = useState(false);
  const [networkOpen, setNetworkOpen] = useState(false);
  const [uiOpen, setUiOpen] = useState(false);
  const [sheet, setSheet] = useState<"none" | "explorer" | "inspector">("none");
  const [paletteCollapsed, setPaletteCollapsed] = useState(false);
  const [activeMaterial, setActiveMaterial] = useState<string | null>(null);
  const [ui, setUi] = useState<InterfaceRecipe>(DEFAULT_INTERFACE);
  const [drawersPinned, setDrawersPinned] = useState(false);
  const [hubModal, setHubModal] = useState<"planet" | "expand" | "mods" | null>(null);
  const [activeBet, setActiveBet] = useState<{ riderId: string; amount: number } | null>(null);
  const activeBetRef = useRef(activeBet); activeBetRef.current = activeBet;
  const [activeMods, setActiveMods] = useState<string[]>(["Chin-Ricochet Shockwave Hook"]);
  const [historyCount, setHistoryCount] = useState([0, 0]);
  const undoStack = useRef<WorldSnapshot[]>([]), redoStack = useRef<WorldSnapshot[]>([]);
  const viewportApi = useRef<ViewportHandle | null>(null);
  const enterNodeRef = useRef<((id: string, parentId?: string) => void) | null>(null);
  const canvasShell = useRef<HTMLDivElement>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const graph = useMemo(() => new FractalNodeGraph(snapshot.graph), [snapshot.graph]);
  const currentNode = graph.get(snapshot.graph.nodes[selected] ? selected : snapshot.graph.rootId);
  const path = pathState[0] === snapshot.graph.rootId && pathState.every(id => snapshot.graph.nodes[id]) ? pathState : startingPath(snapshot);
  const authoringNodeId = snapshot.authoring?.presets[path[path.length - 1]] ? path[path.length - 1] : null;
  const goblinActive = path.some(id => snapshot.authoring?.presets[id]?.kind === "goblin");
  const contextKind = graph.get(path[path.length - 1]).kind;
  const depth = ({ universe: 0, planet: 1, terrain: 2, biome: 3, prop: 4, material: 5, rail: 2 } as const)[contextKind];
  const style = STYLE_META[snapshot.style];
  const notify = useCallback((message: string, error = false) => setToast({ message, error }), []);

  const commit = useCallback((update: (previous: WorldSnapshot) => WorldSnapshot, record = true) => {
    const previous = snapshotRef.current;
    if (record) { undoStack.current.push(previous); if (undoStack.current.length > 50) undoStack.current.shift(); redoStack.current = []; }
    const next = update(previous); snapshotRef.current = next; setSnapshot(next); setDirty(true); setHistoryCount([undoStack.current.length, redoStack.current.length]);
  }, []);
  const updateSettings = useCallback((changes: Partial<StudioSettings>) => commit(s => ({ ...s, settings: { ...s.settings, ...changes } }), false), [commit]);
  const updateEconomy = useCallback((updater: (prev: IslandEconomy) => IslandEconomy) => commit(s => ({ ...s, economy: updater(s.economy ?? { ...DEFAULT_ECONOMY, joinedFriends: [] }) }), false), [commit]);
  const undo = useCallback(() => { const previous = undoStack.current.pop(); if (!previous) return; redoStack.current.push(snapshotRef.current); snapshotRef.current = previous; setSnapshot(previous); setDirty(true); setHistoryCount([undoStack.current.length, redoStack.current.length]); }, []);
  const redo = useCallback(() => { const next = redoStack.current.pop(); if (!next) return; undoStack.current.push(snapshotRef.current); snapshotRef.current = next; setSnapshot(next); setDirty(true); setHistoryCount([undoStack.current.length, redoStack.current.length]); }, []);
  const onStroke = useCallback((stroke: BrushStroke) => commit(s => ({ ...s, strokes: [...s.strokes, stroke].slice(-600) })), [commit]);
  const onRail = useCallback((point: Vec3) => commit(s => ({ ...s, rails: [...s.rails, point].slice(0, 64) })), [commit]);

  const handleChinHit = useCallback((riderId: string, riderName: string, totalHits: number) => {
    const ruleId = snapshotRef.current.economy?.majorityRule ?? "standard";
    const rule = MAJORITY_RULES.find(r => r.id === ruleId) ?? MAJORITY_RULES[0];
    updateEconomy(prev => ({
      ...prev,
      chinHits: Math.max(prev.chinHits + 1, totalHits),
      raceMoneys: prev.raceMoneys + rule.chinBonus,
    }));
    notify(`TOOK IT TO THE CHIN! You derailed ${riderName}'s sphere and earned +${rule.chinBonus} Hazard Scrap!`);
  }, [updateEconomy, notify]);

  const handleRaceFinish = useCallback((winnerId: string, winnerName: string, _standings: RacerStanding[]) => {
    const bet = activeBetRef.current;
    if (!bet) return;
    const racer = RACER_ROSTER.find(r => r.id === winnerId);
    if (bet.riderId === winnerId && racer) {
      const payout = Math.round(bet.amount * racer.odds);
      updateEconomy(prev => ({
        ...prev,
        raceMoneys: prev.raceMoneys + payout,
        wins: prev.wins + 1,
      }));
      setActiveBet(null);
      notify(`${winnerName} won the heat! Your bet paid out +${payout} Scrap Moneys!`);
    } else {
      setActiveBet(null);
      notify(`${winnerName} won the heat! Place a new bet or step onto the track to derail the leader.`);
    }
  }, [updateEconomy, notify]);

  const placeBet = useCallback((riderId: string, amount: number) => {
    const econ = snapshotRef.current.economy ?? DEFAULT_ECONOMY;
    if (econ.raceMoneys < amount) {
      notify(`Not enough Scrap Moneys (${econ.raceMoneys} available). Take a sphere to the chin for hazard scrap!`, true);
      return;
    }
    const racer = RACER_ROSTER.find(r => r.id === riderId);
    updateEconomy(prev => ({ ...prev, raceMoneys: prev.raceMoneys - amount }));
    setActiveBet({ riderId, amount });
    setPlaying(true);
    notify(`Bet ${amount} Scrap on ${racer?.name ?? riderId} (${racer?.odds ?? 2}×)! Cheer or chin-check rivals to help them win!`);
  }, [updateEconomy, notify]);

  const toggleModHook = useCallback((modTitle: string, modConfig: Record<string, string | number | boolean>, hookTarget: string) => {
    setActiveMods(prev => {
      const exists = prev.includes(modTitle);
      const next = exists ? prev.filter(m => m !== modTitle) : [...prev, modTitle];
      if (!exists && hookTarget === "island.expand" && typeof modConfig.friendMultiplier === "number") {
        updateEconomy(e => ({ ...e, islandScale: Math.min(4.5, +(e.islandScale * 1.15).toFixed(2)) }));
      }
      notify(exists ? `Disabled mod hook: ${modTitle}` : `Enabled open-source mod hook: ${modTitle}`);
      return next;
    });
  }, [updateEconomy, notify]);

  useEffect(() => {
    let active = true;
    const worldId = new URLSearchParams(window.location.search).get("world");
    const load = async () => {
      try {
        if (worldId) {
          const data = await api<{ world: SavedWorld }>(`/api/worlds/${encodeURIComponent(worldId)}`);
          if (active) { const restored = upgradeSnapshot(data.world.snapshot); setSnapshot(restored); setPath(startingPath(restored)); setSelected(startingSelection(restored)); setWorldName(data.world.name); setCurrentWorld(data.world); notify(data.world.owned ? "Welcome back to your world." : "Community world loaded. Branch it to make it yours."); }
        } else {
          const draft = localStorage.getItem("hm2-studio-draft");
          if (draft) { const data = JSON.parse(draft); data.snapshot = upgradeSnapshot(data.snapshot); validateSnapshot(data.snapshot); if (active) { setSnapshot(data.snapshot); setPath(startingPath(data.snapshot)); setSelected(startingSelection(data.snapshot)); setWorldName(data.name ?? "Verdant Isle"); setCurrentWorld(data.world ?? null); setDirty(Boolean(data.dirty)); } }
          await api("/api/worlds");
        }
      } catch (error) { if (active) notify(error instanceof Error ? error.message : "Could not recover this workspace", true); }
      if (active) setReady(true);
    };
    void load(); return () => { active = false; };
  }, [notify]);
  useEffect(() => { if (!ready) return; const timer = setTimeout(() => { try { localStorage.setItem("hm2-studio-draft", JSON.stringify({ snapshot, name: worldName, world: currentWorld, dirty })); } catch { notify("Device storage is full. Save your world to preserve these edits.", true); } }, 500); return () => clearTimeout(timer); }, [snapshot, currentWorld, worldName, dirty, ready, notify]);
  useEffect(() => { if (!toast) return; const timer = setTimeout(() => setToast(null), 4500); return () => clearTimeout(timer); }, [toast]);
  useEffect(() => { try { const saved = localStorage.getItem("hm2-theme"); if (saved === "paper" || saved === "deep") setTheme(saved); } catch { /* theme preference is optional */ } }, []);
  useEffect(() => { try { localStorage.setItem("hm2-theme", theme); } catch { /* ignore */ } }, [theme]);
  useEffect(() => {
    try { const raw = localStorage.getItem("hm2-interface"); if (raw) setUi(normaliseInterface(JSON.parse(raw))); }
    catch { /* a corrupt interface preset should never block the studio */ }
  }, []);
  useEffect(() => { try { localStorage.setItem("hm2-interface", JSON.stringify(ui)); } catch { /* ignore */ } }, [ui]);
  const toggleTheme = useCallback(() => {
    const next = themeRef.current === "paper" ? "deep" : "paper";
    setTheme(next);
    // Dark mode is the "Dark Room" interface preset, not a separate skin
    setUi(next === "deep" ? DARK_INTERFACE : DEFAULT_INTERFACE);
    notify(next === "paper" ? "Compact Build interface applied." : "Dark Room interface preset applied.");
  }, [notify]);

  const openSave = useCallback((kind: ModalKind = "save") => { setTempName(kind === "branch" ? `${worldName} — remix` : kind === "new" ? "Untitled world" : worldName); setVisibility(kind === "publish" ? "public" : "private"); setModal(kind); }, [worldName]);
  const persist = useCallback(async (kind: "save" | "branch" | "publish" | "new", name = worldName, privacy = visibility) => {
    if (saving) return;
    setSaving(true);
    try {
      const existing = currentRef.current;
      const state = kind === "new" ? createDefaultSnapshot() : snapshotRef.current;
      const canUpdate = existing && existing.owned !== false && kind !== "branch" && kind !== "new";
      const data = await api<{ world: SavedWorld }>(canUpdate ? `/api/worlds/${existing.id}` : "/api/worlds", canUpdate ? "PATCH" : "POST", {
        name: name.trim(), snapshot: state, visibility: kind === "publish" ? "public" : privacy,
        ...(canUpdate ? { version: existing.version, message: kind === "publish" ? "Published to the community" : "Workspace saved" } : { parentId: kind === "branch" ? existing?.id ?? null : null }),
      });
      setCurrentWorld(data.world); setWorldName(data.world.name); setDirty(kind !== "new" && snapshotRef.current !== state);
      if (kind === "new") { setSnapshot(data.world.snapshot); setPath(["universe", "planet", "terrain"]); setSelected("forest"); undoStack.current = []; redoStack.current = []; setHistoryCount([0, 0]); }
      setView("studio"); setModal(kind === "publish" || privacy === "public" ? "share" : null);
      notify(kind === "branch" ? "Your branch is ready. Make it something new." : kind === "publish" ? "World published. Let the mayhem begin." : "World saved. Every little detail.");
      const url = new URL(window.location.href); url.searchParams.delete("world"); window.history.replaceState({}, "", url);
    } catch (error) { notify(error instanceof Error ? error.message : "Could not save your world", true); }
    finally { setSaving(false); }
  }, [saving, visibility, worldName, notify]);
  const quickSave = useCallback(() => { if (currentRef.current && currentRef.current.owned !== false) void persist("save", worldName, currentRef.current.visibility); else openSave("save"); }, [persist, openSave, worldName]);
  useEffect(() => {
    const key = (event: KeyboardEvent) => {
      if (document.querySelector(".authoring-modal")) return;
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") { event.preventDefault(); if (!modal) quickSave(); }
      if (isTypingTarget(event.target) || modal) return;
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "z") { event.preventDefault(); event.shiftKey ? redo() : undo(); return; }
      if (event.ctrlKey || event.metaKey) return;
      if (avatarModeRef.current !== "orbit") {
        if (event.key === "Escape") { viewportApi.current?.setAvatarMode("orbit"); return; }
        return;
      }
      if (playing && event.key.toLowerCase() !== "p") return;
      if (event.key.toLowerCase() === "p") { setPlaying(value => !value); return; }
      if (event.key.toLowerCase() === "e") {
        if (authoringNodeId) return; // the preset shelf owns E inside the workbench
        const order: StudioTool[] = ["select", "brush", "erase", "rail", "move"];
        const suggested = order[(order.indexOf(tool) + 1) % order.length];
        setTool(suggested);
        notify(`Next brush: ${suggested}`);
        return;
      }
      const tools: Record<string, StudioTool> = { v: "select", b: "brush", r: "rail", g: "move" };
      if (tools[event.key.toLowerCase()]) setTool(tools[event.key.toLowerCase()]);
    };
    window.addEventListener("keydown", key); return () => window.removeEventListener("keydown", key);
  }, [modal, playing, quickSave, undo, redo, tool, notify, authoringNodeId]);

  const spawnOnSurface = useCallback((mode: "third" | "first" = "third") => {
    setView("studio");
    setPath(startingPath(snapshotRef.current));
    setSelected(startingSelection(snapshotRef.current));
    setPro(false);
    setTimeout(() => {
      viewportApi.current?.spawnAvatar(mode);
      notify(mode === "first" ? "Jumped into your goblin body (1st person). Walk with WASD / Arrows." : "Spawned on the surface (3rd person). Walk with WASD / Arrows or switch to 1st person.");
    }, 30);
  }, [notify]);

  const pickWedge = useCallback((kind: SwatchKind) => {
    const snap = snapshotRef.current;
    const nodes = Object.values(snap.graph.nodes);
    const byKind = (k: string) => nodes.find(n => n.kind === k)?.id;
    const target =
      kind === "dirt" ? byKind("terrain") :
      kind === "foliage" ? byKind("biome") :
      kind === "iron" ? byKind("rail") :
      kind === "enamel" ? snap.authoring?.bindings.tree :
      kind === "brass" ? snap.authoring?.bindings.goblin :
      snap.authoring?.bindings.leafTexture;
    if (!target || !snap.graph.nodes[target]) { notify("That depth is not part of this world yet."); return; }
    enterNodeRef.current?.(target);
  }, [notify]);

  const pickPrimitive = useCallback((primitive: PrimitiveKind) => {
    commit(prev => {
      const objectId = prev.authoring?.bindings.object;
      if (!objectId || !prev.authoring?.presets[objectId]) return prev;
      const current = prev.authoring.presets[objectId];
      return editPreset(prev, objectId, { shape: { ...current.shape, primitive }, name: `Untitled ${primitive}` });
    });
    const objectId = snapshotRef.current.authoring?.bindings.object;
    if (objectId) enterNodeRef.current?.(objectId);
    notify(`Started a new ${primitive} preset. Add a texture, tweak it, then save it as your own.`);
  }, [commit, notify]);

  const importSharedPackage = useCallback((pkg: Parameters<typeof useSavedPreset>[1]["package"], name: string) => {
    commit(prev => {
      const targetKind = pkg.presets[pkg.rootId]?.kind;
      const target = Object.values(prev.authoring?.presets ?? {}).find(p => p.kind === targetKind);
      if (!target) { notify(`No ${targetKind} slot in this world to receive that preset.`, true); return prev; }
      try {
        const saved = { id: crypto.randomUUID(), name, kind: targetKind, package: pkg, contentHash: "", visibility: "public" as const, createdAt: new Date().toISOString(), owned: false };
        return useSavedPreset(prev, saved, target.id);
      } catch (error) { notify((error as Error).message, true); return prev; }
    });
  }, [commit, notify]);

  const nudgeWalk = useCallback((action: "forward" | "backward" | "left" | "right") => {
    viewportApi.current?.moveAvatar(action, true);
    setTimeout(() => viewportApi.current?.moveAvatar(action, false), 180);
  }, []);
  useEffect(() => {
    if (view === "studio") return;
    let active = true; setLoadingWorlds(true);
    api<{ worlds: SavedWorld[] }>(`/api/worlds${view === "discover" ? "?scope=community" : ""}`).then(data => { if (active) setWorlds(data.worlds); }).catch(error => { if (active) notify(error.message, true); }).finally(() => { if (active) setLoadingWorlds(false); });
    return () => { active = false; };
  }, [view, notify]);

  const applyStyle = (next: WorldStyle) => { commit(s => ({ ...s, style: next, graph: s.graph })); if (!currentWorld) setWorldName(STYLE_META[next].short); setModal(null); notify(`${STYLE_META[next].name} applied to your world.`); };
  const enterNode = (id = selected, parentId?: string) => {
    const activeGraph = new FractalNodeGraph(snapshotRef.current.graph);
    let next = activeGraph.pathTo(id);
    const previous = pathState.filter(nodeId => snapshotRef.current.graph.nodes[nodeId]);
    if (parentId) {
      const index = previous.indexOf(parentId);
      const prefix = index >= 0 ? previous.slice(0, index + 1) : activeGraph.pathTo(parentId);
      if (activeGraph.get(parentId).children.some(ref => ref.nodeId === id)) next = activeGraph.enter(prefix, id);
    } else if (previous.includes(id)) next = previous.slice(0, previous.indexOf(id) + 1);
    else if (previous.length && activeGraph.get(previous[previous.length - 1]).children.some(ref => ref.nodeId === id)) next = activeGraph.enter(previous, id);
    setPath(next); setSelected(id); setPro(false); if (next.length > 4) setTool("select");
  };
  enterNodeRef.current = enterNode;
  const enterPro = () => { const material = Object.values(snapshot.graph.nodes).find(n => n.kind === "material" && n.children.length === 0 && graph.pathTo(n.id).at(-1) === n.id); if (!material) { notify("This preset has no reachable base material yet."); return; } setPath(graph.pathTo(material.id)); setSelected(material.id); setPro(true); setTool("select"); setRightTab("presets"); };
  const loadWorld = (world: SavedWorld) => { setSnapshot(upgradeSnapshot(world.snapshot)); setCurrentWorld(world); setWorldName(world.name); setDirty(false); setView("studio"); setPath(startingPath(world.snapshot)); setSelected(startingSelection(world.snapshot)); setPlaying(false); setPro(false); undoStack.current = []; redoStack.current = []; setHistoryCount([0, 0]); notify(`Opened ${world.name}.`); };
  const openTemplate = (next: WorldStyle) => { commit(() => createDefaultSnapshot(next)); setCurrentWorld(null); setWorldName(STYLE_META[next].short); setView("studio"); setPath(["universe", "planet", "terrain"]); setSelected("forest"); setPlaying(false); setPro(false); };
  const returnToWorld = () => { setView("studio"); setPath(startingPath(snapshot)); setSelected(startingSelection(snapshot)); setPlaying(false); setPro(false); };
  const publish = () => { if (currentWorld?.visibility === "public" && !dirty) setModal("share"); else openSave("publish"); };
  const exportWorld = () => { const blob = new Blob([JSON.stringify({ name: worldName, ...snapshot }, null, 2)], { type: "application/json" }); const url = URL.createObjectURL(blob); const link = document.createElement("a"); link.href = url; link.download = `${worldName.toLowerCase().replace(/[^a-z0-9]+/g, "-")}.hm2.json`; link.click(); URL.revokeObjectURL(url); notify("World exported with all pinned dependencies."); };
  const copyLink = async () => { if (!currentWorld) return; try { await navigator.clipboard.writeText(`${window.location.origin}/?world=${currentWorld.id}`); setCopied(true); setTimeout(() => setCopied(false), 2500); } catch { notify("Select and copy the link below.", true); } };
  const archive = async (world: SavedWorld) => { try { await api(`/api/worlds/${world.id}`, "PATCH", { version: world.version, archived: true, message: "World archived" }); setWorlds(previous => previous.filter(w => w.id !== world.id)); if (currentWorld?.id === world.id) setCurrentWorld(null); setModal(null); notify("World archived. Its revision history is preserved."); } catch (error) { notify((error as Error).message, true); } };
  const showHistory = async () => { if (!currentWorld) { notify("Save your first revision to start a history."); return; } try { const data = await api<{ revisions: typeof revisions }>(`/api/worlds/${currentWorld.id}?revisions=1`); setRevisions(data.revisions); setModal("history"); } catch (error) { notify((error as Error).message, true); } };
  const runDiagnostics = async () => { setDiagnosing(true); const orchestrator = new PluginOrchestrator(); try { setDiagnostics(await orchestrator.diagnose()); notify("Worker contract passed. All capability limits verified."); } catch (error) { notify((error as Error).message, true); } finally { orchestrator.dispose(); setDiagnosing(false); } };
  const importPackage = async (file: File) => { try { if (file.size > 10000) throw new Error("Engine packages must be smaller than 10 KB"); const pkg = PluginOrchestrator.validate(JSON.parse(await file.text())); updateSettings({ renderStyle: pkg.renderStyle }); notify(`${pkg.name} validated and applied. Only approved render capabilities are used.`); } catch (error) { notify((error as Error).message, true); } };

  function treeRow(id: string, level = 0): ReactNode {
    const node = graph.get(id), hasChildren = node.children.length > 0;
    return <div key={id}><div className={`tree-row ${selected === id ? "selected" : ""} node-${node.kind}`} style={{ paddingLeft: 13 + level * 16 }} onDoubleClick={() => enterNode(id)}>
      <button className="tree-expander" aria-label={`${expanded[id] ? "Collapse" : "Expand"} ${node.name}`} onClick={() => setExpanded(s => ({ ...s, [id]: !s[id] }))}>{hasChildren ? expanded[id] ? <ChevronDown size={11} /> : <ChevronRight size={11} /> : <span className="tree-dot" />}</button>
      <button className="node-select" onClick={() => setSelected(id)}><span className="node-icon">{nodeIcon(node)}</span><span>{node.name}</span></button>
      {snapshot.authoring?.presets[id] && <button className="tree-edit" title={`Edit ${node.name} preset`} aria-label={`Edit ${node.name} preset`} onClick={e => { e.stopPropagation(); enterNode(id); }}><Pencil size={11} /></button>}
      {["terrain", "forest", "water", "rail"].includes(id) && <button className="tree-eye" title={`${layers[id] === false ? "Show" : "Hide"} ${node.name}`} onClick={() => setLayers(s => ({ ...s, [id]: s[id] === false }))}>{layers[id] === false ? <EyeOff size={12} /> : <Eye size={12} />}</button>}
    </div>{expanded[id] && node.children.map(ref => treeRow(ref.nodeId, level + 1))}</div>;
  }

  const controls = [
    ["Drag / orbit", "V + drag"], ["Grow with gel", "B · Left click"], ["Carve terrain", "Right click / E"], ["Draw a rail", "R · Click anchors"], ["Spawn & walk on surface", "W A S D / Arrows"], ["Toggle 1st / 3rd person", "C (In body)"], ["Jump on surface", "Space (In body)"], ["Save world", "⌘ / Ctrl + S"], ["Undo / redo", "⌘ / Ctrl + Z / ⇧ Z"], ["Knock off & spawn debris", "Space (Play)"], ["Reel onto the rail", "Hold W (Play)"],
  ];
  const filteredWorlds = worlds.filter(w => w.name.toLowerCase().includes(librarySearch.toLowerCase()) && (filter === "All worlds" || filter === "Public" && w.visibility === "public" || filter === "Private" && w.visibility === "private" || filter === "Forest" && w.snapshot.style === "verdant" || filter === "Desert" && w.snapshot.style === "dunes" || filter === "Cosmic" && w.snapshot.style === "lunar"));

  const uiVars = interfaceVars(ui) as React.CSSProperties;
  return <div className={`studio-app ${theme === "paper" ? "paper" : ""} density-${ui.density}`} style={uiVars}>
    <header className="app-header">
      <button className="brand" onClick={returnToWorld} aria-label="HeavyMetal2 Studio"><span className="brand-symbol"><BrandMark /></span><span className="brand-name">HEAVYMETAL<span className="brand-two">2</span><small>WORLD ENGINE</small></span><span className="alpha-badge">ALPHA</span></button>
      <nav className="main-nav" aria-label="Main navigation"><button className={view === "studio" && !goblinActive ? "active" : ""} onClick={returnToWorld}>{view === "studio" && !goblinActive && <span className="nav-dot" />}Studio</button><button className={`goblin-nav ${view === "studio" && goblinActive ? "active" : ""}`} onClick={() => { setView("studio"); enterNode(snapshot.authoring!.bindings.goblin); }}>Goblin lab<span className="new-nav-tag">3D</span></button>{([['discover', 'Discover'], ['worlds', 'My worlds']] as const).map(([id, label]) => <button key={id} className={view === id ? "active" : ""} onClick={() => setView(id)}>{view === id && <span className="nav-dot" />}{label}</button>)}</nav>
      <div className="header-actions"><IconButton title="Interface preset · sculpt, paint, share" onClick={() => setUiOpen(true)}><Palette size={18} /></IconButton><IconButton title={theme === "paper" ? "Switch to Deep graphite mode" : "Switch to Compact Adaptive Build"} active={theme === "paper"} onClick={toggleTheme}>{theme === "paper" ? <Layers2 size={18} /> : <SquareStack size={18} />}</IconButton><IconButton title="Help & engineering guide" onClick={() => setModal("guide")}><CircleHelp size={19} /></IconButton><span className="header-divider" /><button className="invite-button" onClick={publish}><Link2 size={15} />Share</button><button className="button button-primary publish-button" onClick={publish}><Globe2 size={15} />Publish world<ArrowUpRight size={15} /></button><button className="avatar" title="Your local workspace" onClick={() => setView("worlds")}>ME<span /></button></div>
    </header>

    <div className="command-bar">
      <div className="world-control"><button className="world-name-button" onClick={() => setView(view === "studio" ? "worlds" : "studio")}><span className="world-mini-icon"><Globe2 size={16} /></span><span>{view === "studio" ? worldName : view === "discover" ? "Explore the universe" : "Your little universe"}</span><ChevronDown size={13} /></button>{view === "studio" && <><span className="command-divider" /><span className={`save-status ${dirty ? "unsaved" : ""}`}><span />{saving ? "Saving…" : !currentWorld ? "Local draft" : dirty ? "Unsaved changes" : "All changes saved"}</span></>}</div>
      {view === "studio" ? <><div className="mode-switch"><button className={!playing ? "active" : ""} onClick={() => setPlaying(false)}><Box size={14} />Build</button><button className={playing ? "active play-mode" : ""} onClick={() => { setPlaying(true); setPath(startingPath(snapshot)); setPro(false); }}><Play size={13} />Play<span className="mode-key">P</span></button></div><div className="command-actions"><IconButton title="Undo · Ctrl Z" disabled={!historyCount[0]} onClick={undo}><Undo2 size={16} /></IconButton><IconButton title="Redo · Ctrl Shift Z" disabled={!historyCount[1]} onClick={redo}><Redo2 size={16} /></IconButton><span className="command-divider" /><button className="text-button branch-button" onClick={() => openSave("branch")}><GitBranch size={15} />Branch</button><button className="button button-secondary save-button" disabled={saving} onClick={quickSave}>{saving ? <LoaderCircle className="spin" size={14} /> : <Save size={14} />}Save<span className="shortcut">⌘ S</span></button></div></> : <button className="button button-primary" onClick={() => openSave("new")}><Plus size={15} />New world</button>}
    </div>

    {view === "studio" ? authoringNodeId ? <PresetWorkbench snapshot={snapshot} nodeId={authoringNodeId} traversalPath={path} onEdit={commit} onNavigate={enterNode} onExit={returnToWorld} notify={notify} /> : <div className={`workspace drawers ${drawersPinned ? "pinned" : ""}`}>
      <aside className={`explorer ${sheet === "explorer" ? "sheet-open" : ""}`}>
        <div className="panel-heading"><span className="eyebrow">WORLD EXPLORER</span><div><button type="button" className={`drawer-pin ${drawersPinned ? "on" : ""}`} onClick={() => setDrawersPinned(v => !v)} title={drawersPinned ? "Let drawers auto-hide" : "Pin drawers open"}>{drawersPinned ? "PINNED" : "AUTO"}</button><IconButton title="Search nodes" active={searchOpen} onClick={() => setSearchOpen(!searchOpen)}><Search size={14} /></IconButton><IconButton title="Create a world branch" onClick={() => openSave("branch")}><Plus size={16} /></IconButton></div></div>
        {searchOpen && <div className="node-search"><Search size={13} /><input autoFocus placeholder="Find a node…" aria-label="Search world nodes" value={nodeSearch} onChange={e => setNodeSearch(e.target.value)} /></div>}
        <div className="panel-tabs"><button className={leftTab === "hierarchy" ? "active" : ""} onClick={() => setLeftTab("hierarchy")}><Waypoints size={13} />Hierarchy</button><button className={leftTab === "layers" ? "active" : ""} onClick={() => setLeftTab("layers")}><Layers3 size={13} />Layers<span>4</span></button></div>
        <div className="explorer-scroll">{leftTab === "hierarchy" ? <div className="scene-tree">{nodeSearch ? Object.values(snapshot.graph.nodes).filter(n => n.name.toLowerCase().includes(nodeSearch.toLowerCase())).map(n => <button key={n.id} className={`search-node ${n.id === selected ? "active" : ""}`} onClick={() => setSelected(n.id)}>{nodeIcon(n)}{n.name}<ChevronRight size={13} /></button>) : treeRow(snapshot.graph.rootId)}</div> : <div className="layer-list">{[["terrain", "Terrain & cliffs", Mountain], ["forest", "Vegetation", Trees], ["water", "Water & streams", Waves], ["rail", "Rail & riders", Waypoints]].map(([id, label, Icon]) => { const I = Icon as typeof Mountain; return <div key={id as string}><I size={16} /><span>{label as string}</span><Toggle label={`Show ${label}`} value={layers[id as string] !== false} onChange={() => setLayers(s => ({ ...s, [id as string]: s[id as string] === false }))} /></div>; })}</div>}
        <div className="node-summary"><span className="node-count"><span />{Object.keys(snapshot.graph.nodes).length} nodes</span><span>3 biomes</span><button onClick={() => { setGuideTab("Architecture"); setModal("guide"); }} title="Scene graph architecture"><Code2 size={13} /></button></div>
        <button className="world-authoring-entry network-entry" onClick={() => setNetworkOpen(true)}><Waypoints size={17} /><span><strong>Preset network.</strong><small>Branching timeline · zoom & edit live</small></span><ArrowUpRight size={16} /></button><button className="world-authoring-entry preset-chain-entry" onClick={() => setChainOpen(true)}><Boxes size={17} /><span><strong>Everything is a preset.</strong><small>Cube → texture → object → tree</small></span><ArrowUpRight size={16} /></button><button className="world-authoring-entry" onClick={() => enterNode(snapshot.authoring!.bindings.tree)}><Leaf size={17} /><span><strong>Go beyond the model.</strong><small>Tree → leaf → texture recipe</small></span><ArrowDownRight size={16} /></button><div className="traversal-card"><div className="traversal-icon"><Layers3 size={20} /><span /></div><h3>Small worlds.<br />Infinite possibilities.</h3><p>Every preset is a world of its own.<br />Go deeper. Make it yours.</p><button onClick={() => enterNode()}><span>Enter preset</span><ArrowDownRight size={17} /></button></div>
        <div className="selected-node-card"><span className="eyebrow">SELECTED NODE</span><div>{nodeIcon(currentNode)}<strong>{currentNode.name}</strong><span className="node-version">v{currentNode.revision}.0</span></div><p>{currentNode.kind.toUpperCase()}<span>PINNED REVISION</span></p></div>
        </div>
        <div className="branch-section"><div className="eyebrow">ACTIVE BRANCH <LockKeyhole size={11} /></div><div className="branch-row"><span><GitBranch size={15} /><strong>{currentWorld?.parentId ? "remix" : "main"}</strong></span><span className="private-pill">{currentWorld?.visibility ?? "private"}</span><IconButton title="World actions" onClick={() => setModal("menu")}><MoreHorizontal size={16} /></IconButton></div><button className="branch-history" onClick={showHistory}><span className="small-status-dot" />{currentWorld ? `${currentWorld.version} saved revision${currentWorld.version > 1 ? "s" : ""}` : "Your personal workspace"}<ChevronRight size={12} /></button></div>
        <div className="explorer-footer"><span className="system-orbit"><Cpu size={14} /></span><span>Native world engine<small>Ready to make a little chaos</small></span><span className="online-dot" /></div>
      </aside>

      <main className="center-stage">
        <div className="canvas-shell" ref={canvasShell}>
          <WorldViewport snapshot={snapshot} tool={tool} depth={depth} playing={playing} pro={pro} layers={layers} theme={theme} apiRef={viewportApi} onStroke={onStroke} onRail={onRail} onTransform={updateSettings} onMetrics={setMetrics} onAvatar={setAvatar} onChinHit={handleChinHit} onRaceFinish={handleRaceFinish} />
          {theme === "paper" && avatar.mode === "orbit" && !playing && (
            <PbrPalette
              activeId={activeMaterial}
              collapsed={paletteCollapsed}
              onToggle={() => setPaletteCollapsed(v => !v)}
              onPick={(entry: PaletteEntry) => {
                setActiveMaterial(entry.id);
                notify(`${entry.name} loaded on the brush. ${entry.blurb}`);
              }}
            />
          )}
          <RacePlanetOverlay
            snapshot={snapshot}
            avatar={avatar}
            playing={playing}
            activeBet={activeBet}
            activeMods={activeMods}
            hubModal={hubModal}
            onCloseModal={() => setHubModal(null)}
            onOpenModal={m => setHubModal(m)}
            onUpdateEconomy={updateEconomy}
            onPlaceBet={placeBet}
            onTogglePlay={p => setPlaying(p)}
            onSpawnSurface={m => spawnOnSurface(m)}
            onCheer={id => { viewportApi.current?.cheerAvatar(id); notify("Your 3D goblin cheered! Nearby racing spheres surged forward!"); }}
            onStepOntoTrack={() => { setPlaying(true); viewportApi.current?.stepOntoTrack(); notify("Stepped onto the slotted rail ahead of the pack! Brace your chin!"); }}
            onRespawn={() => { viewportApi.current?.respawnAvatar(); notify("Respawned your goblin on the island surface!"); }}
            onToggleMod={toggleModHook}
            onEnterGoblinLab={() => { setHubModal(null); setView("studio"); enterNode(snapshot.authoring!.bindings.goblin); }}
            notify={notify}
          />
          <div className="viewport-topbar"><div className="breadcrumbs"><button onClick={() => { setPath([snapshot.graph.rootId]); setSelected(snapshot.graph.rootId); }} title="Universe"><OrbitLogo /></button>{path.slice(1).map((id, index) => <span key={id}><ChevronRight size={11} /><button className={index === path.length - 2 ? "current" : ""} onClick={() => { setPath(path.slice(0, index + 2)); setSelected(id); setPro(false); }}>{graph.get(id).kind === "planet" ? worldName : graph.get(id).kind === "terrain" ? "Terrain" : graph.get(id).name}</button></span>)}</div><div className="view-actions"><button type="button" className={`spawn-surface-btn ${avatar.mode !== "orbit" ? "active" : ""}`} onClick={() => spawnOnSurface(avatar.mode === "third" ? "first" : "third")}><Footprints size={12} />{avatar.spawned ? (avatar.mode === "orbit" ? "Jump into body" : avatar.mode === "first" ? "1st person" : "3rd person") : "Spawn on surface"}</button>{avatar.spawned && <div className="pov-pills"><button type="button" className={avatar.mode === "first" ? "active" : ""} onClick={() => viewportApi.current?.setAvatarMode("first")}>1st person</button><button type="button" className={avatar.mode === "third" ? "active" : ""} onClick={() => viewportApi.current?.setAvatarMode("third")}>3rd person</button>{avatar.mode !== "orbit" && <button type="button" onClick={() => viewportApi.current?.setAvatarMode("orbit")}>Orbit</button>}</div>}<select aria-label="Camera view" value={avatar.mode === "first" || avatar.mode === "third" ? avatar.mode : "perspective"} onChange={e => viewportApi.current?.view(e.target.value)}><option value="perspective">Perspective</option><option value="third">3rd person</option><option value="first">1st person</option><option value="top">Top view</option><option value="front">Front view</option></select><ChevronDown size={11} /><span /><IconButton title="Fullscreen viewport" onClick={() => { if (document.fullscreenElement) void document.exitFullscreen(); else void canvasShell.current?.requestFullscreen(); }}><Maximize2 size={14} /></IconButton></div></div>
          <div className="world-title"><span className="eyebrow">{avatar.mode !== "orbit" ? (avatar.mode === "first" ? "1ST PERSON · IN YOUR GOBLIN BODY" : "3RD PERSON · ON THE SURFACE") : playing ? "LET THE MAYHEM BEGIN" : depth >= 4 ? "THE WORLD WITHIN THE WORLD" : depth === 0 ? "A CONNECTED UNIVERSE" : "A WORLD IN THE MAKING"}</span><h1>{depth === 0 ? "The Outer Wilds" : depth >= 3 ? graph.get(path[path.length - 1]).name : worldName}<span className="title-dot">.</span></h1><p>{avatar.mode !== "orbit" ? "Walk with WASD / Arrows. Drag to look around and spectate the rail." : playing ? "Pedal. Collide. Repeat." : depth >= 4 ? "The smallest details make the biggest difference." : "A little wilderness. A lot of possibility."}</p></div>
          <div className="live-badge"><span />{avatar.mode !== "orbit" ? `${avatar.mode === "first" ? "1ST" : "3RD"} PERSON LIVE` : playing ? "SIMULATION LIVE" : "LIVE PREVIEW"}</div>
          <div className="tool-rail">{([
            ["select", MousePointer2, "Select & orbit · V"], ["move", Move3D, "Pan & transform · G"], ["brush", Paintbrush, "Gel brush · B"], ["erase", Minus, "Carve · E"], ["rail", Waypoints, "Draw slotted rail · R"],
          ] as const).map(([id, Icon, title], i) => <div key={id}>{i === 2 && <span className="tool-separator" />}<IconButton title={title} active={tool === id && avatar.mode === "orbit"} onClick={() => { if (avatar.mode !== "orbit") viewportApi.current?.setAvatarMode("orbit"); setTool(id); setPlaying(false); }}><Icon size={18} strokeWidth={1.7} /></IconButton></div>)}<span className="tool-separator" /><IconButton title="Spawn on surface & jump into body" active={avatar.mode !== "orbit"} onClick={() => spawnOnSurface("third")}><Footprints size={17} /></IconButton><IconButton title="Recenter world" onClick={() => viewportApi.current?.reset()}><Target size={17} /></IconButton><IconButton className="mobile-inspector-trigger" title="Styles & presets inspector" onClick={() => setInspectorOpen(true)}><SlidersHorizontal size={17} /></IconButton></div>
          {theme === "paper" && avatar.mode === "orbit" && !playing && (
            <RadialDepthMenu
              depthLabel={graph.get(path[path.length - 1]).name}
              depthIndex={depth}
              activeKind={(contextKind === "terrain" ? "dirt" : contextKind === "biome" ? "foliage" : contextKind === "rail" ? "iron" : contextKind === "prop" ? "enamel" : contextKind === "material" ? "basalt" : null) as SwatchKind | null}
              onPick={pickWedge}
              onUp={() => { if (path.length > 1) { setPath(path.slice(0, -1)); setSelected(path[path.length - 2]); } }}
            />
          )}
          <div className="axis-compass" aria-label="World orientation"><span className="axis-y">Y</span><span className="axis-z">Z</span><span className="axis-x">X</span><i /><svg viewBox="0 0 70 70"><path d="M35 35V11M35 35l-19 13M35 35l21 12" strokeWidth="1" stroke="#75816f" /></svg></div>
          {avatar.mode !== "orbit" && (
            <div className="avatar-hud" role="region" aria-label="Surface avatar controls">
              <div className="avatar-hud-info">
                <span className="play-icon"><UserRound size={17} /></span>
                <div>
                  <strong>{avatar.mode === "first" ? "1st person · In body" : "3rd person · Surface walker"}</strong>
                  <span>Pos {avatar.position[0].toFixed(1)}, {avatar.position[1].toFixed(1)}, {avatar.position[2].toFixed(1)} · {avatar.activeCells || metrics.activeCells || 4} physics cells</span>
                </div>
              </div>
              <div className="avatar-walk-pad" role="group" aria-label="Walk controls">
                <button type="button" title="Walk forward (W)" onClick={() => nudgeWalk("forward")} onPointerDown={() => viewportApi.current?.moveAvatar("forward", true)} onPointerUp={() => viewportApi.current?.moveAvatar("forward", false)} onPointerLeave={() => viewportApi.current?.moveAvatar("forward", false)}>W</button>
                <button type="button" title="Strafe left (A)" onClick={() => nudgeWalk("left")} onPointerDown={() => viewportApi.current?.moveAvatar("left", true)} onPointerUp={() => viewportApi.current?.moveAvatar("left", false)} onPointerLeave={() => viewportApi.current?.moveAvatar("left", false)}>A</button>
                <button type="button" title="Walk backward (S)" onClick={() => nudgeWalk("backward")} onPointerDown={() => viewportApi.current?.moveAvatar("backward", true)} onPointerUp={() => viewportApi.current?.moveAvatar("backward", false)} onPointerLeave={() => viewportApi.current?.moveAvatar("backward", false)}>S</button>
                <button type="button" title="Strafe right (D)" onClick={() => nudgeWalk("right")} onPointerDown={() => viewportApi.current?.moveAvatar("right", true)} onPointerUp={() => viewportApi.current?.moveAvatar("right", false)} onPointerLeave={() => viewportApi.current?.moveAvatar("right", false)}>D</button>
                <button type="button" title="Jump on surface (Space)" onClick={() => viewportApi.current?.moveAvatar("jump", true)}>Jump</button>
              </div>
              <div className="avatar-hud-actions">
                <button type="button" className={`button button-secondary ${avatar.mode === "first" ? "active-pov" : ""}`} onClick={() => viewportApi.current?.setAvatarMode("first")}>1st person</button>
                <button type="button" className={`button button-secondary ${avatar.mode === "third" ? "active-pov" : ""}`} onClick={() => viewportApi.current?.setAvatarMode("third")}>3rd person</button>
                <button type="button" className={`button button-secondary ${avatar.spectateRail ? "active-pov" : ""}`} onClick={() => viewportApi.current?.toggleSpectateRail()}><Eye size={13} />Spectate rail</button>
                <button type="button" className="button button-secondary" onClick={() => { viewportApi.current?.cheerAvatar(activeBet?.riderId); notify("Your 3D goblin cheered! Boosted racing spheres!"); }}>Cheer</button>
                <button type="button" className="button button-secondary" onClick={() => { setPlaying(true); viewportApi.current?.stepOntoTrack(); }}>Take to Chin</button>
                <button type="button" className="button button-secondary" onClick={() => viewportApi.current?.bump()}><Zap size={13} />Cause chaos</button>
                <button type="button" className="button button-secondary" onClick={() => viewportApi.current?.setAvatarMode("orbit")}>Leave body</button>
              </div>
            </div>
          )}
          {playing && avatar.mode === "orbit" && <div className="play-hud"><span className="play-icon"><Zap size={18} /></span><div><strong>Scrap run</strong><span>3 riders · One beautifully bad idea</span></div><button className="button button-secondary" onClick={() => viewportApi.current?.bump()}><AudioLines size={15} />Cause chaos<span className="keycap">Space</span></button><button className="winch-button" title="Hold to reel onto the track" onPointerDown={() => viewportApi.current?.winch(true)} onPointerUp={() => viewportApi.current?.winch(false)} onPointerLeave={() => viewportApi.current?.winch(false)}><Link2 size={14} />Winch</button><button className="winch-button" title="Spawn on surface to spectate" onClick={() => spawnOnSurface("third")}><Footprints size={14} />Spectate on foot</button><IconButton title="Pause simulation" onClick={() => setPlaying(false)}><Pause size={17} /></IconButton></div>}
          {tool === "rail" && !playing && avatar.mode === "orbit" && <div className="canvas-context-message"><Waypoints size={14} /><span>Click the island to place rail anchors.</span><strong>{snapshot.rails.length}/64</strong>{snapshot.rails.length > 0 && <button onClick={() => commit(s => ({ ...s, rails: [] }))}>Clear</button>}</div>}
          <div className="viewport-bottom"><div className="scale-indicator"><div className="scale-line"><i /><i /><i /><i /><i /></div><span>{avatar.mode !== "orbit" ? "AVATAR SCALE" : depth === 0 ? "UNIVERSE SCALE" : depth >= 4 ? "MATERIAL SCALE" : "WORLD SCALE"}<strong>{avatar.mode !== "orbit" || depth >= 4 ? "1 : 1" : depth === 0 ? "1 : 10k" : "1 : 100"}</strong></span></div><div className="zoom-controls"><IconButton title="Zoom out" onClick={() => viewportApi.current?.zoom(-1)}><Minus size={15} /></IconButton><IconButton title="Zoom in" onClick={() => viewportApi.current?.zoom(1)}><Plus size={15} /></IconButton></div></div>
          <div className="canvas-status"><div><span className="online-dot" />{metrics.fps ? `${metrics.fps} FPS` : "INITIALIZING"}<i />{metrics.triangles ? `${(metrics.triangles / 1000).toFixed(1)}k triangles` : "Procedural scene"}<i /><span className="renderer-label">WebGL 2</span></div><div className="canvas-hints">{avatar.mode !== "orbit" ? <><kbd>WASD</kbd> Walk<kbd>Space</kbd> Jump<kbd>C</kbd> 1st/3rd<kbd>Drag</kbd> Look</> : playing ? <><kbd>W</kbd> Winch<kbd>⇧</kbd> Boost</> : depth >= 4 ? <><kbd>Drag</kbd> Orbit<kbd>Scroll</kbd> Zoom</> : <><kbd>LMB</kbd> Grow<kbd>RMB</kbd> Carve<kbd>Scroll</kbd> Zoom</>}</div></div>
        </div>
        <section className="preset-dock"><div className="dock-heading"><div><Sparkles size={13} /><span className="eyebrow">A STARTING POINT FOR ANYTHING</span></div><button className="dock-enter-tree" aria-label="Edit tree & textures" onClick={() => enterNode(snapshot.authoring!.bindings.tree)}>Edit tree & textures<ArrowDownRight size={13} /></button><button onClick={() => setView("discover")}>Explore presets<ArrowUpRight size={13} /></button></div><div className="preset-cards">{(Object.entries(STYLE_META) as [WorldStyle, typeof style][]).map(([id, meta]) => <button key={id} className={`preset-card ${snapshot.style === id ? "selected" : ""}`} onClick={() => applyStyle(id)}><div className="preset-thumb"><img src={meta.image} alt={`${meta.name} procedural world`} />{snapshot.style === id && <span><Check size={11} /></span>}</div><div className="preset-copy"><span className={`preset-category category-${id}`}>{meta.tag}</span><strong>{meta.name}</strong><small>{id === "verdant" ? "Wild by nature" : id === "dunes" ? "A warmer kind of chaos" : "Out of this world"}</small></div></button>)}</div></section>
      </main>

      <div className={`mobile-properties-backdrop ${inspectorOpen ? "visible" : ""}`} onClick={() => setInspectorOpen(false)} /><aside className={`properties ${inspectorOpen ? "mobile-open" : ""} ${sheet === "inspector" ? "sheet-open" : ""}`}><div className="mobile-properties-heading"><span className="eyebrow">TOOL INSPECTOR</span><IconButton title="Close tool inspector" onClick={() => setInspectorOpen(false)}><X size={16} /></IconButton></div>
        <div className="properties-tabs"><button className={rightTab === "presets" ? "active" : ""} onClick={() => setRightTab("presets")}><SlidersHorizontal size={14} />Styles & presets</button><button className={rightTab === "engine" ? "active" : ""} onClick={() => setRightTab("engine")}><Cpu size={14} />Engine</button></div>
        <div className="properties-scroll">{rightTab === "presets" ? <>
          <div className="brush-heading"><span className="brush-icon">{pro ? <Move3D size={19} /> : <Paintbrush size={19} />}</span><div><h2>{pro ? "Material workshop" : "Gel brush"}</h2><p>{pro ? "The building blocks of everything." : "Paint a little possibility."}</p></div><span className="live-small"><span />LIVE</span></div>
          <div className="active-preset"><div className="active-preset-art"><img src={style.image} alt={style.name} /><span className="preset-art-label"><Layers3 size={11} />{pro ? "BASE MATERIAL" : "BIOME PRESET"}</span><button title="Choose a preset" onClick={() => setModal("presets")}><Maximize2 size={13} /></button></div><div className="active-preset-title"><div><strong>{pro ? "Weathered sandstone" : snapshot.style === "verdant" ? "Alpine forest" : style.name}</strong><span>{pro ? "PBR · PROCEDURAL" : "PROCEDURAL · 8 ASSETS"}</span></div><span className="preset-check"><Check size={13} /></span></div></div>
          <button className="change-preset" onClick={() => setModal("presets")}><Layers3 size={14} />Change preset<ChevronRight size={13} /></button>{!pro && <button className="edit-tree-entry" onClick={() => enterNode(snapshot.authoring!.bindings.tree)}><Leaf size={13} />Edit tree, leaves & textures<ArrowDownRight size={13} /></button>}
          {pro ? <><div className="section-label">PRECISE MANIPULATORS<span>PRO</span></div><div className="manipulator-grid"><button onClick={() => { setTool("select"); viewportApi.current?.manipulate("translate"); }}><Move3D size={17} />Translate</button><button onClick={() => viewportApi.current?.manipulate("rotate")}><RotateCw size={17} />Rotate</button><button onClick={() => viewportApi.current?.manipulate("scale")}><Maximize2 size={17} />Scale</button><button onClick={() => { updateSettings({ materialDetail: Math.max(0, snapshot.settings.materialDetail - 1) }); notify(snapshot.settings.materialDetail > 0 ? "Material geometry decimated. Fewer faces, the same foundation." : "Geometry is already at its coarsest level."); }}><Grip size={17} />Decimate</button></div><div className="slider-field"><label htmlFor="roughness">Roughness <span>{snapshot.settings.roughness.toFixed(2)}</span></label><input id="roughness" type="range" min="0" max="1" step="0.01" value={snapshot.settings.roughness} onChange={e => updateSettings({ roughness: Number(e.target.value) })} /></div><div className="slider-field"><label htmlFor="material-scale">Object scale <span>{snapshot.settings.materialScale.toFixed(1)}×</span></label><input id="material-scale" type="range" min="0.1" max="3" step="0.1" value={snapshot.settings.materialScale} onChange={e => updateSettings({ materialScale: Number(e.target.value) })} /></div><div className="slider-field"><label htmlFor="rotation">Rotation <span>{snapshot.settings.materialRotation}°</span></label><input id="rotation" type="range" min="0" max="360" value={snapshot.settings.materialRotation} onChange={e => updateSettings({ materialRotation: Number(e.target.value) })} /></div><div className="material-info"><ShieldCheck size={15} /><span>Pinned to material revision 1.0.<br />Your edits stay in this branch.</span></div></> : <>
          <div className="brush-mode"><button className={tool !== "erase" ? "active" : ""} onClick={() => setTool("brush")}><Sprout size={14} />Grow</button><button className={tool === "erase" ? "active" : ""} onClick={() => setTool("erase")}><Minus size={14} />Carve</button></div>
          <div className="section-label">BRUSH PROPERTIES<Settings2 size={12} /></div>
          <div className="slider-field"><label htmlFor="brush-radius">Radius <span>{snapshot.settings.radius.toFixed(1)} <em>m</em></span></label><input id="brush-radius" type="range" min="0.3" max="9" step="0.1" value={snapshot.settings.radius} style={{ "--range-fill": `${(snapshot.settings.radius - 0.3) / 8.7 * 100}%` } as React.CSSProperties} onChange={e => updateSettings({ radius: Number(e.target.value) })} /><div className="range-labels"><span>Micro</span><span>World</span></div></div>
          <div className="slider-field density-field"><label htmlFor="brush-density">Density <span>{snapshot.settings.density}<em>%</em></span></label><input id="brush-density" type="range" min="5" max="100" value={snapshot.settings.density} style={{ "--range-fill": `${snapshot.settings.density}%` } as React.CSSProperties} onChange={e => updateSettings({ density: Number(e.target.value) })} /></div>
          <div className="auto-size"><div><span><Sparkles size={13} />AutoSize<span className="default-tag">AUTO</span></span><small>Let your brush set the scale.</small></div><Toggle label="AutoSize engine" value={snapshot.settings.autoSize} onChange={() => updateSettings({ autoSize: !snapshot.settings.autoSize })} /></div>
          <div className="auto-size-level"><span />{AutoSizeEngine.resolve(snapshot.settings.radius * 2, snapshot.settings.autoSize).tier}<span>{AutoSizeEngine.resolve(snapshot.settings.radius * 2, snapshot.settings.autoSize).scale.toFixed(2)}×</span></div>
          <div className="surface-section"><div className="section-label">SURFACE EMBODIMENT<Footprints size={12} /></div><div className="embodiment-card"><div><strong>{avatar.spawned ? (avatar.mode === "orbit" ? "Goblin spawned on surface" : `Walking in ${avatar.mode === "first" ? "1st" : "3rd"} person`) : "Walk your little world"}</strong><small>Spawn your 3D goblin onto the island and spectate in 1st or 3rd person.</small></div><div className="embodiment-buttons"><button type="button" className={avatar.mode === "third" ? "active" : ""} onClick={() => spawnOnSurface("third")}>3rd person</button><button type="button" className={avatar.mode === "first" ? "active" : ""} onClick={() => spawnOnSurface("first")}>1st person</button>{avatar.mode !== "orbit" && <button type="button" onClick={() => viewportApi.current?.setAvatarMode("orbit")}>Orbit</button>}</div></div><div className="section-label">INTELLIGENT BY NATURE</div><div><span className="feature-check"><Check size={11} /></span><span>Slope-aware & prop-pushing<small>Strokes push existing trees aside cleanly</small></span><CircleHelp size={12} /></div><div><span className="feature-check"><Check size={11} /></span><span>Non-destructive strokes<small>Undo, branch, and start again</small></span><CircleHelp size={12} /></div></div>
          <div className="brush-tip"><span><Sparkles size={14} /></span><p>A little gel. A whole new world.<small>Scroll to get closer to the details.</small></p></div>
          </>}
        </> : <>
          <div className="brush-heading"><span className="brush-icon"><Cpu size={20} /></span><div><h2>Your world engine</h2><p>One graph. Your point of view.</p></div></div>
          <div className="engine-profile"><span className="online-dot" /><strong>Local hardware</strong><span className="engine-auto">ADAPTIVE</span><p>Fidelity follows your device.<br />Physics islands resolve at 1:1 scale.</p><div><span>{metrics.fps || "—"}<small>FPS</small></span><span>{metrics.calls || "—"}<small>DRAW CALLS</small></span><span>{metrics.activeCells ?? (avatar.activeCells || 4)}<small>PHYSICS CELLS</small></span></div></div>
          <div className="section-label">RENDER PIPELINE</div><div className="pipeline-options">{ENGINE_PACKAGES.map(pkg => <button key={pkg.name} className={snapshot.settings.renderStyle === pkg.renderStyle ? "active" : ""} onClick={() => updateSettings({ renderStyle: pkg.renderStyle })}><span className="pipeline-icon">{pkg.renderStyle === "standard" ? <Box size={18} /> : pkg.renderStyle === "cinematic" ? <Sparkles size={18} /> : <Waypoints size={18} />}</span><span><strong>{pkg.name}</strong><small>{pkg.renderStyle === "standard" ? "Balanced · Built-in" : pkg.renderStyle === "cinematic" ? "Warm exposure · Built-in" : "Inspect geometry · Built-in"}</small></span>{snapshot.settings.renderStyle === pkg.renderStyle ? <Check size={14} /> : <span className="radio-outline" />}</button>)}</div>
          <div className="section-label">QUALITY BUDGET</div><select className="quality-select" aria-label="Graphics quality" value={snapshot.settings.quality} onChange={e => updateSettings({ quality: e.target.value as StudioSettings["quality"] })}><option value="auto">Auto · Match my hardware</option><option value="performance">Performance · Low GPU budget</option><option value="high">High · Maximum fidelity</option></select>
          <div className="plugin-security"><ShieldCheck size={18} /><strong>Creative, not executable.</strong><p>Import a declarative engine preset. Untrusted scripts never run in your workspace.</p><button className="button button-secondary" onClick={() => fileInput.current?.click()}><Download size={13} />Import package</button><input type="file" ref={fileInput} accept=".json" hidden onChange={e => { const file = e.target.files?.[0]; if (file) void importPackage(file); e.target.value = ""; }} /></div>
          <button className="diagnostics-button" disabled={diagnosing} onClick={runDiagnostics}>{diagnosing ? <LoaderCircle size={14} className="spin" /> : <Zap size={14} />}{diagnostics ? `Worker verified · ${diagnostics.latency} ms` : "Run worker diagnostics"}<ArrowRight size={13} /></button>
        </>}</div>
        <div className="pro-section"><div><span><Box size={15} />Pro mode<span className="pro-label">PRO</span></span><small>{pro ? "You’re at the foundation of your world." : "Get to the heart of your world."}</small></div><Toggle label="Pro mode" value={pro} onChange={() => { if (pro) setPro(false); else enterPro(); }} />{!pro && <button onClick={enterPro}>Explore base materials<ArrowDownRight size={12} /></button>}</div>
      </aside>
    </div> : <main className="library"><div className="library-intro"><div><div className="eyebrow lime">{view === "discover" ? "THE COMMUNITY UNIVERSE" : "EVERY IDEA DESERVES A WORLD"}</div><h1>{view === "discover" ? <>Find your next <span>possibility.</span></> : <>Small worlds. <span>All yours.</span></>}</h1><p>{view === "discover" ? "Start with a little inspiration. Branch it into something completely your own." : "Your creations, experiments, and beautifully bad ideas. Right where you left them."}</p></div><div className="library-illustration"><OrbitLogo /><Globe2 /><span>INFINITE BY DESIGN</span></div></div><div className="library-toolbar"><div className="library-filters">{(view === "discover" ? ["All worlds", "Forest", "Desert", "Cosmic"] : ["All worlds", "Private", "Public"]).map(item => <button key={item} className={filter === item ? "active" : ""} onClick={() => setFilter(item)}>{item}</button>)}</div><div className="library-search"><Search size={16} /><input aria-label="Search worlds" placeholder="Find a little world…" value={librarySearch} onChange={e => setLibrarySearch(e.target.value)} /></div></div>
      {view === "discover" && <><div className="library-section-heading"><h2>Worlds to get lost in<span>CURATED STARTERS</span></h2><span>Made to be made your own<ArrowDownRight size={14} /></span></div><div className="world-grid">{(Object.entries(STYLE_META) as [WorldStyle, typeof style][]).filter(([id, meta]) => meta.name.toLowerCase().includes(librarySearch.toLowerCase()) && (filter === "All worlds" || filter.toUpperCase() === meta.tag)).map(([id, meta]) => <div key={id} className="world-card"><button className="world-card-image" onClick={() => openTemplate(id)}><img src={meta.image} alt={meta.name} /><span className={`preset-category category-${id}`}>{meta.tag}</span><span className="world-card-enter"><ArrowUpRight size={22} /></span></button><div className="world-card-details"><h3>{meta.name}</h3><p>{meta.description}</p><div><span className="template-avatar"><BrandMark /></span><span>HeavyMetal studio<small>12 nodes · Version-locked</small></span><button className="text-button" onClick={() => openTemplate(id)}>Make it yours<ArrowUpRight size={14} /></button></div></div></div>)}</div></>}
      <div className="library-section-heading"><h2>{view === "discover" ? "From the community" : "Your creations"}<span>{filteredWorlds.length} WORLD{filteredWorlds.length !== 1 ? "S" : ""}</span></h2>{view === "worlds" && <button className="text-button" onClick={exportWorld}><Download size={14} />Export current draft</button>}</div>{loadingWorlds ? <div className="library-empty"><LoaderCircle className="spin" size={26} /><p>Finding your worlds…</p></div> : filteredWorlds.length ? <div className="world-grid">{filteredWorlds.map(world => <div className="world-card" key={world.id}><button className="world-card-image" onClick={() => loadWorld(world)}><img src={STYLE_META[world.snapshot.style].image} alt={world.name} /><span className="world-visibility">{world.visibility === "public" ? <Globe2 size={12} /> : <LockKeyhole size={12} />}{world.visibility}</span><span className="world-card-enter"><ArrowUpRight size={22} /></span></button><div className="world-card-details"><h3>{world.name}</h3><p>{world.parentId ? "A new branch. A different kind of possibility." : `${world.snapshot.strokes.length} brush strokes · ${world.snapshot.rails.length} rail anchors`}</p><div><span className="template-avatar"><Globe2 size={18} /></span><span>{world.owned ? "Your workspace" : "Community creator"}<small>Revision {world.version} · {new Date(world.updatedAt).toLocaleDateString()}</small></span><button className="text-button" onClick={() => loadWorld(world)}>Open<ArrowUpRight size={14} /></button>{world.owned && <IconButton title={`Archive ${world.name}`} onClick={() => archive(world)}><Trash2 size={14} /></IconButton>}</div></div></div>)}</div> : <div className="library-empty"><span className="empty-world"><Globe2 size={30} /><Sparkles size={14} /></span><h3>{librarySearch ? "No worlds in this corner of the universe." : view === "discover" ? "The universe has room for your world." : "Your first world is waiting."}</h3><p>{view === "discover" ? "Create something, publish it, and be the first to share a little possibility." : "Save your sandbox or start fresh. Every big idea begins small."}</p><button className="button button-primary" onClick={() => view === "discover" ? publish() : openSave("save")}><Plus size={14} />{view === "discover" ? "Publish your world" : "Save your first world"}</button></div>}
    </main>}

    <footer className="app-footer"><div><span className="online-dot" /><span>{ready ? "Local workspace connected" : "Connecting workspace…"}</span><i /><span className="footer-version">ENGINE v0.3.0</span></div><div className="footer-message"><Sparkles size={11} /><span>Built for a little chaos. Designed for infinite possibility.</span></div><div><span>SEED <strong>{snapshot.seed}</strong></span><i /><span className="lod-status"><span />LOD ADAPTIVE</span><button onClick={() => { setGuideTab("Controls"); setModal("guide"); }}>Shortcuts<CircleHelp size={12} /></button></div></footer>

    {view === "studio" && !authoringNodeId && (
      <>
        {sheet !== "none" && <div className="sheet-scrim" onClick={() => setSheet("none")} aria-hidden="true" />}
        <nav className="sheet-bar" aria-label="Panels">
          <button type="button" className={sheet === "explorer" ? "active" : ""} aria-pressed={sheet === "explorer"} onClick={() => setSheet(s => s === "explorer" ? "none" : "explorer")}>
            <Waypoints size={16} /><span>World</span>
          </button>
          <button type="button" className={sheet === "inspector" ? "active" : ""} aria-pressed={sheet === "inspector"} onClick={() => setSheet(s => s === "inspector" ? "none" : "inspector")}>
            <SlidersHorizontal size={16} /><span>Tools</span>
          </button>
          <button type="button" onClick={() => { setSheet("none"); setChainOpen(true); }}>
            <Boxes size={16} /><span>Presets</span>
          </button>
          <button type="button" onClick={() => { setSheet("none"); setUiOpen(true); }}>
            <Palette size={16} /><span>Skin</span>
          </button>
        </nav>
      </>
    )}
    {uiOpen && <InterfaceStudio recipe={ui} onChange={setUi} onClose={() => setUiOpen(false)} notify={notify} />}
    {networkOpen && snapshot.authoring && (
      <PresetNetwork
        snapshot={snapshot}
        activeId={authoringNodeId ?? snapshot.authoring.bindings.tree}
        onEnter={id => enterNode(id)}
        onClose={() => setNetworkOpen(false)}
      />
    )}
    {chainOpen && snapshot.authoring && (
      <PresetChainPanel
        snapshot={snapshot}
        nodeId={authoringNodeId ?? snapshot.authoring.bindings.object ?? snapshot.authoring.bindings.tree}
        onClose={() => setChainOpen(false)}
        onPickPrimitive={pickPrimitive}
        onImportPackage={importSharedPackage}
        notify={notify}
      />
    )}
    {toast && <div className={`toast ${toast.error ? "error" : ""}`} role="status">{toast.error ? <CircleHelp size={18} /> : <CheckCheck size={18} />}<span>{toast.message}</span><button aria-label="Dismiss notification" onClick={() => setToast(null)}><X size={14} /></button></div>}

    {(modal === "save" || modal === "branch" || modal === "publish" || modal === "new") && <Modal onClose={closeModal} title={modal === "branch" ? "A world of your own." : modal === "publish" ? "Let your world out." : modal === "new" ? "Start a little something." : "Keep every little detail."} subtitle={modal === "branch" ? "Branch this preset. The original stays exactly as it is." : modal === "publish" ? "Share your creation with the community universe." : "Your world and every pinned dependency are saved together."}><form onSubmit={e => { e.preventDefault(); void persist(modal === "publish" && visibility === "private" ? "save" : modal, tempName, visibility); }}><label className="form-label" htmlFor="world-name">WORLD NAME</label><input id="world-name" className="text-input" value={tempName} maxLength={80} required autoFocus onChange={e => setTempName(e.target.value)} /><label className="form-label">VISIBILITY</label><div className="visibility-options"><button type="button" className={visibility === "private" ? "active" : ""} onClick={() => setVisibility("private")}><LockKeyhole size={19} /><strong>Just me</strong><span>Your private corner of the universe.</span>{visibility === "private" && <Check size={14} />}</button><button type="button" className={visibility === "public" ? "active" : ""} onClick={() => setVisibility("public")}><Globe2 size={19} /><strong>Everyone</strong><span>Let the community explore and branch.</span>{visibility === "public" && <Check size={14} />}</button></div><div className="save-summary"><ShieldCheck size={16} /><span>Immutable revisions. Pinned dependencies.<br />Your original ideas are always preserved.</span><span>{Object.keys(snapshot.graph.nodes).length} NODES</span></div><div className="modal-footer"><button type="button" className="button button-secondary" onClick={closeModal}>Not now</button><button className="button button-primary" type="submit" disabled={saving || !tempName.trim()}>{saving ? <LoaderCircle size={15} className="spin" /> : modal === "branch" ? <GitBranch size={15} /> : modal === "publish" ? <Globe2 size={15} /> : <Save size={15} />}{saving ? "Saving your world…" : modal === "branch" ? "Create branch" : modal === "publish" ? "Publish world" : "Save world"}<ArrowUpRight size={14} /></button></div></form></Modal>}
    {modal === "share" && currentWorld && <Modal title="A little world. Out there." subtitle="Your creation is live in the community universe." onClose={closeModal}><div className="share-preview"><img src={style.image} alt={worldName} /><div><Globe2 size={19} /><h3>{worldName}</h3><span>PUBLIC WORLD · REVISION {currentWorld.version}</span></div></div><label className="form-label" htmlFor="share-link">YOUR WORLD LINK</label><div className="share-link"><input id="share-link" readOnly value={typeof window !== "undefined" ? `${window.location.origin}/?world=${currentWorld.id}` : ""} onFocus={e => e.target.select()} /><button onClick={copyLink}>{copied ? <Check size={16} /> : <Copy size={16} />}{copied ? "Copied" : "Copy"}</button></div><p className="share-note"><GitBranch size={14} />Visitors can explore and branch. Only you can edit the original.</p><div className="modal-footer"><button className="button button-secondary" onClick={() => { setModal(null); setView("discover"); }}>View in Discover<ArrowUpRight size={14} /></button><button className="button button-primary" onClick={closeModal}>Back to my world</button></div></Modal>}
    {modal === "presets" && <Modal wide title="Pick a little possibility." subtitle="Different worlds. The same infinite canvas." onClose={closeModal}><div className="preset-picker">{(Object.entries(STYLE_META) as [WorldStyle, typeof style][]).map(([id, meta]) => <button key={id} className={snapshot.style === id ? "active" : ""} onClick={() => applyStyle(id)}><img src={meta.image} alt={meta.name} /><span className={`preset-category category-${id}`}>{meta.tag}</span><strong>{meta.name}</strong><p>{meta.description}</p><span className="picker-action">{snapshot.style === id ? "Current preset" : "Apply to your world"}{snapshot.style === id ? <Check size={15} /> : <ArrowUpRight size={15} />}</span></button>)}</div></Modal>}
    {modal === "menu" && <Modal title="Your world. Your call." subtitle="A few things you can do with this little universe." onClose={closeModal}><div className="world-actions"><button onClick={() => openSave("branch")}><GitBranch size={20} /><span><strong>Create a branch</strong><small>Take your world in a new direction.</small></span><ArrowUpRight size={17} /></button><button onClick={showHistory}><RotateCcw size={20} /><span><strong>Revision history</strong><small>Restore an earlier moment.</small></span><ChevronRight size={17} /></button><button onClick={() => { exportWorld(); setModal(null); }}><Download size={20} /><span><strong>Export world graph</strong><small>Coordinates, seeds, and pinned dependencies.</small></span><ArrowDownLeft size={17} /></button><button onClick={() => { commit(() => createDefaultSnapshot(snapshot.style)); setModal(null); notify("Preset reset. Undo is here if you change your mind."); }}><RotateCcw size={20} /><span><strong>Reset to preset</strong><small>Start fresh without losing your branch.</small></span><ChevronRight size={17} /></button>{currentWorld?.owned && <button className="danger" onClick={() => archive(currentWorld)}><Trash2 size={20} /><span><strong>Archive world</strong><small>Keep its history, hide it from your library.</small></span><ChevronRight size={17} /></button>}</div></Modal>}
    {modal === "history" && <Modal title="Every little moment." subtitle="Immutable snapshots. Restore any revision as a new working draft." onClose={closeModal}><div className="revision-list">{revisions.map(revision => <div key={revision.version}><span className="revision-number">r{revision.version}</span><div><strong>{revision.message}</strong><span>{new Date(revision.createdAt).toLocaleString()}</span></div><button className="button button-secondary" onClick={() => { commit(() => revision.snapshot); setModal(null); notify(`Revision ${revision.version} restored to your draft. Save to commit it as a new revision.`); }}>Restore<RotateCcw size={12} /></button></div>)}</div></Modal>}
    {modal === "guide" && <Modal wide title="Infinite by design." subtitle="The engineering behind your little universe. And the tools to make it yours." onClose={closeModal}><div className="guide-tabs"><a className="authoring-guide-link" href="/handoff" target="_blank" rel="noreferrer"><Leaf size={13} />Agent handoff &amp; features</a><a className="authoring-guide-link" href="/PLAN.md" target="_blank" rel="noreferrer">The plan</a><a className="authoring-guide-link" href="/AUTHORING.md" target="_blank" rel="noreferrer">Authoring detail</a>{["Architecture", "Controls", "Art briefs"].map(tab => <button key={tab} className={guideTab === tab ? "active" : ""} onClick={() => setGuideTab(tab)}>{tab}</button>)}<a href="/ENGINEERING.md" download><Download size={14} />Full specification</a></div><div className="guide-content">{guideTab === "Architecture" ? <><div className="prototype-notice"><Code2 size={19} /><div><strong>A runnable prototype. An implementation-ready roadmap.</strong><p>Local creation, rail simulation, and versioned storage work today. Authoritative multiplayer, unrestricted scale, and executable community plugins are explicitly future work.</p></div></div>{ARCHITECTURE.map(section => <section className="architecture-section" key={section.number}><span>{section.number}</span><div><div className="eyebrow lime">{section.subtitle}</div><h3>{section.title}</h3><p>{section.description}</p><ul>{section.details.map(detail => <li key={detail}>{detail}</li>)}</ul></div></section>)}<div className="milestones"><h3>The path from little to limitless</h3>{MILESTONES.map((item, i) => <div key={item}><span className={i < 3 ? "done" : ""}>{i < 3 ? <Check size={12} /> : i + 1}</span>{item}<small>{i < 3 ? "PROTOTYPE" : "ROADMAP"}</small></div>)}</div><a className="button button-secondary" href="/prototype.html" target="_blank" rel="noreferrer"><ExternalLink size={14} />Open standalone Three.js test scene</a></> : guideTab === "Controls" ? <><div className="controls-intro"><MousePointer2 size={27} /><h3>A few keys. A lot of possibility.</h3><p>Select Build to create, or Play to put your beautifully bad ideas to the test.</p></div><div className="controls-list">{controls.map(([label, keys]) => <div key={label}><span>{label}</span><kbd>{keys}</kbd></div>)}</div><div className="material-info"><Layers3 size={18} /><span>Double-click a hierarchy node to enter its tiny world.<br />Pro mode takes you straight to the base material level.</span></div></> : <div className="art-briefs">{ART_BRIEFS.map(brief => <section key={brief.tag}><div className="eyebrow lime">{brief.tag}</div><h3>{brief.title}</h3><p>{brief.prompt}</p><button className="button button-secondary" onClick={async () => { try { await navigator.clipboard.writeText(brief.prompt); notify("Art direction copied. Ready for your downstream agent."); } catch { notify("Clipboard unavailable. Select the brief to copy it.", true); } }}><Copy size={13} />Copy generative brief</button></section>)}</div>}</div></Modal>}
  </div>;
}
