"use client";
import { useEffect, useRef } from "react";
import { bakeTexturePixels, textureCanvas } from "@/lib/engine/textures";
import type { SurfaceMark, TextureRecipe } from "@/lib/engine/authoring";

export default function TexturePreview({ recipe, marks = [], source = null, channel = "baseColor", label }: { recipe: TextureRecipe; marks?: SurfaceMark[]; source?: TextureRecipe | null; channel?: "baseColor" | "normal" | "roughness" | "height"; label?: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => { if (!ref.current) return; const pixels = bakeTexturePixels(recipe, marks, source, 128); ref.current.getContext("2d")?.drawImage(textureCanvas(pixels, channel), 0, 0, 128, 128); }, [recipe, marks, source, channel]);
  return <canvas ref={ref} width={128} height={128} aria-label={label ?? `${recipe.pattern} ${channel} texture preview`} className="texture-preview" />;
}
