"use client";

import { iconPaths, type IconName, type IconSetId } from "@/lib/engine/icon-sets";

interface Props {
  name: IconName;
  set: IconSetId;
  size?: number;
  weight?: number;
  round?: number;
  className?: string;
}

/**
 * Renders an icon from the active interface preset's icon set.
 * Geometry comes from the set; weight and joins come from the sculpted recipe.
 */
export default function UIIcon({ name, set, size = 18, weight, round = 0, className }: Props) {
  const paths = iconPaths(set, name);
  const cap = round > 0.5 ? "round" : "square";
  return (
    <svg
      className={className}
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={weight ?? 1.5}
      strokeLinecap={cap}
      strokeLinejoin={round > 0.5 ? "round" : "miter"}
      aria-hidden="true"
      focusable="false"
    >
      {paths.map((d, i) => <path key={i} d={d} />)}
    </svg>
  );
}
