"use client";

import { useEffect, useRef, useState, type RefObject } from "react";
import { SandboxScene, type AvatarMoveAction } from "@/lib/engine/scene";
import { STYLE_META, type AvatarCameraMode, type AvatarStatus, type BrushStroke, type RacerStanding, type SceneMetrics, type StudioSettings, type StudioTool, type Vec3, type WorldSnapshot } from "@/lib/engine/types";

export interface ViewportHandle {
  zoom: (direction: number) => void;
  reset: () => void;
  view: (view: string) => void;
  bump: () => void;
  winch: (active: boolean) => void;
  manipulate: (mode: "translate" | "rotate" | "scale") => void;
  spawnAvatar: (mode?: "third" | "first", point?: Vec3) => void;
  setAvatarMode: (mode: AvatarCameraMode) => void;
  moveAvatar: (action: AvatarMoveAction, active: boolean) => void;
  toggleSpectateRail: (force?: boolean) => void;
  cheerAvatar: (targetRiderId?: string) => void;
  stepOntoTrack: () => void;
  respawnAvatar: () => void;
}
interface Props {
  snapshot: WorldSnapshot;
  tool: StudioTool;
  depth: number;
  playing: boolean;
  pro: boolean;
  layers: Record<string, boolean>;
  theme: "deep" | "paper";
  apiRef: RefObject<ViewportHandle | null>;
  onStroke: (stroke: BrushStroke) => void;
  onRail: (point: Vec3) => void;
  onTransform: (changes: Partial<StudioSettings>) => void;
  onMetrics: (metrics: SceneMetrics) => void;
  onAvatar?: (status: AvatarStatus) => void;
  onChinHit?: (riderId: string, riderName: string, totalChinHits: number) => void;
  onRaceFinish?: (winnerId: string, winnerName: string, standings: RacerStanding[]) => void;
}
export default function WorldViewport(props: Props) {
  const mount = useRef<HTMLDivElement>(null);
  const scene = useRef<SandboxScene | null>(null);
  const latest = useRef(props); latest.current = props;
  const [error, setError] = useState(false);
  useEffect(() => {
    if (!mount.current) return;
    try {
      const p = latest.current;
      const instance = new SandboxScene(mount.current, p.snapshot, { tool: p.tool, depth: p.depth, playing: p.playing, pro: p.pro, layers: p.layers, theme: p.theme }, {
        onStroke: stroke => latest.current.onStroke(stroke),
        onRail: point => latest.current.onRail(point),
        onTransform: changes => latest.current.onTransform(changes),
        onMetrics: metrics => latest.current.onMetrics(metrics),
        onAvatar: status => latest.current.onAvatar?.(status),
        onChinHit: (id, name, hits) => latest.current.onChinHit?.(id, name, hits),
        onRaceFinish: (id, name, standings) => latest.current.onRaceFinish?.(id, name, standings),
      });
      scene.current = instance;
      p.apiRef.current = {
        zoom: d => instance.zoom(d),
        reset: () => instance.resetCamera(),
        view: v => instance.cameraView(v),
        bump: () => instance.bump(),
        winch: active => instance.winch(active),
        manipulate: mode => instance.setManipulator(mode),
        spawnAvatar: (mode, point) => instance.spawnAvatar(mode, point),
        setAvatarMode: mode => instance.setAvatarMode(mode),
        moveAvatar: (action, active) => instance.moveAvatar(action, active),
        toggleSpectateRail: force => instance.toggleSpectateRail(force),
        cheerAvatar: id => instance.cheerAvatar(id),
        stepOntoTrack: () => instance.stepOntoTrack(),
        respawnAvatar: () => instance.respawnAvatar(),
      };
      return () => { instance.dispose(); scene.current = null; p.apiRef.current = null; };
    } catch (cause) { console.error("WebGL initialization:", cause); setError(true); }
  }, []);
  useEffect(() => { scene.current?.setSnapshot(props.snapshot); }, [props.snapshot]);
  useEffect(() => { scene.current?.setOptions({ tool: props.tool, depth: props.depth, playing: props.playing, pro: props.pro, layers: props.layers, theme: props.theme }); }, [props.tool, props.depth, props.playing, props.pro, props.layers, props.theme]);
  return <div ref={mount} className="webgl-mount">{error && <div className="webgl-fallback"><img src={STYLE_META[props.snapshot.style].image} alt="Floating island preview" /><div><strong>World preview</strong><p>WebGL is unavailable on this device. Preset editing, branching, and saving still work.</p></div></div>}</div>;
}
