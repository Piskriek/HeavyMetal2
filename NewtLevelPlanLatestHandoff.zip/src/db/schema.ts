import { boolean, integer, jsonb, pgTable, primaryKey, text, timestamp, uuid, index } from "drizzle-orm/pg-core";
import type { WorldSnapshot } from "@/lib/engine/types";
import type { PresetKind, PresetPackage } from "@/lib/engine/authoring";

export const worlds = pgTable("hm2_worlds", {
  id: uuid("id").defaultRandom().primaryKey(),
  ownerToken: text("owner_token").notNull(),
  name: text("name").notNull(),
  snapshot: jsonb("snapshot").$type<WorldSnapshot>().notNull(),
  parentId: uuid("parent_id"),
  version: integer("version").notNull().default(1),
  visibility: text("visibility").$type<"private" | "public">().notNull().default("private"),
  archived: boolean("archived").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, table => [index("hm2_world_owner_idx").on(table.ownerToken), index("hm2_world_public_idx").on(table.visibility)]);

export const worldRevisions = pgTable("hm2_world_revisions", {
  worldId: uuid("world_id").notNull().references(() => worlds.id, { onDelete: "cascade" }),
  version: integer("version").notNull(),
  snapshot: jsonb("snapshot").$type<WorldSnapshot>().notNull(),
  message: text("message").notNull().default("World saved"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, table => [primaryKey({ columns: [table.worldId, table.version] })]);

export const authoringPresets = pgTable("hm2_authoring_presets", {
  id: uuid("id").defaultRandom().primaryKey(),
  ownerToken: text("owner_token").notNull(),
  name: text("name").notNull(),
  kind: text("kind").$type<PresetKind>().notNull(),
  package: jsonb("package").$type<PresetPackage>().notNull(),
  contentHash: text("content_hash").notNull(),
  visibility: text("visibility").$type<"private" | "public">().notNull().default("private"),
  shareCode: text("share_code"),
  useCount: integer("use_count").notNull().default(0),
  remixCount: integer("remix_count").notNull().default(0),
  authorHandle: text("author_handle").notNull().default("Goblin builder"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, table => [index("hm2_preset_owner_idx").on(table.ownerToken)]);

export const shareProfiles = pgTable("hm2_share_profiles", {
  ownerToken: text("owner_token").primaryKey(),
  handle: text("handle").notNull().default("Goblin builder"),
  autoShare: boolean("auto_share").notNull().default(false),
  shareOnEntry: boolean("share_on_entry").notNull().default(false),
  shareWhenTalking: boolean("share_when_talking").notNull().default(true),
  sharesGiven: integer("shares_given").notNull().default(0),
  remixCredits: integer("remix_credits").notNull().default(0),
  scrapFromSharing: integer("scrap_from_sharing").notNull().default(0),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const presetUses = pgTable("hm2_preset_uses", {
  id: uuid("id").defaultRandom().primaryKey(),
  presetId: uuid("preset_id").notNull().references(() => authoringPresets.id, { onDelete: "cascade" }),
  userToken: text("user_token").notNull(),
  action: text("action").$type<"use" | "remix">().notNull().default("use"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, table => [index("hm2_preset_use_idx").on(table.presetId)]);

export const raceLeaderboard = pgTable("hm2_race_leaderboard", {
  id: uuid("id").defaultRandom().primaryKey(),
  ownerToken: text("owner_token").notNull(),
  goblinName: text("goblin_name").notNull(),
  wins: integer("wins").notNull().default(0),
  scrapEarned: integer("scrap_earned").notNull().default(250),
  chinHits: integer("chin_hits").notNull().default(0),
  islandScale: text("island_scale").notNull().default("1.00"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const planetChat = pgTable("hm2_planet_chat", {
  id: uuid("id").defaultRandom().primaryKey(),
  sender: text("sender").notNull(),
  message: text("message").notNull(),
  presetName: text("preset_name"),
  presetKind: text("preset_kind"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const planetRuleVotes = pgTable("hm2_planet_rule_votes", {
  ruleId: text("rule_id").primaryKey(),
  votes: integer("votes").notNull().default(1),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const communityMods = pgTable("hm2_community_mods", {
  id: uuid("id").defaultRandom().primaryKey(),
  ownerToken: text("owner_token").notNull(),
  title: text("title").notNull(),
  author: text("author").notNull(),
  hookTarget: text("hook_target").notNull(),
  description: text("description").notNull(),
  configJson: jsonb("config_json").$type<Record<string, string | number | boolean>>().notNull(),
  upvotes: integer("upvotes").notNull().default(1),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
