import type { AuthoringState, EditablePreset, PresetPackage } from "./authoring";
import type { GraphSnapshot } from "./types";
import { FractalNodeGraph } from "./graph";
const number = (v: unknown, min: number, max: number) => typeof v === "number" && Number.isFinite(v) && v >= min && v <= max;
const color = (v: unknown) => typeof v === "string" && /^#[0-9a-f]{6}$/i.test(v);
const vec = (v: unknown, max: number) => Array.isArray(v) && v.length === 3 && v.every(x => number(x, -max, max));
export function validatePresetDocuments(presets: Record<string, EditablePreset>, graph: GraphSnapshot) {
  if (!presets || typeof presets !== "object" || Array.isArray(presets) || Object.keys(presets).length > 256) throw new Error("Invalid authoring preset budget");
  let totalMarks = 0, referenceFloats = 0;
  for (const [id, p] of Object.entries(presets)) {
    if (!p || p.id !== id || !graph.nodes[id] || p.revision !== graph.nodes[id].revision || typeof p.name !== "string" || p.name.length > 100 || !["tree", "wood", "leaf", "texture", "goblin", "part", "shape", "object"].includes(p.kind) || !["procedural", "reference"].includes(p.source)) throw new Error("Invalid editable preset");
    if (p.textureId !== null && (!presets[p.textureId] || presets[p.textureId].kind !== "texture" || !graph.nodes[id].children.some(r => r.nodeId === p.textureId))) throw new Error("Invalid material dependency");
    if (p.kind === "part" && !p.part) throw new Error("Goblin part socket data is required");
    if (["wood", "leaf", "part", "object"].includes(p.kind) && !p.textureId) throw new Error("An editable surface needs a pinned material");
    const children = graph.nodes[id].children.map(ref => presets[ref.nodeId]);
    if (p.kind === "tree" && (!children.some(child => child?.kind === "wood") || !children.some(child => child?.kind === "leaf"))) throw new Error("Tree presets require linked wood and leaf recipes");
    if (p.kind === "goblin" && !["head", "ears", "body", "arms", "legs", "armor"].every(slot => children.some(child => child?.part?.slot === slot))) throw new Error("Goblin presets require all six socket definitions; parts may be detached, not deleted");
    const s = p.shape;
    if (!s || !number(s.length, 0.3, 2) || !number(s.width, 0.3, 2) || !number(s.curl, -1, 1) || !number(s.edgeDetail, 0, 1)) throw new Error("Invalid procedural shape recipe");
    if (s.primitive !== undefined && !["cube", "cylinder", "sphere", "cone", "plane", "torus"].includes(s.primitive)) throw new Error("Invalid primitive kind");
    if (s.segments !== undefined && (!Number.isInteger(s.segments) || s.segments < 3 || s.segments > 64)) throw new Error("Invalid primitive segments");
    if (s.taper !== undefined && !number(s.taper, 0, 2)) throw new Error("Invalid primitive taper");
    if (s.bevel !== undefined && !number(s.bevel, 0, 0.5)) throw new Error("Invalid primitive bevel");
    const t = p.texture;
    if (p.kind === "texture" && !t) throw new Error("Texture recipe is required");
    if (t) {
      if (!["broadleaf", "fern", "autumn", "bark", "skin", "metal"].includes(t.pattern) || !number(t.seed, 0, 2147483647) || !color(t.color) || !color(t.accent) || !number(t.veinCount, 3, 24) || !number(t.veinWidth, 0, 1) || !number(t.veinContrast, 0, 1) || !number(t.noiseScale, 2, 40) || !number(t.noiseAmount, 0, 1) || !number(t.normalStrength, 0, 2) || !number(t.roughness, 0, 1) || !number(t.normalMix, 0, 1)) throw new Error("Invalid procedural texture recipe");
      if (t.normalSource !== null && (t.normalSource === id || !presets[t.normalSource]?.texture || !graph.nodes[id].children.some(r => r.nodeId === t.normalSource))) throw new Error("Invalid or unpinned normal-map source");
    }
    if (!Array.isArray(p.marks) || p.marks.length > 320 || (totalMarks += p.marks.length) > 1400) throw new Error("Surface edit budget exceeded");
    for (const m of p.marks) {
      if (!m || typeof m.id !== "string" || m.id.length > 64 || typeof m.target !== "string" || m.target.length > 100 || !["paint", "push", "pull", "shape", "wood", "leaf"].includes(m.kind) || !vec(m.point, 50) || !vec(m.normal, 1) || !Array.isArray(m.uv) || m.uv.length !== 2 || !m.uv.every(v => number(v, 0, 1)) || !number(m.radius, 0.02, 2) || !number(m.uvRadius, 0.001, 0.5) || !number(m.strength, 0, 1) || !color(m.color)) throw new Error("Invalid UV paint or sculpt stroke");
    }
    if (p.part) {
      if (!["head", "ears", "body", "arms", "legs", "armor"].includes(p.part.slot) || !["classic", "long", "chunky"].includes(p.part.variant) || typeof p.part.enabled !== "boolean" || !vec(p.part.position, 3) || !vec(p.part.rotation, 360) || !vec(p.part.scale, 2) || !p.part.scale.every(v => number(v, 0.2, 2))) throw new Error("Invalid goblin socket transform");
    }
    if (p.reference) {
      const r = p.reference;
      if (typeof r.name !== "string" || r.name.length > 120 || typeof r.hash !== "string" || !/^[0-9a-f]{64}$/i.test(r.hash) || r.provenance !== "local-glb" || !Array.isArray(r.positions) || r.positions.length < 9 || r.positions.length % 9 || r.positions.length > 18000 || !r.positions.every(v => number(v, -10, 10)) || !Array.isArray(r.uvs) || r.uvs.length !== r.positions.length / 3 * 2 || !r.uvs.every(v => number(v, 0, 1))) throw new Error("Invalid baked reference mesh");
      referenceFloats += r.positions.length + r.uvs.length;
      if (referenceFloats > 60000) throw new Error("Local reference geometry budget exceeded");
    }
    if (p.source === "reference" && !p.reference) throw new Error("Reference geometry is missing");
  }
}
export function validateAuthoring(state: AuthoringState, graph: GraphSnapshot) {
  if (!state || state.schemaVersion !== 1 || !state.bindings || !["tree", "wood", "leaf", "leafTexture", "goblin", "skinTexture", "metalTexture"].every(key => { const id = state.bindings[key as keyof typeof state.bindings]; return typeof id === "string" && Boolean(state.presets[id]); })) throw new Error("Invalid authoring bindings");
  const expected = { tree: "tree", wood: "wood", leaf: "leaf", leafTexture: "texture", goblin: "goblin", skinTexture: "texture", metalTexture: "texture" };
  for (const [key, kind] of Object.entries(expected)) { const id = state.bindings[key as keyof typeof state.bindings]; if (!id || state.presets[id].kind !== kind) throw new Error("Authoring binding kind mismatch"); }
  if (state.bindings.object && state.presets[state.bindings.object]?.kind !== "object") throw new Error("Authoring binding kind mismatch");
  validatePresetDocuments(state.presets, graph);
}
export function validatePresetPackage(value: unknown): asserts value is PresetPackage {
  const pkg = value as PresetPackage;
  if (!pkg || pkg.schemaVersion !== 1 || typeof pkg.rootId !== "string") throw new Error("Invalid preset package");
  const graph: GraphSnapshot = { schemaVersion: 1, rootId: pkg.rootId, nodes: pkg.nodes };
  FractalNodeGraph.validate(graph); validatePresetDocuments(pkg.presets, graph);
  if (!pkg.presets[pkg.rootId] || !Array.isArray(pkg.dependencies) || pkg.dependencies.length !== Object.keys(pkg.nodes).length) throw new Error("Incomplete preset lockfile");
  const seen = new Set<string>();
  for (const dep of pkg.dependencies) { if (!pkg.nodes[dep.id] || pkg.nodes[dep.id].revision !== dep.revision || seen.has(dep.id)) throw new Error("Mismatched preset lockfile"); seen.add(dep.id); }
}
