import type { FractalNode, GraphSnapshot, Vec3, WorldSnapshot } from "./types";

export type PresetKind = "tree" | "wood" | "leaf" | "texture" | "goblin" | "part" | "shape" | "object";
export type PrimitiveKind = "cube" | "cylinder" | "sphere" | "cone" | "plane" | "torus";
export type SurfaceAction = "paint" | "push" | "pull" | "shape" | "wood" | "leaf";
export type AuthorTool = "orbit" | "paint" | "push" | "pull" | "shape" | "wood" | "leaf" | "translate" | "rotate" | "scale";
export type TexturePattern = "broadleaf" | "fern" | "autumn" | "bark" | "skin" | "metal";
export type GoblinSlot = "head" | "ears" | "body" | "arms" | "legs" | "armor";
export interface TextureRecipe {
  pattern: TexturePattern;
  seed: number;
  color: string;
  accent: string;
  veinCount: number;
  veinWidth: number;
  veinContrast: number;
  noiseScale: number;
  noiseAmount: number;
  normalStrength: number;
  roughness: number;
  normalSource: string | null;
  normalMix: number;
}
export interface ShapeRecipe {
  length: number;
  width: number;
  curl: number;
  edgeDetail: number;
  primitive?: PrimitiveKind;
  segments?: number;
  taper?: number;
  bevel?: number;
}
export const PRIMITIVES: { id: PrimitiveKind; name: string; blurb: string }[] = [
  { id: "cube", name: "Cube", blurb: "Six flat faces. The blank slate." },
  { id: "cylinder", name: "Cylinder", blurb: "Trunks, branches, cans, posts." },
  { id: "sphere", name: "Sphere", blurb: "Boulders, fruit, goblin heads." },
  { id: "cone", name: "Cone", blurb: "Canopies, spikes, ears." },
  { id: "plane", name: "Plane", blurb: "Leaves, banners, decals." },
  { id: "torus", name: "Torus", blurb: "Hoops, rivets, rail rings." },
];
export interface SurfaceMark {
  id: string;
  target: string;
  kind: SurfaceAction;
  point: Vec3;
  normal: Vec3;
  uv: [number, number];
  radius: number;
  uvRadius: number;
  strength: number;
  color: string;
}
export interface GoblinPart {
  slot: GoblinSlot;
  variant: "classic" | "long" | "chunky";
  enabled: boolean;
  position: Vec3;
  rotation: Vec3;
  scale: Vec3;
}
export interface ReferenceMesh {
  name: string;
  hash: string;
  positions: number[];
  uvs: number[];
  provenance: "local-glb";
}
export interface EditablePreset {
  id: string;
  name: string;
  kind: PresetKind;
  revision: number;
  textureId: string | null;
  texture: TextureRecipe | null;
  shape: ShapeRecipe;
  part: GoblinPart | null;
  marks: SurfaceMark[];
  source: "procedural" | "reference";
  reference?: ReferenceMesh;
  savedId?: string;
}
export interface AuthoringState {
  schemaVersion: 1;
  presets: Record<string, EditablePreset>;
  bindings: { tree: string; wood: string; leaf: string; leafTexture: string; goblin: string; skinTexture: string; metalTexture: string; object?: string; };
}
export interface PresetPackage {
  schemaVersion: 1;
  rootId: string;
  nodes: Record<string, FractalNode>;
  presets: Record<string, EditablePreset>;
  dependencies: { id: string; revision: number }[];
}
export interface SavedPreset {
  id: string;
  name: string;
  kind: PresetKind;
  package: PresetPackage;
  contentHash: string;
  visibility: "private" | "public";
  createdAt: string;
  owned: boolean;
  authorHandle?: string;
  useCount?: number;
  remixCount?: number;
  shareCode?: string | null;
}
export const TEXTURE_STYLES: { id: TexturePattern; name: string; subtitle: string; color: string; accent: string }[] = [
  { id: "broadleaf", name: "Alpine emerald", subtitle: "Branching veins · Satin", color: "#4a8249", accent: "#c5d786" },
  { id: "fern", name: "Silver fern", subtitle: "Fine veins · Cool green", color: "#427b70", accent: "#b5d8ba" },
  { id: "autumn", name: "Copper autumn", subtitle: "Warm pigment · Deep veins", color: "#b66d32", accent: "#edc478" },
  { id: "bark", name: "Weathered wood", subtitle: "Grain ridges · Organic noise", color: "#725139", accent: "#b69a6a" },
  { id: "skin", name: "Goblin moss", subtitle: "Freckles · Soft pores", color: "#779150", accent: "#bcb879" },
  { id: "metal", name: "Forged brass", subtitle: "Scratches · Brushed iron", color: "#737669", accent: "#bcb28a" },
];
export function textureRecipe(pattern: TexturePattern = "broadleaf"): TextureRecipe {
  const style = TEXTURE_STYLES.find(s => s.id === pattern)!;
  return { pattern, seed: 62, color: style.color, accent: style.accent, veinCount: pattern === "fern" ? 18 : 9, veinWidth: 0.28, veinContrast: 0.65, noiseScale: 12, noiseAmount: 0.22, normalStrength: 0.7, roughness: 0.7, normalSource: null, normalMix: 0.25 };
}
const shape = (): ShapeRecipe => ({ length: 1, width: 1, curl: 0.28, edgeDetail: 0.2 });
export function createAuthoringState(): AuthoringState {
  const presets: Record<string, EditablePreset> = {};
  const add = (id: string, name: string, kind: PresetKind, textureId: string | null = null, pattern?: TexturePattern) => {
    presets[id] = { id, name, kind, revision: 1, textureId, texture: pattern ? textureRecipe(pattern) : null, shape: shape(), part: null, marks: [], source: "procedural" };
  };
  add("pine", "Alpine tree", "tree"); add("wood", "Branch & wood", "wood", "bark"); add("leaf", "Alpine leaf", "leaf", "leaf-texture");
  add("leaf-texture", "Alpine emerald", "texture", null, "broadleaf"); add("bark", "Weathered wood", "texture", null, "bark");
  // Raw, untextured primitives: the bottom of the preset chain
  for (const prim of PRIMITIVES) {
    add(`shape-${prim.id}`, prim.name, "shape");
    presets[`shape-${prim.id}`].shape = { ...shape(), primitive: prim.id, segments: 16, taper: 1, bevel: 0 };
  }
  // A composable object: primitive + material, ready to be saved and reused
  add("object-draft", "Untitled object", "object", "bark");
  presets["object-draft"].shape = { ...shape(), primitive: "cylinder", segments: 16, taper: 0.78, bevel: 0.05 };
  add("goblin", "Rivet, the rail gremlin", "goblin"); add("goblin-skin", "Goblin moss", "texture", null, "skin"); add("goblin-metal", "Forged brass", "texture", null, "metal");
  for (const slot of ["head", "ears", "body", "arms", "legs", "armor"] as GoblinSlot[]) {
    add(`goblin-${slot}`, ({ head: "Head & face", ears: "Pointed ears", body: "Body & torso", arms: "Arms & hands", legs: "Legs & boots", armor: "Scrap armor" })[slot], "part", slot === "armor" || slot === "legs" ? "goblin-metal" : "goblin-skin");
    presets[`goblin-${slot}`].part = { slot, variant: "classic", enabled: true, position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1] };
  }
  return { schemaVersion: 1, presets, bindings: { tree: "pine", wood: "wood", leaf: "leaf", leafTexture: "leaf-texture", goblin: "goblin", skinTexture: "goblin-skin", metalTexture: "goblin-metal", object: "object-draft" } };
}
export function attachAuthoringGraph(graph: GraphSnapshot, authoring: AuthoringState): GraphSnapshot {
  const nodes = { ...graph.nodes };
  const ref = (nodeId: string) => ({ nodeId, revision: authoring.presets[nodeId]?.revision ?? nodes[nodeId]?.revision ?? 1, policy: "pinned" as const, transform: { position: [0, 0, 0] as Vec3, quaternion: [0, 0, 0, 1] as [number, number, number, number], logScale: -1 } });
  const dependencies: Record<string, string[]> = {
    pine: ["wood", "leaf"], wood: ["bark"], leaf: ["leaf-texture"], goblin: ["goblin-head", "goblin-ears", "goblin-body", "goblin-arms", "goblin-legs", "goblin-armor"],
    "object-draft": ["bark"],
  };
  for (const p of Object.values(authoring.presets)) {
    const current = nodes[p.id];
    nodes[p.id] = { id: p.id, revision: p.revision, kind: p.kind === "texture" ? "material" : "prop", name: p.name, seed: 62, parameters: { ...current?.parameters, editor: p.kind }, children: (dependencies[p.id] ?? (p.textureId ? [p.textureId] : [])).map(ref) };
  }
  const planet = Object.values(nodes).find(n => n.kind === "planet") ?? nodes[graph.rootId];
  if (planet && !planet.children.some(r => r.nodeId === "goblin")) nodes[planet.id] = { ...planet, children: [...planet.children, ref("goblin")] };
  return { ...graph, nodes };
}
export function upgradeSnapshot(snapshot: WorldSnapshot): WorldSnapshot {
  const authoring = snapshot.authoring ?? createAuthoringState();
  const graph = snapshot.authoring ? snapshot.graph : attachAuthoringGraph(snapshot.graph, authoring);
  const economy = snapshot.economy ?? {
    raceMoneys: 250,
    islandScale: 1.0,
    joinedFriends: [],
    isWaterRacePlanet: false,
    majorityRule: "standard" as const,
    chinHits: 0,
    wins: 0,
  };
  return { ...snapshot, authoring, graph, economy };
}
export function editPreset(snapshot: WorldSnapshot, id: string, change: Partial<EditablePreset>): WorldSnapshot {
  const state = snapshot.authoring!;
  return { ...snapshot, authoring: { ...state, presets: { ...state.presets, [id]: { ...state.presets[id], ...change, id } } } };
}
export function makePresetPackage(snapshot: WorldSnapshot, rootId: string): PresetPackage {
  const nodes: Record<string, FractalNode> = {}, presets: Record<string, EditablePreset> = {};
  const visit = (id: string) => {
    if (nodes[id]) return;
    const node = snapshot.graph.nodes[id];
    if (!node) throw new Error("Missing preset dependency");
    nodes[id] = structuredClone(node);
    const p = snapshot.authoring?.presets[id];
    if (p) { presets[id] = structuredClone(p); if (p.textureId) visit(p.textureId); if (p.texture?.normalSource) visit(p.texture.normalSource); }
    node.children.forEach(r => visit(r.nodeId));
  };
  visit(rootId);
  return { schemaVersion: 1, rootId, nodes, presets, dependencies: Object.values(nodes).map(n => ({ id: n.id, revision: n.revision })) };
}
/** New revision is copy-on-write; old immutable server packages never change. */
export function savePresetToBranch(snapshot: WorldSnapshot, id: string, name: string, strategy: "replace" | "fork", parentId?: string): { snapshot: WorldSnapshot; id: string } {
  const original = snapshot.authoring!.presets[id];
  const nextId = strategy === "fork" ? `${id.split("--")[0]}--${crypto.randomUUID().slice(0, 8)}` : id;
  const revision = strategy === "fork" ? 1 : original.revision + 1;
  const preset: EditablePreset = { ...structuredClone(original), id: nextId, name, revision };
  const nodes = { ...snapshot.graph.nodes, [nextId]: { ...snapshot.graph.nodes[id], id: nextId, name, revision } };
  for (const node of Object.values(nodes)) {
    if (strategy === "replace" || node.id === parentId) nodes[node.id] = { ...node, children: node.children.map(r => r.nodeId === id ? { ...r, nodeId: nextId, revision } : r) };
  }
  const presets = { ...snapshot.authoring!.presets, [nextId]: preset };
  for (const p of Object.values(presets)) {
    if (p.id === nextId) continue;
    if (strategy === "replace" || p.id === parentId) {
      if (p.textureId === id) presets[p.id] = { ...p, textureId: nextId };
      if (p.texture?.normalSource === id) presets[p.id] = { ...presets[p.id], texture: { ...p.texture, normalSource: nextId } };
    }
  }
  const bindings = { ...snapshot.authoring!.bindings };
  for (const key of Object.keys(bindings) as (keyof typeof bindings)[]) if (bindings[key] === id) bindings[key] = nextId;
  return { id: nextId, snapshot: { ...snapshot, graph: { ...snapshot.graph, nodes }, authoring: { ...snapshot.authoring!, bindings, presets } } };
}
export function useSavedPreset(snapshot: WorldSnapshot, saved: SavedPreset, targetId: string): WorldSnapshot {
  const source = saved.package.presets[saved.package.rootId], target = snapshot.authoring!.presets[targetId];
  if (!source || source.kind !== target.kind || source.part?.slot !== target.part?.slot) throw new Error("Choose a compatible preset for this level");
  const mapping = new Map<string, string>([[source.id, targetId]]);
  for (const id of Object.keys(saved.package.nodes)) if (!mapping.has(id)) mapping.set(id, `${id.split("--")[0]}--${saved.id.slice(0, 8)}`);
  const presets = { ...snapshot.authoring!.presets }, nodes = { ...snapshot.graph.nodes };
  for (const [id, document] of Object.entries(saved.package.presets)) {
    const next = mapping.get(id)!;
    presets[next] = { ...structuredClone(document), id: next, revision: next === targetId ? target.revision : document.revision, textureId: document.textureId ? mapping.get(document.textureId)! : null, texture: document.texture ? { ...document.texture, normalSource: document.texture.normalSource ? mapping.get(document.texture.normalSource)! : null } : null };
  }
  for (const [id, node] of Object.entries(saved.package.nodes)) {
    const next = mapping.get(id)!;
    nodes[next] = { ...structuredClone(node), id: next, revision: next === targetId ? target.revision : node.revision, children: node.children.map(r => ({ ...r, nodeId: mapping.get(r.nodeId)!, revision: presets[mapping.get(r.nodeId)!]?.revision ?? r.revision })) };
  }
  const bindings = { ...snapshot.authoring!.bindings };
  // Bindings are conveniences; material/part dependencies always resolve through node references.
  for (const key of Object.keys(bindings) as (keyof typeof bindings)[]) { const id = bindings[key]; if (id && saved.package.presets[id] && mapping.has(id)) bindings[key] = mapping.get(id)!; }
  return { ...snapshot, graph: { ...snapshot.graph, nodes }, authoring: { ...snapshot.authoring!, presets, bindings } };
}
export function childPreset(snapshot: WorldSnapshot, parentId: string, kind: PresetKind): EditablePreset | undefined {
  return snapshot.graph.nodes[parentId]?.children.map(r => snapshot.authoring?.presets[r.nodeId]).find(p => p?.kind === kind);
}
