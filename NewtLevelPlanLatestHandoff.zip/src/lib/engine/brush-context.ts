/**
 * Context engine: what the quick-materials shelf should offer right now,
 * and which brush most logically comes next (bound to E).
 */
import type { AuthorTool, EditablePreset, PresetKind, TexturePattern } from "./authoring";
import type { SwatchKind } from "./swatches";

export interface ShelfEntry {
  id: string;
  label: string;
  swatch: SwatchKind;
  pattern?: TexturePattern;
  hint: string;
}

/** Materials relevant to the preset you are standing inside. */
export function shelfForContext(kind: PresetKind, tool: AuthorTool): ShelfEntry[] {
  const bark: ShelfEntry = { id: "bark", label: "Bark", swatch: "dirt", pattern: "bark", hint: "Grain ridges for trunks and branches" };
  const broadleaf: ShelfEntry = { id: "broadleaf", label: "Broadleaf", swatch: "foliage", pattern: "broadleaf", hint: "Branching veins, satin finish" };
  const fern: ShelfEntry = { id: "fern", label: "Fern", swatch: "foliage", pattern: "fern", hint: "Fine parallel veins" };
  const autumn: ShelfEntry = { id: "autumn", label: "Autumn", swatch: "foliage", pattern: "autumn", hint: "Warm pigment, deep veins" };
  const skin: ShelfEntry = { id: "skin", label: "Goblin skin", swatch: "foliage", pattern: "skin", hint: "Pores and freckles" };
  const metal: ShelfEntry = { id: "metal", label: "Brass", swatch: "brass", pattern: "metal", hint: "Brushed scratches, warm sheen" };
  const iron: ShelfEntry = { id: "iron", label: "Black iron", swatch: "iron", pattern: "metal", hint: "Dark rail plate" };
  const enamel: ShelfEntry = { id: "enamel", label: "Enamel", swatch: "enamel", pattern: "metal", hint: "Chipped white paint" };
  const basalt: ShelfEntry = { id: "basalt", label: "Basalt", swatch: "basalt", pattern: "bark", hint: "Porous rough stone" };
  const dirt: ShelfEntry = { id: "dirt", label: "Road dirt", swatch: "dirt", pattern: "bark", hint: "Loose grit and soil" };

  switch (kind) {
    case "wood": return [bark, basalt, dirt, enamel];
    case "leaf": return [broadleaf, fern, autumn, skin];
    case "tree": return [bark, broadleaf, fern, autumn];
    case "goblin":
    case "part": return [skin, metal, iron, enamel];
    case "texture": return [broadleaf, bark, skin, metal, basalt, dirt];
    case "shape":
    case "object": return [enamel, iron, bark, basalt, brassOr(metal), broadleaf];
    default: return [dirt, foliageOf(broadleaf), iron, enamel];
  }
  function brassOr(m: ShelfEntry) { return tool === "paint" ? m : metal; }
  function foliageOf(m: ShelfEntry) { return m; }
}

export interface NextBrush {
  tool: AuthorTool;
  reason: string;
}

/**
 * Suggests the next brush in a natural authoring rhythm:
 * look → shape → refine → paint → detail.
 */
export function suggestNextBrush(kind: PresetKind, tool: AuthorTool, preset: EditablePreset): NextBrush {
  const marks = preset.marks;
  const painted = marks.some(m => m.kind === "paint");
  const sculpted = marks.some(m => m.kind === "push" || m.kind === "pull");
  const shaped = marks.some(m => m.kind === "shape");

  // Natural authoring rhythm per preset kind: look → form → refine → paint → detail
  const rhythm: AuthorTool[] =
    kind === "tree" ? ["wood", "leaf", "paint", "pull", "orbit"]
    : kind === "goblin" || kind === "part" ? ["translate", "rotate", "scale", "pull", "paint", "shape", "orbit"]
    : kind === "texture" ? ["paint", "pull", "push", "orbit"]
    : ["pull", "paint", "shape", "push", "orbit"];

  const reasons: Partial<Record<AuthorTool, string>> = {
    wood: "Grow the trunk and branches first",
    leaf: "Add foliage to the branches",
    paint: painted ? "Layer more pigment" : "Lay down base pigment",
    pull: sculpted ? "Pull out more relief" : "Pull the silhouette out of the form",
    push: "Carve the opposing creases",
    shape: shaped ? "Add another growth" : "Add a detail lump or growth",
    translate: "Position the part in its socket",
    rotate: "Angle it into place",
    scale: "Size it against the body",
    orbit: "Step back and inspect it",
  };

  // From a neutral start, jump to the first unfinished step (smart entry).
  // Otherwise advance positionally so repeated presses walk the whole rhythm
  // instead of oscillating between two tools.
  const unfinished = rhythm.find(t => {
    if (t === "paint") return !painted;
    if (t === "pull" || t === "push") return !sculpted;
    if (t === "shape") return !shaped;
    if (t === "wood") return !marks.some(m => m.kind === "wood");
    if (t === "leaf") return !marks.some(m => m.kind === "leaf");
    return false;
  });
  const index = rhythm.indexOf(tool);
  const next = (tool === "orbit" || index === -1) && unfinished
    ? unfinished
    : rhythm[(index + 1) % rhythm.length];
  return { tool: next, reason: reasons[next] ?? "Keep shaping this preset" };
}

/** Which preset you would naturally open next, for the drawer's edit button. */
export function suggestNextPreset(kind: PresetKind): { kind: PresetKind; reason: string } | null {
  switch (kind) {
    case "shape": return { kind: "texture", reason: "Give the shape a material" };
    case "object": return { kind: "texture", reason: "Tune its material recipe" };
    case "wood": return { kind: "texture", reason: "Edit the bark recipe" };
    case "leaf": return { kind: "texture", reason: "Edit the leaf recipe" };
    case "tree": return { kind: "leaf", reason: "Refine the leaves" };
    case "goblin": return { kind: "part", reason: "Edit an individual part" };
    case "part": return { kind: "texture", reason: "Edit the part's material" };
    default: return null;
  }
}
