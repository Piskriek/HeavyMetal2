import type { BrushStroke, StudioSettings, Vec3, WorldStyle } from "./types";

export class AutoSizeEngine {
  static resolve(diameter: number, enabled = true) {
    const scale = enabled ? Math.max(0.15, Math.min(3, diameter / 5)) : 1;
    return { scale, spacing: Math.max(0.25, diameter * 0.2), tier: diameter < 2 ? "Micro detail" : diameter > 12 ? "Landforms" : "Biome growth" };
  }
}
export class GelBrushSystem {
  static stroke(position: Vec3, settings: StudioSettings, style: WorldStyle, carve = false): BrushStroke {
    return { id: crypto.randomUUID(), position, radius: settings.radius, density: settings.density, style, seed: Math.floor(Math.random() * 2147483647), kind: carve ? "carve" : "grow", scale: AutoSizeEngine.resolve(settings.radius * 2, settings.autoSize).scale };
  }
  static samples(stroke: BrushStroke): Vec3[] {
    let seed = stroke.seed >>> 0;
    const random = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; };
    const count = Math.min(24, Math.max(2, Math.round(stroke.density / 7)));
    return Array.from({ length: count }, () => {
      const angle = random() * Math.PI * 2;
      const radius = Math.sqrt(random()) * stroke.radius;
      return [stroke.position[0] + Math.cos(angle) * radius, stroke.position[1], stroke.position[2] + Math.sin(angle) * radius];
    });
  }
}
