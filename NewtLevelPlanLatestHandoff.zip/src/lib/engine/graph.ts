import { validateAuthoring } from "./authoring-validation";
import type { FractalNode, GraphSnapshot, WorldSnapshot } from "./types";

const MAX_NODES = 4096;
const MAX_DEPTH = 32;
const finite = (value: unknown, min: number, max: number): value is number => typeof value === "number" && Number.isFinite(value) && value >= min && value <= max;

/** Flat, immutable references. No embedded child worlds and no eager recursion. */
export class FractalNodeGraph {
  readonly snapshot: GraphSnapshot;
  private cache = new Map<string, FractalNode>();
  constructor(snapshot: GraphSnapshot) {
    FractalNodeGraph.validate(snapshot);
    this.snapshot = snapshot;
  }
  static validate(snapshot: GraphSnapshot) {
    if (!snapshot || snapshot.schemaVersion !== 1 || !snapshot.nodes || typeof snapshot.nodes !== "object") throw new Error("Invalid graph schema");
    const ids = Object.keys(snapshot.nodes);
    if (!ids.length || ids.length > MAX_NODES || !snapshot.nodes[snapshot.rootId]) throw new Error("Invalid graph root or node budget");
    if (ids.some(id => ["__proto__", "constructor", "prototype"].includes(id))) throw new Error("Reserved graph node identifier");
    const state = new Map<string, number>();
    const heights = new Map<string, number>();
    let edges = 0;
    const visit = (id: string, depth: number): number => {
      if (depth > MAX_DEPTH) throw new Error("Graph exceeds the 32-level safety budget");
      if (state.get(id) === 1) throw new Error("Cyclic preset references are not allowed");
      if (state.get(id) === 2) { const height = heights.get(id) ?? 0; if (depth + height > MAX_DEPTH) throw new Error("Graph exceeds the 32-level safety budget"); return height; }
      const node = snapshot.nodes[id];
      if (!node || node.id !== id || !Array.isArray(node.children) || node.children.length > 128 || !Number.isInteger(node.revision) || node.revision < 1) throw new Error("Invalid node reference");
      if (typeof node.name !== "string" || node.name.length > 120 || !finite(node.seed, 0, 2147483647)) throw new Error("Invalid node metadata");
      if (!["universe", "planet", "terrain", "biome", "prop", "material", "rail"].includes(node.kind)) throw new Error("Invalid node kind");
      state.set(id, 1);
      let height = 0;
      for (const ref of node.children) {
        if (++edges > 16384) throw new Error("Graph edge budget exceeded");
        const target = snapshot.nodes[ref.nodeId];
        if (!target || ref.revision !== target.revision || !["pinned", "follow"].includes(ref.policy)) throw new Error("Missing or mismatched pinned revision");
        const t = ref.transform;
        if (!t || !Array.isArray(t.position) || t.position.length !== 3 || !t.position.every(v => finite(v, -1e6, 1e6)) || !Array.isArray(t.quaternion) || t.quaternion.length !== 4 || !t.quaternion.every(v => finite(v, -1, 1)) || !finite(t.logScale, -300, 300)) throw new Error("Invalid relative transform");
        height = Math.max(height, 1 + visit(ref.nodeId, depth + 1));
      }
      if (depth + height > MAX_DEPTH) throw new Error("Graph exceeds the 32-level safety budget");
      state.set(id, 2); heights.set(id, height); return height;
    };
    for (const id of ids) visit(id, 0);
  }
  get(id: string): FractalNode {
    const node = this.snapshot.nodes[id];
    if (!node) throw new Error("Preset does not exist");
    this.cache.delete(id);
    this.cache.set(id, node);
    if (this.cache.size > 128) this.cache.delete(this.cache.keys().next().value!);
    return node;
  }
  enter(path: string[], childId: string): string[] {
    if (path.length >= MAX_DEPTH) throw new Error("Traversal depth budget reached");
    const parent = this.get(path[path.length - 1] ?? this.snapshot.rootId);
    if (!parent.children.some(ref => ref.nodeId === childId) || path.includes(childId)) throw new Error("Invalid child traversal");
    return [...path, childId];
  }
  pathTo(id: string): string[] {
    const queue: string[][] = [[this.snapshot.rootId]];
    const visited = new Set<string>();
    while (queue.length) {
      const path = queue.shift()!;
      const current = path[path.length - 1];
      if (current === id) return path;
      if (visited.has(current)) continue;
      visited.add(current);
      for (const ref of this.get(current).children) queue.push([...path, ref.nodeId]);
    }
    return [this.snapshot.rootId];
  }
}

export function validateSnapshot(value: unknown): asserts value is WorldSnapshot {
  if (!value || typeof value !== "object") throw new Error("A world snapshot is required");
  const s = value as WorldSnapshot;
  if (s.schemaVersion !== 1 || !["verdant", "dunes", "lunar"].includes(s.style) || !finite(s.seed, 0, 2147483647)) throw new Error("Invalid world snapshot");
  FractalNodeGraph.validate(s.graph);
  if (s.authoring) validateAuthoring(s.authoring, s.graph);
  if (!Array.isArray(s.strokes) || s.strokes.length > 600 || !Array.isArray(s.rails) || s.rails.length > 64) throw new Error("World geometry budget exceeded");
  const vec = (v: unknown) => Array.isArray(v) && v.length === 3 && v.every(n => finite(n, -10000, 10000));
  for (const stroke of s.strokes) {
    if (typeof stroke.id !== "string" || stroke.id.length > 64 || !vec(stroke.position) || !finite(stroke.radius, 0.1, 12) || !finite(stroke.density, 1, 100) || !finite(stroke.seed, 0, 2147483647) || (stroke.scale !== undefined && !finite(stroke.scale, 0.15, 3)) || !["grow", "carve"].includes(stroke.kind) || !["verdant", "dunes", "lunar"].includes(stroke.style)) throw new Error("Invalid brush stroke");
  }
  if (!s.rails.every(vec)) throw new Error("Invalid rail coordinates");
  const c = s.settings;
  if (!c || !finite(c.radius, 0.1, 12) || !finite(c.density, 1, 100) || typeof c.autoSize !== "boolean" || !["standard", "cinematic", "wireframe"].includes(c.renderStyle) || !["auto", "performance", "high"].includes(c.quality) || !finite(c.roughness, 0, 1) || !finite(c.materialScale, 0.1, 3) || !finite(c.materialRotation, 0, 360) || !vec(c.materialPosition) || !c.materialPosition.every(v => finite(v, -8, 8)) || !finite(c.materialDetail, 0, 2) || !Number.isInteger(c.materialDetail)) throw new Error("Invalid studio settings");
  if (s.economy !== undefined) {
    const e = s.economy;
    if (!e || !finite(e.raceMoneys, 0, 1e9) || !finite(e.islandScale, 0.5, 6) || !Array.isArray(e.joinedFriends) || e.joinedFriends.length > 32 || typeof e.isWaterRacePlanet !== "boolean" || !["standard", "low_gravity", "chin_check", "turbo_chain", "free_anarchy"].includes(e.majorityRule) || !finite(e.chinHits, 0, 1e7) || !finite(e.wins, 0, 1e7)) {
      throw new Error("Invalid island economy state");
    }
  }
}
