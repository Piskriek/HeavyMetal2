/**
 * Icon sets for custom interfaces.
 *
 * Icons are pure path data, not bitmaps, so an interface preset carries its
 * whole icon language inside a share code. Stroke weight, corner handling and
 * fill are driven by the active InterfaceRecipe, which means a set can be
 * sculpted (geometry) and painted (colour) like any other preset.
 */

export type IconName =
  | "select" | "brush" | "carve" | "rail" | "move" | "walk" | "recentre"
  | "shape" | "texture" | "object" | "tree" | "leaf" | "goblin"
  | "network" | "share" | "save" | "undo" | "redo" | "play" | "build"
  | "zoomIn" | "zoomOut" | "close" | "menu" | "pin" | "next";

export type IconSetId = "hairline" | "stencil" | "chisel" | "tag";

/** 24×24 path data per icon, per set. */
type IconPaths = Record<IconName, string[]>;

const HAIRLINE: IconPaths = {
  select: ["M5 3 L19 12 L12.5 13.5 L16 20 L13.5 21 L10 14.5 L5 19 Z"],
  brush: ["M4 20 C8 20 9 16 12 13 L19 6 L18 5 L11 12 C8 15 4 16 4 20 Z", "M14 9 L15 10"],
  carve: ["M4 12 H20", "M8 8 L12 12 L8 16"],
  rail: ["M5 3 V21", "M19 3 V21", "M5 8 H19", "M5 14 H19", "M5 20 H19"],
  move: ["M12 3 V21", "M3 12 H21", "M12 3 L9 6", "M12 3 L15 6", "M12 21 L9 18", "M12 21 L15 18"],
  walk: ["M13 4 a1.6 1.6 0 1 0 0.01 0", "M11 8 L10 14 L7 20", "M11 10 L15 13 L16 20", "M11 9 L7 11"],
  recentre: ["M12 5 V19", "M5 12 H19", "M12 9 a3 3 0 1 0 0.01 0"],
  shape: ["M4 8 L12 4 L20 8 L20 16 L12 20 L4 16 Z", "M4 8 L12 12 L20 8", "M12 12 V20"],
  texture: ["M4 4 H20 V20 H4 Z", "M4 9 H20", "M4 14 H20", "M9 4 V20", "M15 4 V20"],
  object: ["M4 8 L12 4 L20 8 L12 12 Z", "M4 8 V16 L12 20 V12", "M20 8 V16 L12 20"],
  tree: ["M12 20 V13", "M12 13 L7 9 M12 13 L17 9", "M12 9 L9 5 M12 9 L15 5"],
  leaf: ["M5 19 C5 10 11 5 19 5 C19 13 14 19 5 19 Z", "M5 19 L19 5"],
  goblin: ["M7 10 L4 6 L8 7", "M17 10 L20 6 L16 7", "M8 7 C8 15 16 15 16 7", "M9 11 h1 M14 11 h1", "M9 14 L12 16 L15 14"],
  network: ["M6 6 a2 2 0 1 0 .01 0", "M18 6 a2 2 0 1 0 .01 0", "M12 18 a2 2 0 1 0 .01 0", "M7 8 L11 16", "M17 8 L13 16"],
  share: ["M7 12 a2 2 0 1 0 .01 0", "M17 6 a2 2 0 1 0 .01 0", "M17 18 a2 2 0 1 0 .01 0", "M9 11 L15 7", "M9 13 L15 17"],
  save: ["M5 5 H16 L19 8 V19 H5 Z", "M8 5 V10 H15 V5", "M8 15 H16"],
  undo: ["M8 7 L4 11 L8 15", "M4 11 H14 a5 5 0 0 1 0 10 H9"],
  redo: ["M16 7 L20 11 L16 15", "M20 11 H10 a5 5 0 0 0 0 10 H15"],
  play: ["M7 4 L19 12 L7 20 Z"],
  build: ["M4 18 L10 12", "M9 7 a4 4 0 0 1 6 5 L20 17 L17 20 L12 15 a4 4 0 0 1-5-6 Z"],
  zoomIn: ["M11 4 a7 7 0 1 0 .01 0", "M16 16 L21 21", "M11 8 V14", "M8 11 H14"],
  zoomOut: ["M11 4 a7 7 0 1 0 .01 0", "M16 16 L21 21", "M8 11 H14"],
  close: ["M6 6 L18 18", "M18 6 L6 18"],
  menu: ["M4 7 H20", "M4 12 H20", "M4 17 H20"],
  pin: ["M12 3 V12", "M8 12 H16 L14 17 H10 Z", "M12 17 V21"],
  next: ["M5 12 H18", "M13 7 L18 12 L13 17"],
};

/** Stencil: cut-out blocks, heavier, spray-stencil feel. */
const STENCIL: IconPaths = {
  ...HAIRLINE,
  select: ["M5 3 L19 12 L13 13 L16.5 20 L13 21.5 L9.5 14.5 L5 19 Z"],
  brush: ["M4 20 L4 16 L14 6 L18 10 L8 20 Z", "M13 7 L17 11"],
  carve: ["M3 11 H21 V13 H3 Z", "M7 7 L12 12 L7 17"],
  rail: ["M4 3 H8 V21 H4 Z", "M16 3 H20 V21 H16 Z", "M8 10 H16 V12 H8 Z", "M8 16 H16 V18 H8 Z"],
  texture: ["M4 4 H20 V20 H4 Z", "M4 4 H12 V12 H4 Z", "M12 12 H20 V20 H12 Z"],
  leaf: ["M4 20 C4 10 10 4 20 4 C20 14 14 20 4 20 Z"],
  goblin: ["M6 9 L3 4 L9 6 L15 6 L21 4 L18 9 C18 16 6 16 6 9 Z", "M9 11 h2 M13 11 h2"],
  play: ["M6 3 L20 12 L6 21 Z"],
  close: ["M5 5 L19 19", "M19 5 L5 19", "M4 4 H8 M16 4 H20 M4 20 H8 M16 20 H20"],
};

/** Chisel: angular, carved-from-stone geometry. */
const CHISEL: IconPaths = {
  ...HAIRLINE,
  select: ["M6 2 L18 13 L12 13 L15 21 L11 21 L8 14 L6 17 Z"],
  brush: ["M3 21 L5 15 L15 5 L19 9 L9 19 Z", "M14 6 L18 10"],
  shape: ["M12 3 L21 9 L18 20 L6 20 L3 9 Z", "M12 3 V20", "M3 9 L21 9"],
  object: ["M12 3 L21 9 L12 13 L3 9 Z", "M3 9 L3 16 L12 21 L12 13", "M21 9 L21 16 L12 21"],
  tree: ["M12 21 V14", "M12 14 L5 10 L12 11 L19 10 Z", "M12 11 L7 6 L12 7 L17 6 Z"],
  texture: ["M3 5 L21 3 L20 21 L4 19 Z", "M4 11 L20 10", "M11 4 L12 20"],
  network: ["M4 4 H9 V9 H4 Z", "M15 4 H20 V9 H15 Z", "M9.5 15 H14.5 V20 H9.5 Z", "M7 9 L11 15", "M17 9 L13 15"],
  close: ["M4 4 L20 20", "M20 4 L4 20"],
};

/** Tag: graffiti marker, loose and hand-sprayed. */
const TAG: IconPaths = {
  ...HAIRLINE,
  select: ["M5 3 C9 7 14 10 19 12 C16 13 14 13 13 14 C14 16 15 18 16 20 C14 20 13 20 13 20 C12 18 11 16 10 14 C8 16 6 18 5 19 Z"],
  brush: ["M4 20 C9 21 10 15 13 12 C15 10 17 8 19 6 C18 5 18 5 18 5 C15 8 12 11 10 13 C7 16 4 16 4 20 Z"],
  leaf: ["M5 19 C6 10 12 4 19 5 C20 13 13 20 5 19 Z", "M6 18 C10 14 14 10 18 6"],
  goblin: ["M7 10 C5 8 4 6 3 5 C5 5 7 6 8 7 C11 6 13 6 16 7 C17 6 19 5 21 5 C20 6 19 8 17 10 C18 16 6 16 7 10 Z", "M9 11 h1.5 M13.5 11 h1.5", "M9 14 C11 16 13 16 15 14"],
  share: ["M7 12 a2 2 0 1 0 .01 0", "M17 5 a2 2 0 1 0 .01 0", "M17 19 a2 2 0 1 0 .01 0", "M9 11 C11 10 13 8 15 7", "M9 13 C11 14 13 16 15 18"],
  network: ["M6 6 a2 2 0 1 0 .01 0", "M18 6 a2 2 0 1 0 .01 0", "M12 18 a2 2 0 1 0 .01 0", "M7 8 C8 11 10 14 11 16", "M17 8 C16 11 14 14 13 16"],
};

export const ICON_SETS: Record<IconSetId, { name: string; blurb: string; paths: IconPaths; defaultWeight: number; cap: "butt" | "round" | "square" }> = {
  hairline: { name: "Hairline", blurb: "Thin charcoal strokes. Quiet and precise.", paths: HAIRLINE, defaultWeight: 1.5, cap: "square" },
  stencil: { name: "Stencil", blurb: "Cut-out blocks, spray-stencil weight.", paths: STENCIL, defaultWeight: 2.2, cap: "butt" },
  chisel: { name: "Chisel", blurb: "Angular facets carved from stone.", paths: CHISEL, defaultWeight: 1.8, cap: "butt" },
  tag: { name: "Tag", blurb: "Loose marker lines, hand-sprayed.", paths: TAG, defaultWeight: 2.4, cap: "round" },
};

export const ICON_SET_IDS = Object.keys(ICON_SETS) as IconSetId[];

export function iconPaths(set: IconSetId, name: IconName): string[] {
  return ICON_SETS[set]?.paths[name] ?? HAIRLINE[name] ?? [];
}
