/**
 * The interface is a preset.
 *
 * Same contract as every other preset: a recipe you can sculpt (geometry,
 * density, weight), paint (colour), save as a revision, fork, and share as a
 * compact code. Applying one rewrites CSS custom properties, so the whole
 * studio re-skins without a reload.
 */
import { ICON_SETS, type IconSetId } from "./icon-sets";

export type InterfaceDensity = "compact" | "regular" | "roomy";

export interface InterfaceRecipe {
  iconSet: IconSetId;
  /** Sculpt: stroke weight of every icon, in px at 24×24. */
  iconWeight: number;
  /** Sculpt: 0 = razor square, 1 = fully rounded. Applies to icon joins only. */
  iconRound: number;
  /** Sculpt: control height scale. */
  density: InterfaceDensity;
  /** Sculpt: hairline thickness for panel edges. */
  hairline: number;
  /** Sculpt: corner radius in px. 0 keeps the flat cut-out language. */
  radius: number;
  /** Paint. */
  surface: string;
  panel: string;
  ink: string;
  accent: string;
  /** Paint: how strongly the accent is used. */
  accentStrength: number;
  /** Paint: background grain, 0 = clean enamel. */
  grain: number;
}

export const DEFAULT_INTERFACE: InterfaceRecipe = {
  iconSet: "hairline",
  iconWeight: 1.5,
  iconRound: 0,
  density: "compact",
  hairline: 1,
  radius: 0,
  surface: "#f4f2ee",
  panel: "#fbfaf7",
  ink: "#23231f",
  accent: "#ff2d6f",
  accentStrength: 0.85,
  grain: 0.22,
};

/** Shipped starting points, same role as the biome presets. */
export const INTERFACE_PRESETS: { id: string; name: string; blurb: string; recipe: InterfaceRecipe }[] = [
  { id: "build", name: "Compact Build", blurb: "Warm white, hairline charcoal, zero radius.", recipe: DEFAULT_INTERFACE },
  {
    id: "workshop", name: "Workshop", blurb: "Roomier controls, stencil icons, brass accent.",
    recipe: { ...DEFAULT_INTERFACE, iconSet: "stencil", iconWeight: 2.2, density: "roomy", accent: "#c9992e", grain: 0.3, panel: "#fcfbf8" },
  },
  {
    id: "yard", name: "Scrap Yard", blurb: "Chisel icons, heavier hairlines, lime accent.",
    recipe: { ...DEFAULT_INTERFACE, iconSet: "chisel", iconWeight: 1.9, hairline: 1.4, accent: "#a8e600", surface: "#f1f0ea", grain: 0.38 },
  },
  {
    id: "spray", name: "Spray Booth", blurb: "Marker icons, soft corners, cyan accent.",
    recipe: { ...DEFAULT_INTERFACE, iconSet: "tag", iconWeight: 2.5, iconRound: 1, radius: 2, accent: "#00c4ff", density: "regular" },
  },
  {
    id: "darkroom", name: "Dark Room", blurb: "Graphite workshop. Low light, lime accent.",
    recipe: {
      ...DEFAULT_INTERFACE,
      iconSet: "hairline", iconWeight: 1.6, density: "compact",
      surface: "#15171a", panel: "#1c1f23", ink: "#e8e6e0",
      accent: "#a8e600", accentStrength: 0.9, grain: 0.3, hairline: 1.2,
    },
  },
];

/** The dark mode is simply the Dark Room interface preset. */
export const DARK_INTERFACE = INTERFACE_PRESETS.find(p => p.id === "darkroom")!.recipe;

const DENSITY_SCALE: Record<InterfaceDensity, number> = { compact: 1, regular: 1.12, roomy: 1.26 };

const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));
const isHex = (v: unknown): v is string => typeof v === "string" && /^#[0-9a-f]{6}$/i.test(v);

/** Mix two hex colours; used to derive muted ink tiers from the painted ink. */
function mix(a: string, b: string, t: number) {
  const pa = [1, 3, 5].map(i => parseInt(a.slice(i, i + 2), 16));
  const pb = [1, 3, 5].map(i => parseInt(b.slice(i, i + 2), 16));
  const out = pa.map((v, i) => Math.round(v + (pb[i] - v) * t));
  return `#${out.map(v => v.toString(16).padStart(2, "0")).join("")}`;
}

/** Turn a recipe into the CSS custom properties the studio already reads. */
export function interfaceVars(recipe: InterfaceRecipe): Record<string, string> {
  const r = normaliseInterface(recipe);
  const scale = DENSITY_SCALE[r.density];
  const hairAlpha = clamp(0.1 * r.hairline, 0.04, 0.4);
  return {
    "--w-bg": r.surface,
    "--w-panel": r.panel,
    "--w-raise": mix(r.panel, "#ffffff", 0.55),
    "--w-sink": mix(r.surface, r.ink, 0.05),
    "--ink": r.ink,
    "--ink-2": mix(r.ink, r.surface, 0.42),
    "--ink-3": mix(r.ink, r.surface, 0.62),
    "--hair": `rgba(${hexToRgb(r.ink)},${hairAlpha.toFixed(3)})`,
    "--hair-2": `rgba(${hexToRgb(r.ink)},${(hairAlpha * 2).toFixed(3)})`,
    "--acc-pink": r.accent,
    "--ui-accent-strength": r.accentStrength.toFixed(2),
    "--ui-density": scale.toFixed(3),
    "--ui-radius": `${r.radius}px`,
    "--ui-hairline": `${r.hairline}px`,
    "--ui-grain": r.grain.toFixed(3),
    "--ui-icon-weight": r.iconWeight.toFixed(2),
    "--ui-icon-cap": r.iconRound > 0.5 ? "round" : ICON_SETS[r.iconSet].cap,
  };
}

function hexToRgb(hex: string) {
  return [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16)).join(",");
}

/** Clamp any incoming recipe into safe ranges. Shared by UI and server. */
export function normaliseInterface(input: Partial<InterfaceRecipe> | undefined | null): InterfaceRecipe {
  const r = { ...DEFAULT_INTERFACE, ...(input ?? {}) };
  return {
    iconSet: ICON_SETS[r.iconSet] ? r.iconSet : "hairline",
    iconWeight: clamp(Number(r.iconWeight) || 1.5, 0.75, 3.5),
    iconRound: clamp(Number(r.iconRound) || 0, 0, 1),
    density: (["compact", "regular", "roomy"] as const).includes(r.density) ? r.density : "compact",
    hairline: clamp(Number(r.hairline) || 1, 0.5, 3),
    radius: clamp(Number(r.radius) || 0, 0, 14),
    surface: isHex(r.surface) ? r.surface : DEFAULT_INTERFACE.surface,
    panel: isHex(r.panel) ? r.panel : DEFAULT_INTERFACE.panel,
    ink: isHex(r.ink) ? r.ink : DEFAULT_INTERFACE.ink,
    accent: isHex(r.accent) ? r.accent : DEFAULT_INTERFACE.accent,
    accentStrength: clamp(Number(r.accentStrength) ?? 0.85, 0, 1),
    grain: clamp(Number(r.grain) ?? 0.22, 0, 1),
  };
}

/** Strict validation for anything crossing the wire. */
export function validateInterface(value: unknown): asserts value is InterfaceRecipe {
  if (!value || typeof value !== "object") throw new Error("Interface recipe must be an object");
  const r = value as InterfaceRecipe;
  if (!ICON_SETS[r.iconSet]) throw new Error("Unknown icon set");
  if (!(["compact", "regular", "roomy"] as const).includes(r.density)) throw new Error("Invalid interface density");
  for (const [key, lo, hi] of [["iconWeight", 0.75, 3.5], ["iconRound", 0, 1], ["hairline", 0.5, 3], ["radius", 0, 14], ["accentStrength", 0, 1], ["grain", 0, 1]] as const) {
    const n = r[key];
    if (typeof n !== "number" || !Number.isFinite(n) || n < lo || n > hi) throw new Error(`Interface ${key} is out of range`);
  }
  for (const key of ["surface", "panel", "ink", "accent"] as const) {
    if (!isHex(r[key])) throw new Error(`Interface ${key} must be a hex colour`);
  }
}

export const INTERFACE_SHARE_PREFIX = "HM2UI-";

/** Compact code for just the interface — short enough to drop in chat. */
export function encodeInterface(recipe: InterfaceRecipe): string {
  const r = normaliseInterface(recipe);
  const compact = [
    r.iconSet, r.iconWeight, r.iconRound, r.density, r.hairline, r.radius,
    r.surface.slice(1), r.panel.slice(1), r.ink.slice(1), r.accent.slice(1),
    r.accentStrength, r.grain,
  ].join("~");
  return INTERFACE_SHARE_PREFIX + compact;
}

export function decodeInterface(code: string): InterfaceRecipe {
  const trimmed = code.trim();
  if (!trimmed.startsWith(INTERFACE_SHARE_PREFIX)) throw new Error("Not an interface code");
  const parts = trimmed.slice(INTERFACE_SHARE_PREFIX.length).split("~");
  if (parts.length !== 12) throw new Error("Interface code is malformed");
  const recipe = normaliseInterface({
    iconSet: parts[0] as IconSetId,
    iconWeight: Number(parts[1]),
    iconRound: Number(parts[2]),
    density: parts[3] as InterfaceDensity,
    hairline: Number(parts[4]),
    radius: Number(parts[5]),
    surface: `#${parts[6]}`,
    panel: `#${parts[7]}`,
    ink: `#${parts[8]}`,
    accent: `#${parts[9]}`,
    accentStrength: Number(parts[10]),
    grain: Number(parts[11]),
  });
  validateInterface(recipe);
  return recipe;
}
