import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import type { ReferenceMesh } from "./authoring";
import { disposePresetObject } from "./preset-geometry";

/** GLB bytes become a bounded, normalized mesh recipe. Never retain loader URLs. */
export async function importLocalReference(file: File): Promise<ReferenceMesh> {
  if (!file.name.toLowerCase().endsWith(".glb") || file.size > 4 * 1024 * 1024) throw new Error("Choose an embedded .glb smaller than 4 MB");
  const buffer = await file.arrayBuffer(), view = new DataView(buffer);
  if (buffer.byteLength < 20 || view.getUint32(0, true) !== 0x46546c67 || view.getUint32(4, true) !== 2 || view.getUint32(8, true) !== buffer.byteLength || view.getUint32(16, true) !== 0x4e4f534a) throw new Error("Only valid binary glTF 2.0 models are supported");
  const length = view.getUint32(12, true);
  if (length > buffer.byteLength - 20) throw new Error("Invalid GLB manifest length");
  const manifest = JSON.parse(new TextDecoder().decode(new Uint8Array(buffer, 20, length)));
  const resources = [...(manifest.buffers ?? []), ...(manifest.images ?? [])];
  if (resources.some(r => r.uri && !String(r.uri).startsWith("data:"))) throw new Error("External model URLs are not allowed. Embed every resource in the GLB.");
  if ((manifest.nodes?.length ?? 0) > 128 || (manifest.accessors ?? []).some((a: { count: number }) => a.count > 100000) || (manifest.extensionsRequired?.length ?? 0) > 0) throw new Error("Use a retopologized, uncompressed GLB with at most 128 nodes and 100k vertices");
  const nodeStates = new Map<number, number>();
  const visitNode = (index: number, depth: number) => {
    if (!Number.isInteger(index) || index < 0 || index >= (manifest.nodes?.length ?? 0) || depth > 32 || nodeStates.get(index) === 1) throw new Error("Invalid or cyclic model node graph");
    if (nodeStates.get(index) === 2) return;
    nodeStates.set(index, 1);
    for (const child of manifest.nodes[index].children ?? []) visitNode(child, depth + 1);
    nodeStates.set(index, 2);
  };
  for (let i = 0; i < (manifest.nodes?.length ?? 0); i++) visitNode(i, 0);
  const gltf = await new GLTFLoader().parseAsync(buffer, "");
  try {
    gltf.scene.updateMatrixWorld(true);
    const candidates: THREE.Mesh[] = [];
    gltf.scene.traverse(o => { if (o instanceof THREE.Mesh && !(o instanceof THREE.SkinnedMesh)) candidates.push(o); });
    if (!candidates.length) throw new Error("Import a static, split part mesh before rigging");
    const mesh = candidates[0], geo = mesh.geometry, attribute = geo.getAttribute("position"), uv = geo.getAttribute("uv"), index = geo.getIndex();
    if (!attribute) throw new Error("Local mesh has no editable positions");
    const count = Math.floor((index?.count ?? attribute.count) / 3), stride = Math.max(1, Math.ceil(count / 2000));
    const points: THREE.Vector3[] = [], uvs: number[] = [];
    for (let triangle = 0; triangle < count; triangle += stride) for (let corner = 0; corner < 3; corner++) {
      const i = index ? index.getX(triangle * 3 + corner) : triangle * 3 + corner;
      const point = new THREE.Vector3().fromBufferAttribute(attribute, i).applyMatrix4(mesh.matrixWorld);
      if (!point.toArray().every(Number.isFinite)) throw new Error("Local mesh contains invalid vertex coordinates");
      points.push(point);
      uvs.push(uv ? Math.max(0, Math.min(1, uv.getX(i))) : 0, uv ? Math.max(0, Math.min(1, uv.getY(i))) : 0);
    }
    if (!points.length) throw new Error("Local mesh has no triangles");
    const bounds = new THREE.Box3().setFromPoints(points), center = bounds.getCenter(new THREE.Vector3()), dimensions = bounds.getSize(new THREE.Vector3());
    const scale = 4.5 / Math.max(dimensions.x, dimensions.y, dimensions.z, 0.001), positions: number[] = [];
    for (const [i, p] of points.entries()) { p.sub(center).multiplyScalar(scale); positions.push(...p.toArray().map(v => +v.toFixed(4))); if (!uv) { uvs[i * 2] = (p.x / 4.5 + 0.5); uvs[i * 2 + 1] = (p.y / 4.5 + 0.5); } }
    const digest = await crypto.subtle.digest("SHA-256", buffer), hash = Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, "0")).join("");
    return { name: file.name.slice(0, 120), hash, positions, uvs, provenance: "local-glb" };
  } finally { disposePresetObject(gltf.scene); }
}
