/**
 * PBR showcase: the centrepiece of the white room.
 *
 * A rock / tree / bush vignette built from fully procedural PBR materials —
 * albedo, normal, roughness and AO are generated as canvas textures so the
 * scene demonstrates real physically-based shading with no external assets.
 *
 * When the low-poly texture set from the art pipeline lands, these generators
 * are the swap-in point: same material slots, same UVs, higher-fidelity maps.
 */
import * as THREE from "three";

const rnd = (seed: number) => { let s = seed >>> 0; return () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; }; };

function makeCanvas(size: number) {
  const c = document.createElement("canvas");
  c.width = c.height = size;
  return { c, ctx: c.getContext("2d")! };
}

/** Derive a tangent-space normal map from a greyscale height canvas. */
function heightToNormal(height: HTMLCanvasElement, strength = 2.2): HTMLCanvasElement {
  const size = height.width;
  const src = height.getContext("2d")!.getImageData(0, 0, size, size).data;
  const { c, ctx } = makeCanvas(size);
  const out = ctx.createImageData(size, size);
  const at = (x: number, y: number) => src[((y + size) % size * size + (x + size) % size) * 4] / 255;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const dx = (at(x - 1, y) - at(x + 1, y)) * strength;
      const dy = (at(x, y - 1) - at(x, y + 1)) * strength;
      const len = Math.hypot(dx, dy, 1);
      const i = (y * size + x) * 4;
      out.data[i] = ((dx / len) * 0.5 + 0.5) * 255;
      out.data[i + 1] = ((dy / len) * 0.5 + 0.5) * 255;
      out.data[i + 2] = ((1 / len) * 0.5 + 0.5) * 255;
      out.data[i + 3] = 255;
    }
  }
  ctx.putImageData(out, 0, 0);
  return c;
}

function tex(canvas: HTMLCanvasElement, srgb = false, repeat = 1) {
  const t = new THREE.CanvasTexture(canvas);
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeat, repeat);
  t.anisotropy = 8;
  return t;
}

export interface PbrSet {
  albedo: HTMLCanvasElement;
  height: HTMLCanvasElement;
  roughness: HTMLCanvasElement;
  ao: HTMLCanvasElement;
}

/** Weathered granite: mineral speckle, fracture lines, lichen bloom. */
export function graniteMaps(seed = 11, size = 512): PbrSet {
  const r = rnd(seed);
  const { c: albedo, ctx: a } = makeCanvas(size);
  const { c: height, ctx: h } = makeCanvas(size);
  const { c: roughness, ctx: ro } = makeCanvas(size);
  const { c: ao, ctx: o } = makeCanvas(size);

  a.fillStyle = "#6f6b64"; a.fillRect(0, 0, size, size);
  h.fillStyle = "#808080"; h.fillRect(0, 0, size, size);
  ro.fillStyle = "#b4b4b4"; ro.fillRect(0, 0, size, size);
  o.fillStyle = "#ffffff"; o.fillRect(0, 0, size, size);

  // Mineral grain
  for (let i = 0; i < 26000; i++) {
    const x = r() * size, y = r() * size, s = 0.6 + r() * 2.2, g = r();
    a.fillStyle = g > 0.86 ? "#cdc7bd" : g > 0.62 ? "#8b8680" : g > 0.3 ? "#5c5852" : "#46433e";
    a.fillRect(x, y, s, s);
    const hv = Math.round(118 + g * 72);
    h.fillStyle = `rgb(${hv},${hv},${hv})`;
    h.fillRect(x, y, s, s);
  }
  // Fracture lines bite into height and darken AO
  for (let i = 0; i < 16; i++) {
    let x = r() * size, y = r() * size;
    const steps = 50 + r() * 90;
    a.strokeStyle = "rgba(42,40,37,.5)"; a.lineWidth = 1 + r() * 2.4;
    h.strokeStyle = "rgba(40,40,40,.75)"; h.lineWidth = 2 + r() * 3.4;
    o.strokeStyle = "rgba(120,120,120,.5)"; o.lineWidth = 3 + r() * 4;
    a.beginPath(); h.beginPath(); o.beginPath();
    a.moveTo(x, y); h.moveTo(x, y); o.moveTo(x, y);
    let ang = r() * Math.PI * 2;
    for (let s = 0; s < steps; s++) {
      ang += (r() - 0.5) * 0.5; x += Math.cos(ang) * 3; y += Math.sin(ang) * 3;
      a.lineTo(x, y); h.lineTo(x, y); o.lineTo(x, y);
    }
    a.stroke(); h.stroke(); o.stroke();
  }
  // Lichen: rough, lighter, slightly raised
  for (let i = 0; i < 90; i++) {
    const x = r() * size, y = r() * size, rad = 5 + r() * 26;
    const g = a.createRadialGradient(x, y, 1, x, y, rad);
    g.addColorStop(0, `rgba(${120 + r() * 40 | 0},${138 + r() * 30 | 0},92,.5)`);
    g.addColorStop(1, "rgba(130,145,95,0)");
    a.fillStyle = g; a.beginPath(); a.arc(x, y, rad, 0, 7); a.fill();
    ro.fillStyle = "rgba(245,245,245,.5)"; ro.beginPath(); ro.arc(x, y, rad * 0.8, 0, 7); ro.fill();
  }
  // Polished facets read smoother
  for (let i = 0; i < 40; i++) {
    const x = r() * size, y = r() * size, rad = 8 + r() * 30;
    ro.fillStyle = "rgba(96,96,96,.42)"; ro.beginPath(); ro.arc(x, y, rad, 0, 7); ro.fill();
  }
  return { albedo, height, roughness, ao };
}

/** Deep fissured bark with raised ridges and mossy crevices. */
export function barkMaps(seed = 23, size = 512): PbrSet {
  const r = rnd(seed);
  const { c: albedo, ctx: a } = makeCanvas(size);
  const { c: height, ctx: h } = makeCanvas(size);
  const { c: roughness, ctx: ro } = makeCanvas(size);
  const { c: ao, ctx: o } = makeCanvas(size);

  a.fillStyle = "#5d4733"; a.fillRect(0, 0, size, size);
  h.fillStyle = "#8c8c8c"; h.fillRect(0, 0, size, size);
  ro.fillStyle = "#d2d2d2"; ro.fillRect(0, 0, size, size);
  o.fillStyle = "#ffffff"; o.fillRect(0, 0, size, size);

  // Vertical ridges with wandering fissures between them
  const columns = 26;
  for (let i = 0; i < columns; i++) {
    const baseX = (i / columns) * size + (r() - 0.5) * 8;
    const w = size / columns * (0.5 + r() * 0.8);
    let x = baseX;
    a.beginPath(); h.beginPath(); o.beginPath();
    a.moveTo(x, 0); h.moveTo(x, 0); o.moveTo(x, 0);
    for (let y = 0; y <= size; y += 7) {
      x += (r() - 0.5) * 5;
      a.lineTo(x, y); h.lineTo(x, y); o.lineTo(x, y);
    }
    // crevice: dark, low, occluded
    a.strokeStyle = `rgba(${34 + r() * 16 | 0},${24 + r() * 12 | 0},16,.85)`; a.lineWidth = w * 0.5;
    h.strokeStyle = "rgba(26,26,26,.9)"; h.lineWidth = w * 0.55;
    o.strokeStyle = "rgba(96,96,96,.75)"; o.lineWidth = w * 0.9;
    a.stroke(); h.stroke(); o.stroke();
    // ridge highlight beside it
    a.strokeStyle = `rgba(${140 + r() * 40 | 0},${112 + r() * 30 | 0},${74 + r() * 24 | 0},.45)`;
    a.lineWidth = w * 0.3;
    h.strokeStyle = "rgba(226,226,226,.7)"; h.lineWidth = w * 0.34;
    a.save(); h.save(); a.translate(w * 0.5, 0); h.translate(w * 0.5, 0);
    a.stroke(); h.stroke(); a.restore(); h.restore();
  }
  // Fibrous grain
  for (let i = 0; i < 4200; i++) {
    const x = r() * size, y = r() * size, len = 4 + r() * 22;
    a.strokeStyle = r() > 0.5 ? "rgba(96,74,50,.3)" : "rgba(40,30,20,.3)";
    a.lineWidth = 0.7;
    a.beginPath(); a.moveTo(x, y); a.lineTo(x + (r() - 0.5) * 3, y + len); a.stroke();
  }
  // Damp moss in the crevices: rougher and greener
  for (let i = 0; i < 120; i++) {
    const x = r() * size, y = r() * size, rad = 4 + r() * 18;
    const g = a.createRadialGradient(x, y, 1, x, y, rad);
    g.addColorStop(0, "rgba(92,122,58,.45)"); g.addColorStop(1, "rgba(92,122,58,0)");
    a.fillStyle = g; a.beginPath(); a.arc(x, y, rad, 0, 7); a.fill();
    ro.fillStyle = "rgba(255,255,255,.4)"; ro.beginPath(); ro.arc(x, y, rad, 0, 7); ro.fill();
  }
  return { albedo, height, roughness, ao };
}

/** Waxy broadleaf: midrib, branching veins, subtle sheen. */
export function foliageMaps(seed = 37, size = 512): PbrSet {
  const r = rnd(seed);
  const { c: albedo, ctx: a } = makeCanvas(size);
  const { c: height, ctx: h } = makeCanvas(size);
  const { c: roughness, ctx: ro } = makeCanvas(size);
  const { c: ao, ctx: o } = makeCanvas(size);

  const base = a.createLinearGradient(0, 0, 0, size);
  base.addColorStop(0, "#4b7a2c"); base.addColorStop(0.55, "#3d6a24"); base.addColorStop(1, "#2f5a1d");
  a.fillStyle = base; a.fillRect(0, 0, size, size);
  h.fillStyle = "#8a8a8a"; h.fillRect(0, 0, size, size);
  ro.fillStyle = "#6e6e6e"; ro.fillRect(0, 0, size, size);   // waxy = fairly smooth
  o.fillStyle = "#ffffff"; o.fillRect(0, 0, size, size);

  // Mottling
  for (let i = 0; i < 700; i++) {
    const x = r() * size, y = r() * size, rad = 6 + r() * 34;
    const g = a.createRadialGradient(x, y, 1, x, y, rad);
    const warm = r() > 0.6;
    g.addColorStop(0, warm ? "rgba(132,166,70,.3)" : "rgba(28,62,22,.28)");
    g.addColorStop(1, "rgba(0,0,0,0)");
    a.fillStyle = g; a.beginPath(); a.arc(x, y, rad, 0, 7); a.fill();
  }
  // Midrib + branching veins raise the surface
  const drawVein = (x0: number, y0: number, x1: number, y1: number, w: number, bright: number) => {
    a.strokeStyle = `rgba(${150 + bright * 50 | 0},${180 + bright * 40 | 0},${96 + bright * 40 | 0},${0.3 + bright * 0.35})`;
    a.lineWidth = w;
    h.strokeStyle = `rgba(${200 + bright * 40 | 0},${200 + bright * 40 | 0},${200 + bright * 40 | 0},.8)`;
    h.lineWidth = w * 1.1;
    o.strokeStyle = "rgba(210,210,210,.35)"; o.lineWidth = w * 2.2;
    for (const ctx2 of [a, h, o]) { ctx2.beginPath(); ctx2.moveTo(x0, y0); ctx2.lineTo(x1, y1); ctx2.stroke(); }
  };
  for (let leafRow = 0; leafRow < 3; leafRow++) {
    const cx = size * (0.2 + leafRow * 0.3);
    drawVein(cx, 0, cx + (r() - 0.5) * 30, size, 4.5, 1);
    for (let v = 1; v < 16; v++) {
      const y = (v / 16) * size;
      const spread = 48 + r() * 34;
      drawVein(cx, y, cx - spread, y + 40, 1.8, 0.5);
      drawVein(cx, y, cx + spread, y + 40, 1.8, 0.5);
    }
  }
  // Specular sheen patches: lower roughness
  for (let i = 0; i < 60; i++) {
    const x = r() * size, y = r() * size, rad = 10 + r() * 36;
    const g = ro.createRadialGradient(x, y, 1, x, y, rad);
    g.addColorStop(0, "rgba(40,40,40,.5)"); g.addColorStop(1, "rgba(40,40,40,0)");
    ro.fillStyle = g; ro.beginPath(); ro.arc(x, y, rad, 0, 7); ro.fill();
  }
  return { albedo, height, roughness, ao };
}

/** Damp forest floor: soil, grit, scattered needles. */
export function soilMaps(seed = 53, size = 512): PbrSet {
  const r = rnd(seed);
  const { c: albedo, ctx: a } = makeCanvas(size);
  const { c: height, ctx: h } = makeCanvas(size);
  const { c: roughness, ctx: ro } = makeCanvas(size);
  const { c: ao, ctx: o } = makeCanvas(size);

  a.fillStyle = "#5b4a35"; a.fillRect(0, 0, size, size);
  h.fillStyle = "#808080"; h.fillRect(0, 0, size, size);
  ro.fillStyle = "#e0e0e0"; ro.fillRect(0, 0, size, size);
  o.fillStyle = "#ffffff"; o.fillRect(0, 0, size, size);

  for (let i = 0; i < 30000; i++) {
    const x = r() * size, y = r() * size, s = 0.8 + r() * 2.6, g = r();
    a.fillStyle = g > 0.88 ? "#8d7752" : g > 0.6 ? "#6a563c" : g > 0.3 ? "#4a3b29" : "#372c1e";
    a.fillRect(x, y, s, s);
    const hv = Math.round(104 + g * 86);
    h.fillStyle = `rgb(${hv},${hv},${hv})`; h.fillRect(x, y, s, s);
  }
  // Pebbles sit proud and read smoother
  for (let i = 0; i < 160; i++) {
    const x = r() * size, y = r() * size, rad = 2 + r() * 7;
    a.fillStyle = `rgba(${130 + r() * 50 | 0},${124 + r() * 40 | 0},${110 + r() * 36 | 0},.9)`;
    a.beginPath(); a.arc(x, y, rad, 0, 7); a.fill();
    h.fillStyle = "rgba(225,225,225,.9)"; h.beginPath(); h.arc(x, y, rad, 0, 7); h.fill();
    ro.fillStyle = "rgba(120,120,120,.6)"; ro.beginPath(); ro.arc(x, y, rad, 0, 7); ro.fill();
    o.fillStyle = "rgba(170,170,170,.4)"; o.beginPath(); o.arc(x, y, rad * 1.7, 0, 7); o.fill();
  }
  // Needles and leaf litter
  for (let i = 0; i < 420; i++) {
    const x = r() * size, y = r() * size, ang = r() * Math.PI, len = 6 + r() * 20;
    a.strokeStyle = r() > 0.5 ? "rgba(92,78,42,.6)" : "rgba(58,74,36,.55)";
    a.lineWidth = 1 + r();
    a.beginPath(); a.moveTo(x, y); a.lineTo(x + Math.cos(ang) * len, y + Math.sin(ang) * len); a.stroke();
  }
  return { albedo, height, roughness, ao };
}

export type ShowcaseMaterialId = "granite" | "bark" | "foliage" | "soil";

const GENERATORS: Record<ShowcaseMaterialId, (seed?: number, size?: number) => PbrSet> = {
  granite: graniteMaps, bark: barkMaps, foliage: foliageMaps, soil: soilMaps,
};

export const SHOWCASE_MATERIALS: { id: ShowcaseMaterialId; name: string; blurb: string; metalness: number; roughnessScale: number; normalScale: number; repeat: number }[] = [
  { id: "granite", name: "Weathered granite", blurb: "Mineral speckle · fracture lines · lichen", metalness: 0.02, roughnessScale: 0.95, normalScale: 1.1, repeat: 1 },
  { id: "bark", name: "Fissured bark", blurb: "Deep ridges · damp moss · fibrous grain", metalness: 0, roughnessScale: 1, normalScale: 1.5, repeat: 2 },
  { id: "foliage", name: "Waxy broadleaf", blurb: "Branching veins · specular sheen", metalness: 0, roughnessScale: 0.78, normalScale: 0.9, repeat: 1 },
  { id: "soil", name: "Forest floor", blurb: "Grit · pebbles · needle litter", metalness: 0, roughnessScale: 1, normalScale: 1.2, repeat: 3 },
];

/** Build a real MeshStandardMaterial with the full map set wired up. */
export function showcaseMaterial(id: ShowcaseMaterialId, seed = 0): THREE.MeshStandardMaterial {
  const meta = SHOWCASE_MATERIALS.find(m => m.id === id)!;
  const maps = GENERATORS[id](seed || undefined, 512);
  const normal = heightToNormal(maps.height, meta.normalScale * 2);
  return new THREE.MeshStandardMaterial({
    map: tex(maps.albedo, true, meta.repeat),
    normalMap: tex(normal, false, meta.repeat),
    normalScale: new THREE.Vector2(meta.normalScale, meta.normalScale),
    roughnessMap: tex(maps.roughness, false, meta.repeat),
    roughness: meta.roughnessScale,
    aoMap: tex(maps.ao, false, meta.repeat),
    aoMapIntensity: 0.85,
    displacementMap: undefined,
    metalness: meta.metalness,
  });
}

/** Small square preview for the palette, rendered from the albedo + shading hint. */
export function paletteSwatch(id: ShowcaseMaterialId, size = 96): HTMLCanvasElement {
  const maps = GENERATORS[id](undefined, 256);
  const { c, ctx } = makeCanvas(size);
  ctx.drawImage(maps.albedo, 0, 0, size, size);
  // bake a soft key light so the swatch reads as a material, not a flat colour
  const light = ctx.createLinearGradient(0, 0, size, size);
  light.addColorStop(0, "rgba(255,255,255,.26)");
  light.addColorStop(0.5, "rgba(255,255,255,0)");
  light.addColorStop(1, "rgba(0,0,0,.26)");
  ctx.fillStyle = light; ctx.fillRect(0, 0, size, size);
  return c;
}
