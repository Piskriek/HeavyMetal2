import type { RenderStyle } from "./types";

export interface EnginePackage {
  schemaVersion: 1;
  name: string;
  renderStyle: RenderStyle;
  damping: number;
  maxParticles: number;
}
export const ENGINE_PACKAGES: EnginePackage[] = [
  { schemaVersion: 1, name: "Native WebGL", renderStyle: "standard", damping: 0.92, maxParticles: 128 },
  { schemaVersion: 1, name: "Cinematic", renderStyle: "cinematic", damping: 0.92, maxParticles: 128 },
  { schemaVersion: 1, name: "Wireframe", renderStyle: "wireframe", damping: 0.92, maxParticles: 32 },
];

/** Only declarative, validated packages run. A Worker alone is NOT a security sandbox. */
export class PluginOrchestrator {
  private worker: Worker | null = null;
  static validate(input: unknown): EnginePackage {
    if (!input || typeof input !== "object") throw new Error("A declarative engine package is required");
    const data = input as Record<string, unknown>;
    const permitted = ["schemaVersion", "name", "renderStyle", "damping", "maxParticles"];
    if (Object.keys(data).some(key => !permitted.includes(key))) throw new Error("Executable code and unknown capabilities are forbidden");
    if (data.schemaVersion !== 1 || typeof data.name !== "string" || data.name.length > 60 || !["standard", "cinematic", "wireframe"].includes(String(data.renderStyle)) || typeof data.damping !== "number" || !Number.isFinite(data.damping) || data.damping < 0 || data.damping > 1 || typeof data.maxParticles !== "number" || !Number.isInteger(data.maxParticles) || data.maxParticles < 0 || data.maxParticles > 128) throw new Error("Invalid engine package contract");
    return data as unknown as EnginePackage;
  }
  async diagnose(): Promise<{ latency: number; isolated: boolean; budget: number }> {
    this.dispose();
    return new Promise((resolve, reject) => {
      const start = performance.now();
      const worker = new Worker("/engine-worker.js");
      this.worker = worker;
      const timeout = window.setTimeout(() => { this.dispose(); reject(new Error("Engine worker exceeded its time budget")); }, 3000);
      worker.onerror = () => { window.clearTimeout(timeout); this.dispose(); reject(new Error("Engine worker could not start")); };
      worker.onmessage = event => {
        window.clearTimeout(timeout);
        if (event.data?.type !== "ready" || event.data?.budget !== 128) { this.dispose(); reject(new Error("Invalid worker response")); return; }
        resolve({ latency: Math.round(performance.now() - start), isolated: true, budget: event.data.budget });
        this.dispose();
      };
      worker.postMessage({ type: "diagnose", count: 128 });
    });
  }
  dispose() { this.worker?.terminate(); this.worker = null; }
}
