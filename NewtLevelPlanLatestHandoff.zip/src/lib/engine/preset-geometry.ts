import * as THREE from "three";
import { childPreset, textureRecipe, type EditablePreset, type GoblinSlot, type SurfaceMark } from "./authoring";
import type { WorldSnapshot } from "./types";
import { makePBRMaterial } from "./textures";

export function createLeafGeometry(preset: EditablePreset, segments = 36) {
  if (preset.source === "reference" && preset.reference) return referenceGeometry(preset);
  const positions: number[] = [], uv: number[] = [], indices: number[] = [];
  const across = 12, shape = preset.shape;
  for (let row = 0; row <= segments; row++) {
    const v = row / segments, envelope = Math.pow(Math.sin(v * Math.PI), 0.78);
    for (let col = 0; col <= across; col++) {
      const u = col / across, edge = 1 + Math.sin(v * 64) * shape.edgeDetail * 0.065;
      const x = (u - 0.5) * 3.5 * shape.width * envelope * edge;
      const y = (v - 0.5) * 5.2 * shape.length;
      const z = Math.abs(u - 0.5) ** 1.5 * -0.75 + Math.sin(v * Math.PI) * 0.36 + v * v * shape.curl * 0.85;
      positions.push(x, y, z); uv.push(u, v);
      if (row < segments && col < across) { const a = row * (across + 1) + col; indices.push(a, a + 1, a + across + 1, a + 1, a + across + 2, a + across + 1); }
    }
  }
  const geometry = new THREE.BufferGeometry(); geometry.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3)); geometry.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2)); geometry.setIndex(indices); geometry.computeVertexNormals(); return geometry;
}
/** Builds a raw primitive from a shape recipe — the base of the preset chain. */
export function createPrimitiveGeometry(preset: EditablePreset) {
  const sh = preset.shape;
  const seg = Math.max(3, Math.min(64, sh.segments ?? 16));
  const w = sh.width, l = sh.length, taper = sh.taper ?? 1;
  switch (sh.primitive ?? "cube") {
    case "cylinder": return new THREE.CylinderGeometry(0.9 * w * taper, 0.9 * w, 2.2 * l, seg, Math.max(1, Math.round(seg / 4)));
    case "sphere": return new THREE.SphereGeometry(1.1 * w, seg, Math.max(4, Math.round(seg * 0.6)));
    case "cone": return new THREE.ConeGeometry(1.05 * w, 2.3 * l, seg, Math.max(1, Math.round(seg / 4)));
    case "plane": return new THREE.PlaneGeometry(2.2 * w, 2.4 * l, seg, seg);
    case "torus": return new THREE.TorusGeometry(1.0 * w, 0.34 * w * taper, Math.max(6, Math.round(seg / 2)), seg * 2);
    default: {
      const bevel = sh.bevel ?? 0;
      if (bevel > 0.01) {
        const half = 1.1 * w, shape2 = new THREE.Shape();
        const b = bevel * half;
        shape2.moveTo(-half + b, -half);
        shape2.lineTo(half - b, -half); shape2.quadraticCurveTo(half, -half, half, -half + b);
        shape2.lineTo(half, half - b); shape2.quadraticCurveTo(half, half, half - b, half);
        shape2.lineTo(-half + b, half); shape2.quadraticCurveTo(-half, half, -half, half - b);
        shape2.lineTo(-half, -half + b); shape2.quadraticCurveTo(-half, -half, -half + b, -half);
        const geo = new THREE.ExtrudeGeometry(shape2, { depth: 2.2 * l, bevelEnabled: false, curveSegments: 4 });
        geo.center();
        return geo;
      }
      return new THREE.BoxGeometry(2.2 * w, 2.2 * l, 2.2 * w, 2, 2, 2);
    }
  }
}
export function createShapeObject(snapshot: WorldSnapshot, preset: EditablePreset) {
  const group = new THREE.Group();
  const geometry = preset.source === "reference" && preset.reference ? referenceGeometry(preset) : createPrimitiveGeometry(preset);
  sculptGeometry(geometry, preset.marks, "surface");
  const hasMaterial = Boolean(preset.textureId);
  const material = hasMaterial
    ? materialForPreset(snapshot, preset, "surface")
    : new THREE.MeshStandardMaterial({ color: 0xdedbd4, roughness: 0.78, metalness: 0.02 });
  const mesh = new THREE.Mesh(geometry, material);
  mesh.userData.presetId = preset.id;
  mesh.userData.meshKey = "surface";
  mesh.name = "surface";
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  group.add(mesh);
  for (const mark of preset.marks.filter(m => m.kind === "shape").slice(-48)) {
    const extra = new THREE.Mesh(new THREE.SphereGeometry(mark.radius * 0.55, 18, 12), material);
    extra.userData.presetId = preset.id;
    extra.userData.meshKey = `shape-${mark.id}`;
    extra.position.set(...mark.point);
    group.add(extra);
  }
  return group;
}
export function referenceGeometry(preset: EditablePreset) {
  const r = preset.reference!, geometry = new THREE.BufferGeometry(); geometry.setAttribute("position", new THREE.Float32BufferAttribute(r.positions, 3)); geometry.setAttribute("uv", new THREE.Float32BufferAttribute(r.uvs, 2)); geometry.computeVertexNormals(); return geometry;
}
export function sculptGeometry(geometry: THREE.BufferGeometry, marks: SurfaceMark[], target: string) {
  const positions = geometry.getAttribute("position"), normals = geometry.getAttribute("normal");
  for (const mark of marks) {
    if (mark.target !== target || !["push", "pull"].includes(mark.kind)) continue;
    for (let i = 0; i < positions.count; i++) {
      const d = Math.hypot(positions.getX(i) - mark.point[0], positions.getY(i) - mark.point[1], positions.getZ(i) - mark.point[2]) / mark.radius;
      if (d >= 1) continue;
      const amount = (1 - d * d) ** 2 * mark.strength * mark.radius * 0.38 * (mark.kind === "push" ? -1 : 1);
      positions.setXYZ(i, positions.getX(i) + normals.getX(i) * amount, positions.getY(i) + normals.getY(i) * amount, positions.getZ(i) + normals.getZ(i) * amount);
    }
  }
  positions.needsUpdate = true; geometry.computeVertexNormals(); geometry.computeBoundingSphere();
}
let materialCache: Map<string, THREE.MeshStandardMaterial> | null = null;
export function materialForPreset(snapshot: WorldSnapshot, preset: EditablePreset, meshKey = "surface", textureOverride?: string, size = 256) {
  const state = snapshot.authoring!;
  const texture = state.presets[textureOverride ?? preset.textureId ?? (preset.kind === "texture" ? preset.id : state.bindings.leafTexture)];
  const recipe = texture?.texture ?? textureRecipe("broadleaf");
  const source = recipe.normalSource ? state.presets[recipe.normalSource]?.texture ?? null : null;
  const marks = [...(texture?.marks ?? []), ...(texture?.id === preset.id ? [] : preset.marks.filter(m => m.target === meshKey))];
  const key = JSON.stringify([recipe, marks, source, size]);
  const cached = materialCache?.get(key); if (cached) return cached;
  const material = makePBRMaterial(recipe, marks, source, size); materialCache?.set(key, material); return material;
}
function editableMesh(geometry: THREE.BufferGeometry, snapshot: WorldSnapshot, preset: EditablePreset, key: string, override?: string) {
  sculptGeometry(geometry, preset.marks, key);
  const mesh = new THREE.Mesh(geometry, materialForPreset(snapshot, preset, key, override)); mesh.userData.presetId = preset.id; mesh.userData.meshKey = key; mesh.castShadow = true; mesh.receiveShadow = true; mesh.name = key; return mesh;
}
function addShapes(group: THREE.Group, snapshot: WorldSnapshot, preset: EditablePreset) {
  for (const mark of preset.marks.filter(m => m.kind === "shape").slice(-48)) {
    const mesh = editableMesh(new THREE.SphereGeometry(mark.radius * 0.55, 20, 12), snapshot, preset, `shape-${mark.id}`);
    mesh.position.set(...mark.point); group.add(mesh);
  }
}
export function createLeafObject(snapshot: WorldSnapshot, preset: EditablePreset, textureOverride?: string) {
  const group = new THREE.Group(); const textureDocument = snapshot.authoring!.presets[textureOverride ?? preset.textureId ?? ""];
  const geometry = createLeafGeometry(preset);
  if (textureDocument) sculptGeometry(geometry, textureDocument.marks, "surface");
  const mesh = editableMesh(geometry, snapshot, preset, "surface", textureOverride); group.add(mesh);
  const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.07, 0.75, 8), new THREE.MeshStandardMaterial({ color: 0x849353, roughness: 0.8 })); stem.position.set(0, -2.6 * preset.shape.length - 0.2, 0); group.add(stem);
  addShapes(group, snapshot, preset); return group;
}
export function createWoodObject(snapshot: WorldSnapshot, preset: EditablePreset) {
  const group = new THREE.Group();
  const geometry = preset.source === "reference" && preset.reference ? referenceGeometry(preset) : new THREE.CylinderGeometry(0.33 * preset.shape.width, 0.52 * preset.shape.width, 5 * preset.shape.length, 40, 32);
  const mesh = editableMesh(geometry, snapshot, preset, "surface"); group.add(mesh);
  for (let i = 0; i < 3; i++) { const branch = editableMesh(new THREE.CylinderGeometry(0.07, 0.17, 1.6, 16, 12), snapshot, preset, `branch-${i}`); branch.rotation.z = (i % 2 ? 1 : -1) * 0.85; branch.position.set((i % 2 ? -1 : 1) * 0.5, -0.3 + i * 0.7, 0); group.add(branch); }
  addShapes(group, snapshot, preset); return group;
}
export function createTreeObject(snapshot: WorldSnapshot, preset: EditablePreset) {
  const group = new THREE.Group();
  const wood = childPreset(snapshot, preset.id, "wood") ?? snapshot.authoring!.presets[snapshot.authoring!.bindings.wood];
  const leaf = childPreset(snapshot, preset.id, "leaf") ?? snapshot.authoring!.presets[snapshot.authoring!.bindings.leaf];
  const woodObject = createWoodObject(snapshot, wood); woodObject.scale.setScalar(0.9); woodObject.position.y = -0.5; group.add(woodObject);
  for (let i = 0; i < 21; i++) {
    const leafObject = createLeafObject(snapshot, leaf); const a = i * 2.399, h = i / 21;
    leafObject.scale.setScalar(0.34 + (i % 3) * 0.03); leafObject.rotation.set(-0.4 + (i % 2) * 0.8, a, 0.5 + i % 3 * 0.4); leafObject.position.set(Math.cos(a) * (1.15 - h * 0.5), 0.2 + h * 2.6, Math.sin(a) * (1.15 - h * 0.5)); group.add(leafObject);
  }
  for (const mark of preset.marks.filter(m => ["leaf", "wood", "shape"].includes(m.kind)).slice(-64)) {
    const item = mark.kind === "wood" ? createWoodObject(snapshot, wood) : createLeafObject(snapshot, leaf);
    item.scale.setScalar(mark.kind === "wood" ? mark.radius * 0.25 : mark.radius * 0.45); item.position.set(...mark.point); item.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(...mark.normal)); group.add(item);
  }
  return group;
}
const SLOT_ORIGIN: Record<GoblinSlot, [number, number, number]> = { head: [0, 1.8, 0], ears: [0, 2.0, 0], body: [0, 0.2, 0], arms: [0, 0.25, 0], legs: [0, -1.3, 0], armor: [0, 0.4, 0] };
export function createGoblinPart(snapshot: WorldSnapshot, preset: EditablePreset) {
  const group = new THREE.Group(), part = preset.part!; group.name = preset.id; group.userData.presetId = preset.id;
  const factor = part.variant === "long" ? 1.3 : part.variant === "chunky" ? 1.2 : 1;
  const add = (geo: THREE.BufferGeometry, key: string, position: [number, number, number] = [0, 0, 0], scale: [number, number, number] = [1, 1, 1]) => { const mesh = editableMesh(geo, snapshot, preset, key); mesh.position.set(...position); mesh.scale.set(...scale); group.add(mesh); return mesh; };
  const sphere = (radius: number) => new THREE.SphereGeometry(radius, 32, 24);
  if (preset.source === "reference" && preset.reference) add(referenceGeometry(preset), "surface");
  else if (part.slot === "head") {
    add(sphere(0.8), "surface", [0, 0, 0], [factor, part.variant === "long" ? 1.15 : 0.94, 0.8]);
    add(sphere(0.42), "jaw", [0, -0.38, 0.25], [1.1, 0.75, 0.9]);
    add(sphere(0.25), "nose", [0, -0.02, 0.66], [part.variant === "chunky" ? 1.6 : 1, 0.75, factor * 1.4]);
    for (const side of [-1, 1]) {
      const eye = new THREE.Mesh(sphere(0.16), new THREE.MeshStandardMaterial({ color: 0xe2d59f, roughness: 0.4 })); eye.position.set(side * 0.31, 0.12, 0.62); eye.scale.set(1.1, 0.9, 0.5); group.add(eye);
      const pupil = new THREE.Mesh(sphere(0.075), new THREE.MeshStandardMaterial({ color: 0x1f2c17 })); pupil.position.set(side * 0.29, 0.12, 0.7); pupil.scale.z = 0.4; group.add(pupil);
      const brow = add(new THREE.CapsuleGeometry(0.075, 0.33, 5, 12), `brow-${side}`, [side * 0.33, 0.3, 0.62]); brow.rotation.z = side * 1.1;
      const tooth = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.25, 8), new THREE.MeshStandardMaterial({ color: 0xe9dfba })); tooth.position.set(side * 0.21, -0.34, 0.61); group.add(tooth);
    }
  } else if (part.slot === "ears") {
    for (const side of [-1, 1]) {
      const ear = add(new THREE.SphereGeometry(0.55, 28, 20), `ear-${side}`, [side * (0.83 + factor * 0.13), 0, 0], [factor * 0.95, 0.38, 0.19]); ear.rotation.z = side * 0.38;
      const tip = add(new THREE.ConeGeometry(0.23, 0.66 * factor, 20, 12), `tip-${side}`, [side * (1.16 + factor * 0.1), 0.17, 0]); tip.rotation.z = side * -1.08; tip.scale.z = 0.3;
    }
  } else if (part.slot === "body") {
    add(sphere(0.75), "surface", [0, -0.08, 0], [factor * 0.82, 1.28, 0.76]);
    add(new THREE.CylinderGeometry(0.25, 0.31, 0.42, 24, 16), "neck", [0, 0.95, 0]);
    const belt = new THREE.Mesh(new THREE.TorusGeometry(0.57, 0.09, 8, 32), new THREE.MeshStandardMaterial({ color: 0x604c38, roughness: 0.9 })); belt.rotation.x = Math.PI / 2; belt.position.y = -0.61; belt.scale.z = 0.74; group.add(belt);
  } else if (part.slot === "arms") {
    for (const side of [-1, 1]) { const arm = add(new THREE.CapsuleGeometry(0.21 * (part.variant === "chunky" ? 1.4 : 1), 1.22 * factor, 8, 24), `arm-${side}`, [side * 0.9, -0.15, 0]); arm.rotation.z = side * 0.22; add(sphere(0.27), `hand-${side}`, [side * 1.1, -1.02 * factor, 0.12], [0.9, 1.2, 0.8]); }
  } else if (part.slot === "legs") {
    for (const side of [-1, 1]) { add(new THREE.CapsuleGeometry(0.22, 0.82 * factor, 8, 24), `leg-${side}`, [side * 0.35, 0, 0]); add(sphere(0.3), `boot-${side}`, [side * 0.35, -0.57 * factor, 0.18], [1, 0.55, 1.55]); }
  } else {
    for (const side of [-1, 1]) { const plate = add(new THREE.SphereGeometry(0.35 * factor, 18, 12, 0, Math.PI * 2, 0, Math.PI / 2), `shoulder-${side}`, [side * 0.77, 0.48, 0]); plate.rotation.z = side * -0.4; }
    add(new THREE.BoxGeometry(0.78 * factor, 0.64, 0.15, 8, 8, 1), "chest", [0, 0.15, 0.57]);
    const rivetMaterial = new THREE.MeshStandardMaterial({ color: 0xc6b37c, metalness: 0.8, roughness: 0.3 });
    for (const x of [-0.29, 0.29]) for (const y of [-0.04, 0.33]) { const rivet = new THREE.Mesh(sphere(0.045), rivetMaterial); rivet.position.set(x, y, 0.67); group.add(rivet); }
  }
  addShapes(group, snapshot, preset);
  group.position.set(...SLOT_ORIGIN[part.slot]); group.position.add(new THREE.Vector3(...part.position));
  group.rotation.set(...part.rotation.map(v => v * Math.PI / 180) as [number, number, number]); group.scale.set(...part.scale); group.visible = part.enabled; return group;
}
export function createGoblinObject(snapshot: WorldSnapshot, preset: EditablePreset) {
  const group = new THREE.Group();
  const parts = snapshot.graph.nodes[preset.id].children.map(ref => snapshot.authoring!.presets[ref.nodeId]).filter(p => p?.kind === "part");
  parts.forEach(p => group.add(createGoblinPart(snapshot, p))); return group;
}
function buildPresetObject(snapshot: WorldSnapshot, nodeId: string) {
  const p = snapshot.authoring!.presets[nodeId];
  if (p.kind === "shape" || p.kind === "object") return createShapeObject(snapshot, p);
  if (p.kind === "tree") return createTreeObject(snapshot, p);
  if (p.kind === "wood") return createWoodObject(snapshot, p);
  if (p.kind === "goblin") return createGoblinObject(snapshot, p);
  if (p.kind === "part") { const object = createGoblinPart(snapshot, p); object.position.set(0, 0, 0); return object; }
  if (p.kind === "texture" && ["bark", "skin", "metal"].includes(p.texture!.pattern)) { const group = new THREE.Group(); const mesh = editableMesh(new THREE.SphereGeometry(2, 64, 48), snapshot, p, "surface"); group.add(mesh); return group; }
  const leaf = p.kind === "texture" ? snapshot.authoring!.presets[snapshot.authoring!.bindings.leaf] : p;
  return createLeafObject(snapshot, leaf, p.kind === "texture" ? p.id : undefined);
}
export function createPresetObject(snapshot: WorldSnapshot, nodeId: string) { materialCache = new Map(); try { return buildPresetObject(snapshot, nodeId); } finally { materialCache = null; } }
export function disposePresetObject(object: THREE.Object3D) {
  const geometries = new Set<THREE.BufferGeometry>(), materials = new Set<THREE.Material>(), textures = new Set<THREE.Texture>();
  object.traverse(child => { if (child instanceof THREE.Mesh || child instanceof THREE.Line) { geometries.add(child.geometry); const list = Array.isArray(child.material) ? child.material : [child.material]; list.forEach(m => { materials.add(m); if (m instanceof THREE.MeshStandardMaterial) [m.map, m.normalMap, m.roughnessMap].forEach(t => { if (t) textures.add(t); }); }); } });
  geometries.forEach(g => g.dispose()); textures.forEach(t => t.dispose()); materials.forEach(m => m.dispose()); object.removeFromParent();
}
export const GOBLIN_SLOT_ORIGIN = SLOT_ORIGIN;
