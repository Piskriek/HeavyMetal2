import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { TransformControls } from "three/addons/controls/TransformControls.js";
import { createPresetObject, disposePresetObject, GOBLIN_SLOT_ORIGIN } from "./preset-geometry";
import type { AuthorTool, GoblinPart, SurfaceMark } from "./authoring";
import type { WorldSnapshot, Vec3 } from "./types";

export interface PresetSceneOptions { nodeId: string; tool: AuthorTool; radius: number; strength: number; color: string; wireframe: boolean; selectedPart?: string; }
export class PresetScene {
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(37, 1, 0.02, 200);
  private renderer: THREE.WebGLRenderer;
  private controls: OrbitControls;
  private transform: TransformControls;
  private object = new THREE.Group();
  private cursor: THREE.Group;
  private raycaster = new THREE.Raycaster();
  private pointer = new THREE.Vector2();
  private observer: ResizeObserver;
  private down = false;
  private button = 0;
  private lastTime = 0;
  private lastPoint = new THREE.Vector3(Infinity, Infinity, Infinity);
  private hit: THREE.Intersection | null = null;
  private key = "";
  private frame = 0;
  private previous = 0;
  private metricsTime = 0;
  private alt = false;
  private activePart: string | null = null;
  constructor(private container: HTMLElement, private snapshot: WorldSnapshot, private options: PresetSceneOptions, private callbacks: { onMark: (presetId: string, mark: SurfaceMark) => void; onPartTransform: (id: string, part: GoblinPart) => void; onMetrics: (triangles: number, fps: number) => void }) {
    this.renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true }); this.renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5)); this.renderer.setClearColor(0, 0); this.renderer.toneMapping = THREE.ACESFilmicToneMapping; this.renderer.toneMappingExposure = 1.22;
    this.renderer.domElement.setAttribute("aria-label", "Editable 3D preset. Paint directly on the surface, push or pull geometry, and assemble parts."); this.renderer.domElement.tabIndex = 0; container.appendChild(this.renderer.domElement);
    this.controls = new OrbitControls(this.camera, this.renderer.domElement); this.controls.enableDamping = true; this.controls.dampingFactor = 0.09; this.controls.minDistance = 1; this.controls.maxDistance = 25; this.controls.enablePan = false;
    this.controls.mouseButtons = { LEFT: THREE.MOUSE.ROTATE, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: THREE.MOUSE.PAN };
    this.scene.add(new THREE.HemisphereLight(0xf0f4de, 0x283b39, 2.15));
    const light = new THREE.DirectionalLight(0xffeccb, 3.4); light.position.set(-5, 8, 9); this.scene.add(light);
    const rim = new THREE.DirectionalLight(0xb1d4d5, 2.0); rim.position.set(6, 3, -6); this.scene.add(rim);
    const grid = new THREE.GridHelper(16, 32, 0x506442, 0x33462e); grid.position.y = -3.25; (grid.material as THREE.Material).transparent = true; (grid.material as THREE.Material).opacity = 0.24; this.scene.add(grid);
    const platform = new THREE.Mesh(new THREE.CylinderGeometry(2.5, 2.6, 0.12, 80), new THREE.MeshStandardMaterial({ color: 0x243221, roughness: 0.8, metalness: 0.2 })); platform.position.y = -3.17; this.scene.add(platform);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(2.57, 0.012, 6, 100), new THREE.MeshBasicMaterial({ color: 0x9fbd7d, transparent: true, opacity: 0.45 })); ring.rotation.x = Math.PI / 2; ring.position.y = -3.07; this.scene.add(ring);
    this.cursor = new THREE.Group(); const outer = new THREE.Mesh(new THREE.RingGeometry(0.94, 1, 64), new THREE.MeshBasicMaterial({ color: 0xc2ef8a, side: THREE.DoubleSide, depthTest: false, transparent: true, opacity: 0.9 })); outer.renderOrder = 20; this.cursor.add(outer);
    const gel = new THREE.Mesh(new THREE.SphereGeometry(1, 20, 12), new THREE.MeshBasicMaterial({ color: 0xc2ef8a, transparent: true, opacity: 0.055, depthWrite: false })); this.cursor.add(gel); this.cursor.visible = false; this.scene.add(this.cursor);
    this.transform = new TransformControls(this.camera, this.renderer.domElement); this.transform.setSize(0.75); this.scene.add(this.transform.getHelper()); this.transform.enabled = false; this.transform.getHelper().visible = false;
    this.transform.addEventListener("dragging-changed", e => { this.controls.enabled = !e.value; });
    this.transform.addEventListener("mouseUp", () => {
      const id = this.activePart, obj = this.transform.object; if (!id || !obj) return;
      const part = this.snapshot.authoring!.presets[id]?.part; if (!part) return; const origin = this.snapshot.authoring!.presets[this.options.nodeId].kind === "goblin" ? GOBLIN_SLOT_ORIGIN[part.slot] : [0, 0, 0];
      this.callbacks.onPartTransform(id, { ...part, position: obj.position.toArray().map((v, i) => Math.max(-3, Math.min(3, +(v - origin[i]).toFixed(3)))) as Vec3, rotation: [obj.rotation.x, obj.rotation.y, obj.rotation.z].map(v => +(THREE.MathUtils.radToDeg(v) % 360).toFixed(2)) as Vec3, scale: obj.scale.toArray().map(v => Math.max(0.2, Math.min(2, +v.toFixed(3)))) as Vec3 });
    });
    this.scene.add(this.object); this.observer = new ResizeObserver(() => this.resize()); this.observer.observe(container); this.resize(); this.update(snapshot, options); this.reset();
    const canvas = this.renderer.domElement; canvas.addEventListener("pointermove", this.move); canvas.addEventListener("pointerdown", this.start); canvas.addEventListener("pointerup", this.end); canvas.addEventListener("pointerleave", this.end); canvas.addEventListener("contextmenu", this.context);
    window.addEventListener("keydown", this.keyDown); window.addEventListener("keyup", this.keyUp); this.renderer.setAnimationLoop(this.animate);
  }
  private resize() { const w = this.container.clientWidth || 1, h = this.container.clientHeight || 1; this.renderer.setSize(w, h); this.camera.aspect = w / h; this.camera.updateProjectionMatrix(); }
  reset() { const p = this.snapshot.authoring!.presets[this.options.nodeId]; const goblin = p.kind === "goblin"; const distance = p.kind === "part" ? 6.3 : goblin ? 11 : p.kind === "tree" ? 14.5 : 11.5; this.camera.position.set(goblin ? 4.3 : 2.8, goblin ? 2.8 : 1.4, distance * Math.max(1, 0.85 / this.camera.aspect)); this.controls.target.set(0, goblin ? 0.45 : 0, 0); this.controls.update(); }
  zoom(direction: number) { this.camera.position.sub(this.controls.target).multiplyScalar(direction > 0 ? 0.84 : 1.2).add(this.controls.target); this.controls.update(); }
  private transforms() { return ["translate", "rotate", "scale"].includes(this.options.tool); }
  update(snapshot: WorldSnapshot, options: PresetSceneOptions) {
    const oldId = this.options.nodeId; this.activePart = options.selectedPart ?? this.activePart; this.snapshot = snapshot; this.options = options;
    const key = options.nodeId + JSON.stringify(snapshot.authoring);
    if (key !== this.key) {
      this.key = key; this.transform.detach(); disposePresetObject(this.object); this.object = createPresetObject(snapshot, options.nodeId); this.scene.add(this.object);
      if (oldId !== options.nodeId) { this.activePart = null; this.reset(); }
    }
    this.object.traverse(o => { if (o instanceof THREE.Mesh && o.material instanceof THREE.MeshStandardMaterial) o.material.wireframe = options.wireframe; });
    this.controls.enableRotate = options.tool === "orbit" || this.alt; this.transform.enabled = this.transforms(); this.transform.getHelper().visible = this.transforms();
    if (this.transforms()) {
      this.transform.setMode(options.tool as "translate" | "rotate" | "scale");
      const current = snapshot.authoring!.presets[options.nodeId];
      const target = current.kind === "part" ? this.object : this.activePart ? this.object.getObjectByName(this.activePart) : this.object.children.find(o => o.userData.presetId);
      if (target) { this.activePart = target.userData.presetId ?? current.id; this.transform.attach(target); }
    }
    this.renderer.domElement.style.cursor = options.tool === "orbit" ? "grab" : "crosshair";
    this.cursor.scale.setScalar(options.radius); if (options.tool === "orbit" || this.transforms()) this.cursor.visible = false;
  }
  private move = (event: PointerEvent) => {
    const rect = this.renderer.domElement.getBoundingClientRect(); this.pointer.set((event.clientX - rect.left) / rect.width * 2 - 1, -(event.clientY - rect.top) / rect.height * 2 + 1); this.raycaster.setFromCamera(this.pointer, this.camera);
    this.hit = this.raycaster.intersectObject(this.object, true).find(h => h.object.userData.presetId) ?? null;
    this.cursor.visible = !!this.hit && this.options.tool !== "orbit" && !this.transforms() && !this.alt;
    if (this.hit) { const mesh = this.hit.object, normal = this.hit.face?.normal.clone().transformDirection(mesh.matrixWorld) ?? new THREE.Vector3(0, 0, 1); this.cursor.position.copy(this.hit.point).addScaledVector(normal, 0.02); this.cursor.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), normal); if (this.down) this.paint(); }
  };
  private start = (event: PointerEvent) => {
    if (this.options.tool === "orbit" || this.alt || this.transforms() || event.button === 1) return;
    this.move(event); this.down = true; this.button = event.button; this.lastPoint.set(Infinity, Infinity, Infinity); this.paint();
  };
  private end = () => { this.down = false; };
  private context = (e: Event) => { if (this.options.tool !== "orbit") e.preventDefault(); };
  private keyDown = (e: KeyboardEvent) => { if (e.key === "Alt") { this.alt = true; this.controls.enableRotate = true; } };
  private keyUp = (e: KeyboardEvent) => { if (e.key === "Alt") { this.alt = false; this.controls.enableRotate = this.options.tool === "orbit"; } };
  private paint() {
    const hit = this.hit; if (!hit || this.transforms() || performance.now() - this.lastTime < 75 || hit.point.distanceTo(this.lastPoint) < this.options.radius * 0.18) return;
    const current = this.snapshot.authoring!.presets[this.options.nodeId];
    const hitPreset = this.snapshot.authoring!.presets[hit.object.userData.presetId as string];
    const texturePaint = this.options.tool === "paint" && ["leaf", "wood"].includes(hitPreset.kind) && hitPreset.textureId;
    const id = current.kind === "texture" || current.kind === "tree" && ["wood", "leaf", "shape"].includes(this.options.tool) ? current.id : texturePaint ? hitPreset.textureId! : hitPreset.id;
    if (this.snapshot.authoring!.presets[id].marks.length >= 320) return;
    const point = (current.kind === "tree" && ["wood", "leaf", "shape"].includes(this.options.tool) ? this.object : hit.object).worldToLocal(hit.point.clone()), normal = hit.face?.normal ?? new THREE.Vector3(0, 0, 1);
    let kind = this.options.tool as SurfaceMark["kind"]; if (this.button === 2 && ["push", "pull"].includes(kind)) kind = kind === "push" ? "pull" : "push";
    if (!["paint", "push", "pull", "shape", "wood", "leaf"].includes(kind)) return;
    const uv = hit.uv?.toArray() ?? [0.5, 0.5];
    this.callbacks.onMark(id, { id: crypto.randomUUID(), kind, target: current.kind === "texture" || texturePaint ? "surface" : hit.object.userData.meshKey ?? "surface", point: point.toArray() as Vec3, normal: normal.toArray() as Vec3, uv: uv.map(v => Math.max(0, Math.min(1, v))) as [number, number], radius: this.options.radius, uvRadius: Math.min(0.4, this.options.radius / (current.kind === "goblin" || current.kind === "part" ? 3 : 6)), strength: this.options.strength, color: this.options.color });
    this.lastTime = performance.now(); this.lastPoint.copy(hit.point);
  }
  private animate = (time: number) => { if (document.hidden) return; this.controls.update(); this.renderer.render(this.scene, this.camera); const dt = this.previous ? (time - this.previous) / 1000 : 0; this.previous = time; this.metricsTime += dt; this.frame++; if (this.metricsTime > 1.5) { this.callbacks.onMetrics(this.renderer.info.render.triangles, Math.round(this.frame / this.metricsTime)); this.metricsTime = 0; this.frame = 0; } };
  dispose() { this.renderer.setAnimationLoop(null); this.observer.disconnect(); this.controls.dispose(); this.transform.dispose(); const c = this.renderer.domElement; c.removeEventListener("pointermove", this.move); c.removeEventListener("pointerdown", this.start); c.removeEventListener("pointerup", this.end); c.removeEventListener("pointerleave", this.end); c.removeEventListener("contextmenu", this.context); window.removeEventListener("keydown", this.keyDown); window.removeEventListener("keyup", this.keyUp); disposePresetObject(this.scene); this.renderer.dispose(); c.remove(); }
}
