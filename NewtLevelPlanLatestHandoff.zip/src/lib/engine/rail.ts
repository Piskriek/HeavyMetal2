import * as THREE from "three";

/** C1-continuous cubic Bezier segments, parameterized by arc length. */
export class SlottedRailSystem {
  readonly curve: THREE.CurvePath<THREE.Vector3>;
  readonly length: number;
  constructor(anchors: THREE.Vector3[], closed = true) {
    if (anchors.length < 2 || anchors.length > 64) throw new Error("Rails require 2–64 anchors");
    this.curve = new THREE.CurvePath<THREE.Vector3>();
    const at = (i: number) => closed ? anchors[(i + anchors.length) % anchors.length] : anchors[Math.max(0, Math.min(anchors.length - 1, i))];
    const count = closed ? anchors.length : anchors.length - 1;
    for (let i = 0; i < count; i++) {
      const a = at(i), b = at(i + 1);
      const c1 = a.clone().add(at(i + 1).clone().sub(at(i - 1)).multiplyScalar(1 / 6));
      const c2 = b.clone().sub(at(i + 2).clone().sub(at(i)).multiplyScalar(1 / 6));
      this.curve.add(new THREE.CubicBezierCurve3(a, c1, c2, b));
    }
    this.length = this.curve.getLength();
  }
  point(distance: number) { return this.curve.getPointAt(((distance / this.length) % 1 + 1) % 1); }
  tangent(distance: number) { return this.curve.getTangentAt(((distance / this.length) % 1 + 1) % 1).normalize(); }
  nearest(point: THREE.Vector3) {
    let best = Infinity, distance = 0;
    for (let i = 0; i < 256; i++) {
      const d = i / 256 * this.length;
      const squared = this.point(d).distanceToSquared(point);
      if (squared < best) { best = squared; distance = d; }
    }
    return distance;
  }
  winchForce(position: THREE.Vector3, velocity: THREE.Vector3, anchor: THREE.Vector3, mass = 1) {
    // Critically damped spring; independent of rendering fidelity.
    const stiffness = 32;
    return anchor.clone().sub(position).multiplyScalar(stiffness).addScaledVector(velocity, -2 * Math.sqrt(stiffness * mass));
  }
}
