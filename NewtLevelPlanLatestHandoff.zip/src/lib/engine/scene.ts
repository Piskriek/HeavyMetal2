import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { TransformControls } from "three/addons/controls/TransformControls.js";
import { SlottedRailSystem } from "./rail";
import { createPresetObject, disposePresetObject } from "./preset-geometry";
import { makePBRMaterial } from "./textures";
import { childPreset } from "./authoring";
import { AutoSizeEngine, GelBrushSystem } from "./brush";
import { graffitiWall, paintSpill } from "./swatches";
import { showcaseMaterial } from "./pbr-showcase";
import { baseTerrainHeight, resolvePushedTreePosition, sampleCarvedTerrainHeight, sampleTerrainSlope, SpatialHashGrid } from "./spatial";
import { MAJORITY_RULES, RACER_ROSTER, type AvatarCameraMode, type AvatarStatus, type BrushStroke, type RacerStanding, type SceneMetrics, type StudioSettings, type StudioTool, type Vec3, type WorldSnapshot, type WorldStyle } from "./types";

function isTypingTarget(target: EventTarget | null) {
  const el = target as Element | null;
  return Boolean(el && typeof el.matches === "function" && el.matches("input,textarea,select"));
}

export type StudioTheme = "deep" | "paper";
type SceneOptions = { tool: StudioTool; depth: number; playing: boolean; pro: boolean; layers: Record<string, boolean>; theme: StudioTheme };

const PAPER_RACE_COLORS = [0xff2d6f, 0x00c4ff, 0xff7a1a, 0xa8e600, 0x8a5cff];
const PAPER_INK = 0x14161a;
const PAPER_GOLD = 0xd9a521;
const PAPER_GREEN = 0x6dd400;
type Rider = {
  id: string;
  name: string;
  color: string;
  odds: number;
  mesh: THREE.Group;
  distance: number;
  speed: number;
  baseSpeed: number;
  boostTimer: number;
  laps: number;
  attached: boolean;
  velocity: THREE.Vector3;
  target: number;
  chinCooldown: number;
};
export type AvatarMoveAction = "forward" | "backward" | "left" | "right" | "jump" | "sprint";

const PALETTES = {
  verdant: { grass: ["#73834e", "#7c8c53", "#66794a", "#87915d"], stone: ["#a18d65", "#bba274", "#c6b183", "#8e7b58"], leaf: ["#315e4a", "#487559", "#5c8963"], water: "#55b2b0" },
  dunes: { grass: ["#b67d48", "#c38c55", "#d09b63", "#ac7041"], stone: ["#ce9a70", "#daa979", "#e4b98b", "#b37959"], leaf: ["#807451", "#9a8659", "#b8a166"], water: "#78b0ad" },
  lunar: { grass: ["#626079", "#757089", "#68637e", "#807890"], stone: ["#9d94b9", "#aca5c4", "#c0b5d9", "#817a9b"], leaf: ["#656e98", "#9295b9", "#b7b1dc"], water: "#80d1dd" },
};
const mat = (color: string | number, extra: THREE.MeshStandardMaterialParameters = {}) => new THREE.MeshStandardMaterial({ color, roughness: 0.85, flatShading: true, ...extra });
const seeded = (initial: number) => { let seed = initial >>> 0; return () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; }; };
export function terrainHeight(x: number, z: number) {
  return baseTerrainHeight(x, z);
}
function disposeObject(object: THREE.Object3D) {
  object.traverse(child => {
    if (child instanceof THREE.Mesh || child instanceof THREE.Line || child instanceof THREE.Points) {
      child.geometry.dispose();
      const materials = Array.isArray(child.material) ? child.material : [child.material];
      materials.forEach(m => m.dispose());
    }
  });
  object.removeFromParent();
}
function ribbon(curve: THREE.Curve<THREE.Vector3>, width: number, color: string, count = 240) {
  const vertices: number[] = [], indices: number[] = [];
  for (let i = 0; i <= count; i++) {
    const p = curve.getPointAt(i / count), tangent = curve.getTangentAt(i / count);
    const normal = new THREE.Vector3(-tangent.z, 0, tangent.x).normalize().multiplyScalar(width / 2);
    vertices.push(p.x + normal.x, p.y, p.z + normal.z, p.x - normal.x, p.y, p.z - normal.z);
    if (i < count) { const a = i * 2; indices.push(a, a + 2, a + 1, a + 1, a + 2, a + 3); }
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute("position", new THREE.Float32BufferAttribute(vertices, 3));
  geometry.setIndex(indices); geometry.computeVertexNormals();
  const mesh = new THREE.Mesh(geometry, mat(color, { side: THREE.DoubleSide, metalness: 0.25 }));
  mesh.receiveShadow = true;
  return mesh;
}

export class SandboxScene {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(36, 1, 0.05, 1600);
  private controls: OrbitControls;
  private transform: TransformControls;
  private materialDetail = -1;
  private authoringKey = "";
  private detailTrees = new THREE.Group();
  private world = new THREE.Group();
  private terrain = new THREE.Group();
  private forest = new THREE.Group();
  private water = new THREE.Group();
  private oceanGroup = new THREE.Group();
  private oceanMesh: THREE.Mesh | null = null;
  private oceanBasePositions: Float32Array | null = null;
  private crowdGroup = new THREE.Group();
  private railGroup = new THREE.Group();
  private strokes = new THREE.Group();
  private customRails = new THREE.Group();
  private micro = new THREE.Group();
  private universe = new THREE.Group();
  private brush = new THREE.Group();
  private chunks = new THREE.Group();
  private avatarGroup = new THREE.Group();
  private avatarRig = new THREE.Group();
  private avatarBeacon: THREE.Mesh;
  private cheerAura: THREE.Mesh;
  private paperGroup = new THREE.Group();
  private paperIsland = new THREE.Group();
  private paperSpheres: THREE.Group[] = [];
  private paperBuilt = false;
  private currentTheme: StudioTheme = "deep";
  private gridHelper!: THREE.GridHelper;
  private paperGrid: THREE.GridHelper | null = null;
  private spatialGrid = new SpatialHashGrid(4);
  private avatarEmitTime = 0;
  private avatar = {
    spawned: false,
    mode: "orbit" as AvatarCameraMode,
    position: new THREE.Vector3(2.2, terrainHeight(2.2, 4.8), 4.8),
    velocity: new THREE.Vector3(),
    yaw: Math.atan2(-3.2, -6.8),
    pitch: -0.06,
    grounded: true,
    walkTime: 0,
    spectateRail: false,
    cheerTimer: 0,
    wasted: false,
    wastedTimer: 0,
    chinHits: 0,
    lastChinHitBy: null as string | null,
    lapWinner: null as string | null,
  };
  private collider: THREE.Mesh | null = null;
  private colliderBase: Float32Array | null = null;
  private trees: { x: number; z: number; scale: number; rotation: number }[] = [];
  private treeInstances: THREE.InstancedMesh[] = [];
  private rail: SlottedRailSystem | null = null;
  private chain: THREE.InstancedMesh | null = null;
  private riders: Rider[] = [];
  private cable: THREE.Line;
  private raycaster = new THREE.Raycaster();
  private pointer = new THREE.Vector2();
  private pointerDown = false;
  private pointerButton = 0;
  private lastPointerX = 0;
  private lastPointerY = 0;
  private lastStroke = 0;
  private lastPaintPoint = new THREE.Vector3(Infinity, Infinity, Infinity);
  private keys = new Set<string>();
  private virtualKeys = new Set<string>();
  private resizeObserver: ResizeObserver;
  private snapshot: WorldSnapshot;
  private options: SceneOptions;
  private lastTime = 0;
  private elapsed = 0;
  private accumulator = 0;
  private metricsTime = 0;
  private frames = 0;
  private strokeKey = "";
  private railKey = "";
  private economyKey = "";
  private depthTarget = new THREE.Vector3(28, 24, 33);
  private lookTarget = new THREE.Vector3(0, 0, 0);
  private transitioning = false;
  private styleKey = "";
  private destroyed = false;
  private firstResize = true;
  private chunkLife = 0;
  private onStroke: (stroke: BrushStroke) => void;
  private onRail: (point: Vec3) => void;
  private onMetrics: (metrics: SceneMetrics) => void;
  private onAvatar?: (status: AvatarStatus) => void;
  private onChinHit?: (riderId: string, riderName: string, totalChinHits: number) => void;
  private onRaceFinish?: (winnerId: string, winnerName: string, standings: RacerStanding[]) => void;

  constructor(
    private container: HTMLElement,
    snapshot: WorldSnapshot,
    options: SceneOptions,
    callbacks: {
      onStroke: (stroke: BrushStroke) => void;
      onRail: (point: Vec3) => void;
      onTransform: (changes: Partial<StudioSettings>) => void;
      onMetrics: (metrics: SceneMetrics) => void;
      onAvatar?: (status: AvatarStatus) => void;
      onChinHit?: (riderId: string, riderName: string, totalChinHits: number) => void;
      onRaceFinish?: (winnerId: string, winnerName: string, standings: RacerStanding[]) => void;
    },
  ) {
    this.snapshot = snapshot; this.options = options;
    this.onStroke = callbacks.onStroke; this.onRail = callbacks.onRail; this.onMetrics = callbacks.onMetrics;
    this.onAvatar = callbacks.onAvatar; this.onChinHit = callbacks.onChinHit; this.onRaceFinish = callbacks.onRaceFinish;
    this.renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.6));
    this.renderer.shadowMap.enabled = true; this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.shadowMap.autoUpdate = false; this.renderer.shadowMap.needsUpdate = true;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping; this.renderer.toneMappingExposure = 1.18;
    this.renderer.setClearColor(0x000000, 0);
    this.renderer.domElement.setAttribute("aria-label", "Interactive procedural floating island. Drag to orbit, scroll to zoom, use the gel brush to grow or carve terrain, or spawn on the surface to walk in 1st and 3rd person.");
    this.renderer.domElement.tabIndex = 0;
    container.appendChild(this.renderer.domElement);
    this.camera.position.copy(this.depthTarget);
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true; this.controls.dampingFactor = 0.07;
    this.controls.minDistance = 2.2; this.controls.maxDistance = 160;
    this.controls.maxPolarAngle = Math.PI * 0.65;
    this.controls.mouseButtons = { LEFT: THREE.MOUSE.ROTATE, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: THREE.MOUSE.PAN };
    this.scene.add(new THREE.HemisphereLight(0xd4e3cd, 0x273c41, 2.2));
    const sun = new THREE.DirectionalLight(0xffe5b9, 3.6); sun.position.set(-15, 25, 12);
    sun.castShadow = true; sun.shadow.mapSize.set(1024, 1024);
    Object.assign(sun.shadow.camera, { left: -26, right: 26, top: 26, bottom: -26, near: 1, far: 75 });
    sun.shadow.normalBias = 0.04; sun.shadow.bias = -0.0001;
    this.scene.add(sun);
    const rim = new THREE.DirectionalLight(0x80b8c0, 1.65); rim.position.set(15, 5, -15); this.scene.add(rim);
    this.forest.add(this.detailTrees);
    this.avatarBeacon = new THREE.Mesh(
      new THREE.RingGeometry(0.36, 0.48, 36),
      new THREE.MeshBasicMaterial({ color: 0xc2ef8a, side: THREE.DoubleSide, transparent: true, opacity: 0.75 }),
    );
    this.avatarBeacon.rotation.x = -Math.PI / 2;
    this.avatarBeacon.position.y = 0.03;
    this.cheerAura = new THREE.Mesh(
      new THREE.RingGeometry(0.52, 0.95, 40),
      new THREE.MeshBasicMaterial({ color: 0xf7e07c, side: THREE.DoubleSide, transparent: true, opacity: 0.85 }),
    );
    this.cheerAura.rotation.x = -Math.PI / 2;
    this.cheerAura.position.y = 0.06;
    this.cheerAura.visible = false;
    this.avatarGroup.add(this.avatarBeacon, this.cheerAura, this.avatarRig);
    this.avatarGroup.visible = false;
    this.buildOceanPlanet();
    this.world.add(this.oceanGroup, this.terrain, this.forest, this.water, this.railGroup, this.crowdGroup, this.strokes, this.customRails, this.chunks, this.avatarGroup);
    this.scene.add(this.world, this.micro, this.universe, this.paperGroup);
    const grid = new THREE.GridHelper(90, 45, 0x314b43, 0x243b35); grid.position.y = -8.6;
    const gm = grid.material as THREE.Material; gm.transparent = true; gm.opacity = 0.15; this.scene.add(grid);
    this.gridHelper = grid;
    // Paper-mode grid: a faint ink layout grid replacing the dark engineering grid
    const paperGrid = new THREE.GridHelper(240, 48, 0x14161a, 0xc4c4bf);
    paperGrid.position.y = -7.4;
    const pgm = paperGrid.material as THREE.Material; pgm.transparent = true; pgm.opacity = 0.2;
    paperGrid.visible = false;
    this.paperGrid = paperGrid;
    this.scene.add(paperGrid);
    const orbitPoints = Array.from({ length: 181 }, (_, i) => new THREE.Vector3(Math.cos(i / 180 * Math.PI * 2) * 18.5, -5.5, Math.sin(i / 180 * Math.PI * 2) * 14.8));
    const orbit = new THREE.Line(new THREE.BufferGeometry().setFromPoints(orbitPoints), new THREE.LineDashedMaterial({ color: 0x819b75, transparent: true, opacity: 0.24, dashSize: 0.3, gapSize: 0.2 })); orbit.computeLineDistances(); this.world.add(orbit);
    this.buildBrush(); this.world.add(this.brush);
    this.cable = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]), new THREE.LineBasicMaterial({ color: 0xc8f892 })); this.cable.visible = false; this.world.add(this.cable);
    this.buildMicro(); this.buildUniverse();
    this.transform = new TransformControls(this.camera, this.renderer.domElement);
    this.transform.attach(this.micro); this.transform.setSize(0.85); this.transform.setSpace("local");
    this.scene.add(this.transform.getHelper());
    this.transform.addEventListener("dragging-changed", event => { this.controls.enabled = !event.value && this.avatar.mode === "orbit"; });
    this.transform.addEventListener("mouseUp", () => {
      callbacks.onTransform({ materialPosition: this.micro.position.toArray().map(v => Math.max(-8, Math.min(8, Math.round(v * 100) / 100))) as Vec3,
        materialScale: Math.max(0.1, Math.min(3, Math.round(Math.max(this.micro.scale.x, this.micro.scale.y, this.micro.scale.z) * 100) / 100)),
        materialRotation: Math.round((THREE.MathUtils.radToDeg(this.micro.rotation.y) % 360 + 360) % 360),
      });
    });
    this.resizeObserver = new ResizeObserver(() => this.resize()); this.resizeObserver.observe(container);
    this.resize(); this.setSnapshot(snapshot); this.setOptions(options);
    const canvas = this.renderer.domElement;
    canvas.addEventListener("pointermove", this.pointerMove); canvas.addEventListener("pointerdown", this.pointerStart); canvas.addEventListener("pointerup", this.pointerEnd);
    canvas.addEventListener("pointerleave", this.pointerEnd); canvas.addEventListener("contextmenu", this.contextMenu);
    window.addEventListener("keydown", this.keyDown); window.addEventListener("keyup", this.keyUp);
    this.renderer.setAnimationLoop(this.animate);
  }

  /** PAPER MODE: white silhouettes, vibrant perspective racing lines, gold rivets, goblin-tagged metal. */
  private buildPaperOverlay() {
    if (this.paperBuilt) return;
    this.paperBuilt = true;
    const inkLine = () => new THREE.LineBasicMaterial({ color: PAPER_INK });
    const flat = (color: number) => new THREE.MeshBasicMaterial({ color });
    this.paperGroup.add(this.paperIsland);
    // Soft drop shadow so the floating cut-out separates from the white void
    const shadowGeo = new THREE.CircleGeometry(14.4, 56);
    shadowGeo.rotateX(-Math.PI / 2);
    const shadowCanvas = document.createElement("canvas");
    shadowCanvas.width = shadowCanvas.height = 128;
    const sctx = shadowCanvas.getContext("2d")!;
    const grad = sctx.createRadialGradient(64, 64, 8, 64, 64, 64);
    grad.addColorStop(0, "rgba(20,22,26,0.30)");
    grad.addColorStop(0.55, "rgba(20,22,26,0.16)");
    grad.addColorStop(1, "rgba(20,22,26,0)");
    sctx.fillStyle = grad;
    sctx.fillRect(0, 0, 128, 128);
    const shadowTex = new THREE.CanvasTexture(shadowCanvas);
    const shadow = new THREE.Mesh(shadowGeo, new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, depthWrite: false }));
    shadow.position.y = -6.6;
    shadow.scale.set(1, 1, 0.74);
    this.paperGroup.add(shadow);

    // Clean cut-outs: flat warm-white fill + a single thin charcoal contour line
    const edgeMat = new THREE.LineBasicMaterial({ color: PAPER_INK, transparent: true, opacity: 0.58 });
    const outlined = (geo: THREE.BufferGeometry, fill = 0xffffff, threshold = 24) => {
      const g = new THREE.Group();
      const mesh = new THREE.Mesh(geo, flat(fill));
      mesh.renderOrder = 1;
      g.add(mesh);
      g.add(new THREE.LineSegments(new THREE.EdgesGeometry(geo, threshold), edgeMat));
      return g;
    };

    // White slab island: a paper cut-out rimmed with a bold ink outline
    const islandGeo = new THREE.CylinderGeometry(13.6, 12.4, 1.5, 64);
    const islandCut = outlined(islandGeo, 0xfbfaf7, 30);
    islandCut.position.y = -1.35;
    this.paperIsland.add(islandCut);
    const wedgeGeo = new THREE.CylinderGeometry(12.2, 2.9, 3.4, 48, 1, true);
    const wedgeCut = outlined(wedgeGeo, 0xf2f0ea, 30);
    wedgeCut.position.y = -3.9;
    this.paperIsland.add(wedgeCut);

    // Terrain silhouette: gentle grass swells cut out of the white slab
    const swellGeo = new THREE.SphereGeometry(1, 28, 14, 0, Math.PI * 2, 0, Math.PI / 2);
    for (const [sx, sz, r] of [[-6.4, -3.4, 3.5], [6.2, -3.2, 4.1], [0.6, 2.6, 2.6], [-3.2, 5.2, 2.2]] as [number, number, number][]) {
      const swell = outlined(swellGeo, 0xfdfdfb, 42);
      swell.scale.set(r, r * 0.55, r * 0.74);
      swell.position.set(sx, -1.3, sz);
      this.paperIsland.add(swell);
    }

    // Cut-out prop silhouettes: trees, arch landmark, and creek ribbon
    const silhouette = (geo: THREE.BufferGeometry, x: number, y: number, z: number, s: number, ry = 0, fill = 0xffffff) => {
      const g = outlined(geo, fill, 26);
      g.position.set(x, y, z);
      g.scale.setScalar(s);
      g.rotation.y = ry;
      this.paperIsland.add(g);
    };
    const cone = new THREE.ConeGeometry(0.9, 2.1, 7);
    for (let i = 0; i < 15; i++) {
      const a = (i / 15) * Math.PI * 2 + 0.4;
      const rr = 5.4 + (i % 3) * 1.6;
      silhouette(cone, Math.cos(a) * rr * 1.16, 0.1 + (i % 3) * 0.34, Math.sin(a) * rr * 0.82, 0.62 + (i % 4) * 0.16, a, i % 3 === 0 ? 0xeef7e2 : 0xffffff);
    }
    const trunkGeo = new THREE.CylinderGeometry(0.1, 0.16, 1.4, 6);
    for (let i = 0; i < 15; i++) {
      const a = (i / 15) * Math.PI * 2 + 0.4;
      const rr = 5.4 + (i % 3) * 1.6;
      silhouette(trunkGeo, Math.cos(a) * rr * 1.16, -0.85, Math.sin(a) * rr * 0.82, 0.8);
    }
    const archShape = new THREE.Shape();
    archShape.moveTo(-1.7, 0); archShape.lineTo(-1.6, 1.5); archShape.lineTo(-0.6, 2.9); archShape.lineTo(0.7, 2.9); archShape.lineTo(1.7, 1.4); archShape.lineTo(1.6, 0); archShape.lineTo(0.75, 0); archShape.lineTo(0.7, 1.15); archShape.lineTo(-0.6, 1.15); archShape.lineTo(-0.72, 0); archShape.closePath();
    const archGeoPaper = new THREE.ExtrudeGeometry(archShape, { depth: 0.55, bevelEnabled: false });
    silhouette(archGeoPaper, 3.4, -1.2, -3.6, 1.0, -0.2);

    // Creek ribbon across the slab
    const creekPts: THREE.Vector3[] = [];
    for (let i = 0; i <= 22; i++) {
      const t = i / 22;
      creekPts.push(new THREE.Vector3(-3.6 + t * 1.6, -1.28, -8.4 + t * 17.2));
    }
    const creekCurve = new THREE.CatmullRomCurve3(creekPts);
    const creekGeo = new THREE.TubeGeometry(creekCurve, 48, 0.34, 6, false);
    this.paperIsland.add(new THREE.Mesh(creekGeo, flat(0xdff4fb)));
    this.paperIsland.add(new THREE.LineSegments(new THREE.EdgesGeometry(creekGeo, 40), new THREE.LineBasicMaterial({ color: PAPER_INK, transparent: true, opacity: 0.4 })));

    this.buildPbrShowcase();
    this.paperGroup.visible = false;
  }

  /**
   * The centrepiece: a rock / tree / bush vignette lit to show off real PBR.
   * Everything here uses generated albedo + normal + roughness + AO maps.
   */
  private buildPbrShowcase() {
    const group = new THREE.Group();
    group.name = "pbr-showcase";

    const granite = showcaseMaterial("granite", 11);
    const bark = showcaseMaterial("bark", 23);
    const foliage = showcaseMaterial("foliage", 37);
    const soil = showcaseMaterial("soil", 53);
    const r = seeded(918);

    // --- Plinth of damp forest soil ---
    const plinthGeo = new THREE.CylinderGeometry(5.2, 5.5, 0.55, 72);
    plinthGeo.setAttribute("uv2", plinthGeo.getAttribute("uv"));
    const plinth = new THREE.Mesh(plinthGeo, soil);
    plinth.position.y = -1.05;
    plinth.castShadow = true; plinth.receiveShadow = true;
    group.add(plinth);

    // --- Hero boulder: faceted granite, visibly rough and light-catching ---
    const rockGeo = new THREE.IcosahedronGeometry(2.05, 3);
    const rp = rockGeo.getAttribute("position") as THREE.BufferAttribute;
    for (let i = 0; i < rp.count; i++) {
      const v = new THREE.Vector3().fromBufferAttribute(rp, i);
      const n = Math.sin(v.x * 2.4) * Math.cos(v.y * 2.1) * Math.sin(v.z * 1.9);
      v.multiplyScalar(1 + n * 0.16 + (r() - 0.5) * 0.07);
      v.y *= 0.82;
      rp.setXYZ(i, v.x, v.y, v.z);
    }
    rockGeo.computeVertexNormals();
    rockGeo.setAttribute("uv2", rockGeo.getAttribute("uv"));
    const rock = new THREE.Mesh(rockGeo, granite);
    rock.position.set(-1.25, 0.25, -0.35);
    rock.rotation.set(0.12, 0.6, -0.08);
    rock.castShadow = true; rock.receiveShadow = true;
    group.add(rock);

    // Smaller companion stones
    for (let i = 0; i < 4; i++) {
      const g2 = new THREE.IcosahedronGeometry(0.34 + r() * 0.42, 1);
      g2.setAttribute("uv2", g2.getAttribute("uv"));
      const s2 = new THREE.Mesh(g2, granite);
      const a2 = r() * Math.PI * 2, d2 = 2.4 + r() * 1.9;
      s2.position.set(Math.cos(a2) * d2, -0.62 + r() * 0.12, Math.sin(a2) * d2);
      s2.rotation.set(r() * 3, r() * 3, r() * 3);
      s2.scale.y = 0.72;
      s2.castShadow = true; s2.receiveShadow = true;
      group.add(s2);
    }

    // --- Tree: fissured bark trunk with tapering limbs ---
    const tree = new THREE.Group();
    const trunkCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, -0.7, 0), new THREE.Vector3(0.1, 0.5, 0.08),
      new THREE.Vector3(-0.05, 1.7, -0.05), new THREE.Vector3(0.14, 2.9, 0.1),
    ]);
    const trunkGeo = new THREE.TubeGeometry(trunkCurve, 32, 0.34, 18, false);
    trunkGeo.setAttribute("uv2", trunkGeo.getAttribute("uv"));
    const trunk = new THREE.Mesh(trunkGeo, bark);
    trunk.castShadow = true; trunk.receiveShadow = true;
    tree.add(trunk);

    // Root flare
    for (let i = 0; i < 5; i++) {
      const a2 = (i / 5) * Math.PI * 2 + 0.4;
      const root = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.9, 7), bark);
      root.position.set(Math.cos(a2) * 0.3, -0.62, Math.sin(a2) * 0.3);
      root.rotation.set(Math.PI * 0.42, 0, -Math.atan2(Math.sin(a2), Math.cos(a2)) + Math.PI / 2);
      root.castShadow = true;
      tree.add(root);
    }
    // Limbs
    const limbs: THREE.Vector3[] = [];
    for (let i = 0; i < 5; i++) {
      const a2 = (i / 5) * Math.PI * 2 + 0.7;
      const h2 = 1.5 + i * 0.3;
      const tip = new THREE.Vector3(Math.cos(a2) * (0.9 + r() * 0.5), h2 + 0.75, Math.sin(a2) * (0.9 + r() * 0.5));
      const limbGeo = new THREE.TubeGeometry(
        new THREE.CatmullRomCurve3([new THREE.Vector3(0, h2, 0), new THREE.Vector3(tip.x * 0.5, h2 + 0.45, tip.z * 0.5), tip]),
        14, 0.1, 10, false,
      );
      limbGeo.setAttribute("uv2", limbGeo.getAttribute("uv"));
      const limb = new THREE.Mesh(limbGeo, bark);
      limb.castShadow = true;
      tree.add(limb);
      limbs.push(tip);
    }
    // Canopy clusters of waxy broadleaf
    for (const tip of limbs) {
      for (let c = 0; c < 3; c++) {
        const leafGeo = new THREE.IcosahedronGeometry(0.46 + r() * 0.26, 1);
        leafGeo.setAttribute("uv2", leafGeo.getAttribute("uv"));
        const cluster = new THREE.Mesh(leafGeo, foliage);
        cluster.position.set(tip.x + (r() - 0.5) * 0.6, tip.y + 0.12 + r() * 0.5, tip.z + (r() - 0.5) * 0.6);
        cluster.scale.set(1.25, 0.78, 1.25);
        cluster.castShadow = true; cluster.receiveShadow = true;
        tree.add(cluster);
      }
    }
    const crownGeo = new THREE.IcosahedronGeometry(1.15, 2);
    crownGeo.setAttribute("uv2", crownGeo.getAttribute("uv"));
    const crown = new THREE.Mesh(crownGeo, foliage);
    crown.position.set(0.1, 3.25, 0.05);
    crown.scale.set(1.3, 0.82, 1.3);
    crown.castShadow = true; crown.receiveShadow = true;
    tree.add(crown);
    tree.position.set(1.45, 0.1, 0.2);
    group.add(tree);

    // --- Bush: dense low foliage mass tucked against the rock ---
    const bush = new THREE.Group();
    for (let i = 0; i < 11; i++) {
      const bGeo = new THREE.IcosahedronGeometry(0.3 + r() * 0.32, 1);
      bGeo.setAttribute("uv2", bGeo.getAttribute("uv"));
      const blob = new THREE.Mesh(bGeo, foliage);
      const a2 = r() * Math.PI * 2, d2 = r() * 0.68;
      blob.position.set(Math.cos(a2) * d2, 0.1 + r() * 0.42, Math.sin(a2) * d2);
      blob.scale.set(1.2, 0.82, 1.2);
      blob.castShadow = true; blob.receiveShadow = true;
      bush.add(blob);
    }
    // A few bare twigs poking out
    for (let i = 0; i < 4; i++) {
      const twig = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.03, 0.7, 6), bark);
      const a2 = r() * Math.PI * 2;
      twig.position.set(Math.cos(a2) * 0.4, 0.28, Math.sin(a2) * 0.4);
      twig.rotation.set((r() - 0.5) * 0.8, 0, (r() - 0.5) * 0.8);
      bush.add(twig);
    }
    bush.position.set(-2.55, -0.62, 1.55);
    bush.scale.setScalar(1.08);
    group.add(bush);

    // --- Studio lighting rig: one key, one fill, one rim ---
    const key = new THREE.DirectionalLight(0xfff2dc, 2.9);
    key.position.set(-5.5, 8.5, 5.5);
    key.castShadow = true;
    key.shadow.mapSize.set(2048, 2048);
    Object.assign(key.shadow.camera, { left: -9, right: 9, top: 9, bottom: -9, near: 0.5, far: 30 });
    key.shadow.normalBias = 0.022;
    key.shadow.bias = -0.0004;
    group.add(key, key.target);

    const fill = new THREE.DirectionalLight(0xdfeaff, 0.85);
    fill.position.set(6, 3.2, 4.5);
    group.add(fill);

    const rim = new THREE.DirectionalLight(0xffffff, 1.5);
    rim.position.set(1.5, 4, -7.5);
    group.add(rim);

    group.add(new THREE.HemisphereLight(0xffffff, 0xb9b4a8, 0.75));

    // Contact shadow under the vignette
    const contact = new THREE.Mesh(
      new THREE.CircleGeometry(5.6, 48).rotateX(-Math.PI / 2),
      new THREE.MeshBasicMaterial({ color: 0x23231f, transparent: true, opacity: 0.1, depthWrite: false }),
    );
    contact.position.y = -1.31;
    group.add(contact);

    group.position.y = 0.2;
    this.paperGroup.add(group);
  }

  setTheme(theme: StudioTheme) {
    this.currentTheme = theme;
    const paper = theme === "paper";
    if (paper) this.buildPaperOverlay();
    this.paperGroup.visible = paper && this.options.depth < 4;
    this.world.visible = !paper && this.options.depth < 4;
    this.gridHelper.visible = !paper;
    if (this.paperGrid) this.paperGrid.visible = paper;
    // Reframe the camera so the paper cut-out fills the void
    if (this.options.depth < 4 && this.avatar.mode === "orbit") {
      if (paper) {
        const pull = 34 * Math.max(1, 0.95 / this.camera.aspect);
        this.depthTarget.set(pull * 0.5, pull * 0.42, pull * 0.8);
        this.lookTarget.set(0.6, 0.4, 0.4);
      } else {
        this.depthTarget.set(28, 24, 33).multiplyScalar(Math.max(1, 0.95 / this.camera.aspect));
        this.lookTarget.set(0, 0, 0);
      }
      this.camera.position.copy(this.depthTarget);
      this.controls.target.copy(this.lookTarget);
      this.transitioning = false;
    }
    this.renderer.shadowMap.enabled = !paper;
    this.renderer.toneMappingExposure = paper ? 1 : this.snapshot.settings.renderStyle === "cinematic" ? 1.5 : 1.18;
    this.renderer.shadowMap.needsUpdate = true;
  }

  private buildOceanPlanet() {
    const oceanGeo = new THREE.PlaneGeometry(260, 260, 44, 44);
    oceanGeo.rotateX(-Math.PI / 2);
    const oceanMat = new THREE.MeshPhysicalMaterial({
      color: 0x1e6b7b,
      emissive: 0x0b2e38,
      emissiveIntensity: 0.35,
      roughness: 0.22,
      metalness: 0.15,
      transparent: true,
      opacity: 0.88,
      flatShading: true,
    });
    this.oceanMesh = new THREE.Mesh(oceanGeo, oceanMat);
    this.oceanMesh.position.y = -1.35;
    this.oceanMesh.receiveShadow = true;
    this.oceanBasePositions = new Float32Array((oceanGeo.getAttribute("position") as THREE.BufferAttribute).array);
    const foamRing = new THREE.Mesh(
      new THREE.RingGeometry(14.2, 16.4, 64),
      new THREE.MeshBasicMaterial({ color: 0x9be7e2, side: THREE.DoubleSide, transparent: true, opacity: 0.42 }),
    );
    foamRing.rotation.x = -Math.PI / 2;
    foamRing.position.y = -1.28;
    // Finish banner & grandstand arches on the Water Race Planet
    const archGroup = new THREE.Group();
    const bannerPillarGeo = new THREE.CylinderGeometry(0.14, 0.18, 3.6, 8);
    const pillarMat = mat("#c6b37c", { metalness: 0.6, roughness: 0.35 });
    for (const side of [-1, 1]) {
      const pillar = new THREE.Mesh(bannerPillarGeo, pillarMat);
      pillar.position.set(side * 1.4, 1.8, -6.4);
      archGroup.add(pillar);
    }
    const crossbar = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.48, 0.18), mat("#c2ef8a", { emissive: "#436b24", emissiveIntensity: 0.35 }));
    crossbar.position.set(0, 3.3, -6.4);
    archGroup.add(crossbar);
    this.oceanGroup.add(this.oceanMesh, foamRing, archGroup);
    this.oceanGroup.visible = false;
  }

  private getStandings(): RacerStanding[] {
    if (!this.rail) return [];
    const sorted = [...this.riders].sort((a, b) => (b.laps * this.rail!.length + b.distance) - (a.laps * this.rail!.length + a.distance));
    return this.riders.map(r => ({
      id: r.id,
      name: r.name,
      color: r.color,
      odds: r.odds,
      laps: r.laps,
      distance: Math.round(r.distance * 10) / 10,
      attached: r.attached,
      rank: sorted.findIndex(s => s.id === r.id) + 1,
    }));
  }

  private emitAvatar() {
    this.onAvatar?.({
      spawned: this.avatar.spawned,
      mode: this.avatar.mode,
      position: [
        Math.round(this.avatar.position.x * 10) / 10,
        Math.round(this.avatar.position.y * 10) / 10,
        Math.round(this.avatar.position.z * 10) / 10,
      ],
      spectateRail: this.avatar.spectateRail,
      activeCells: this.spatialGrid.activeCellCount,
      cheering: this.avatar.cheerTimer > 0,
      wasted: this.avatar.wasted,
      chinHits: this.avatar.chinHits,
      lastChinHitBy: this.avatar.lastChinHitBy,
      standings: this.getStandings(),
      lapWinner: this.avatar.lapWinner,
    });
  }

  private syncAvatarHeadVisibility() {
    const firstPerson = this.avatar.mode === "first";
    this.avatarGroup.visible = this.avatar.spawned && !firstPerson;
  }

  spawnAvatar(mode: "third" | "first" = "third", targetPoint?: Vec3) {
    const x = targetPoint ? targetPoint[0] : 2.2;
    const z = targetPoint ? targetPoint[2] : 4.8;
    const y = sampleCarvedTerrainHeight(x, z, this.snapshot.strokes);
    this.avatar.spawned = true;
    this.avatar.wasted = false;
    this.avatar.wastedTimer = 0;
    this.avatar.position.set(x, y, z);
    this.avatar.velocity.set(0, 0, 0);
    this.avatar.grounded = true;
    this.avatar.yaw = Math.atan2(-1.0 - x, -2.0 - z);
    this.avatar.pitch = -0.06;
    this.avatarRig.rotation.set(0, 0, 0);
    this.avatarGroup.visible = mode !== "first";
    this.avatarGroup.position.copy(this.avatar.position);
    this.avatarGroup.rotation.y = this.avatar.yaw;
    this.setAvatarMode(mode);
  }

  respawnAvatar() {
    this.spawnAvatar(this.avatar.mode === "orbit" ? "third" : this.avatar.mode);
  }

  /** Places the spectator directly on the active rail ahead of the lead sphere to take it to the chin! */
  stepOntoTrack() {
    if (!this.rail || !this.riders.length) return;
    const lead = [...this.riders].sort((a, b) => (b.laps * this.rail!.length + b.distance) - (a.laps * this.rail!.length + a.distance))[0];
    const targetDist = (lead.distance + 2.1) % this.rail.length;
    const pt = this.rail.point(targetDist);
    this.spawnAvatar(this.avatar.mode === "first" ? "first" : "third", [pt.x, pt.y, pt.z]);
  }

  /** Spectator cheers! Raises arms, pulses cheer aura, and boosts nearby or favored racing spheres. */
  cheerAvatar(targetRiderId?: string) {
    if (!this.avatar.spawned) this.spawnAvatar("third");
    this.avatar.cheerTimer = 1.6;
    this.cheerAura.visible = true;
    if (this.avatar.grounded) {
      this.avatar.velocity.y = 3.6;
      this.avatar.grounded = false;
    }
    for (const rider of this.riders) {
      if (!targetRiderId || rider.id === targetRiderId || rider.mesh.position.distanceTo(this.avatar.position) < 9.5) {
        rider.boostTimer = 2.8;
      }
    }
    this.emitAvatar();
  }

  setAvatarMode(mode: AvatarCameraMode) {
    if (mode !== "orbit" && !this.avatar.spawned) {
      this.spawnAvatar(mode);
      return;
    }
    this.avatar.mode = mode;
    this.transitioning = false;
    this.syncAvatarHeadVisibility();
    if (mode === "orbit") {
      this.controls.enabled = true;
      this.controls.enableRotate = this.options.tool === "select" || this.options.tool === "move" || this.options.playing || this.options.depth >= 4;
      this.controls.enablePan = this.controls.enableRotate;
      const offset = new THREE.Vector3(12, 10, 14);
      this.depthTarget.copy(this.avatar.position).add(offset);
      this.lookTarget.copy(this.avatar.position);
      this.transitioning = true;
    } else {
      this.controls.enabled = false;
      this.brush.visible = false;
      this.updateAvatarCamera(1);
    }
    this.emitAvatar();
  }

  toggleSpectateRail(force?: boolean) {
    this.avatar.spectateRail = force !== undefined ? force : !this.avatar.spectateRail;
    this.emitAvatar();
  }

  moveAvatar(action: AvatarMoveAction, active: boolean) {
    const map: Record<AvatarMoveAction, string> = {
      forward: "w",
      backward: "s",
      left: "a",
      right: "d",
      jump: " ",
      sprint: "shift",
    };
    const key = map[action];
    if (action === "jump" && active) {
      if (this.avatar.spawned && this.avatar.grounded && !this.avatar.wasted) {
        this.avatar.velocity.y = 5.8;
        this.avatar.grounded = false;
        this.stepAvatar(0.08);
        this.updateAvatarCamera(0.16);
        this.emitAvatar();
      }
      return;
    }
    if (active) {
      this.virtualKeys.add(key);
      if (this.avatar.mode !== "orbit") {
        this.stepAvatar(0.12);
        this.updateAvatarCamera(0.16);
        this.emitAvatar();
      }
    } else {
      this.virtualKeys.delete(key);
    }
  }

  private hasKey(key: string) {
    return this.keys.has(key) || this.virtualKeys.has(key);
  }

  private resize() {
    const w = Math.max(1, this.container.clientWidth), h = Math.max(1, this.container.clientHeight);
    this.renderer.setSize(w, h); this.camera.aspect = w / h; this.camera.updateProjectionMatrix();
    if (this.firstResize) { this.camera.position.multiplyScalar(Math.max(1, 0.95 / this.camera.aspect)); this.depthTarget.copy(this.camera.position); this.firstResize = false; }
  }

  private buildBase(style: WorldStyle) {
    for (const group of [this.terrain, this.forest, this.water, this.railGroup]) { [...group.children].forEach(disposeObject); }
    this.trees = []; this.treeInstances = []; this.riders = []; this.authoringKey = ""; this.detailTrees = new THREE.Group(); this.forest.add(this.detailTrees);
    const palette = PALETTES[style], random = seeded(this.snapshot.seed);
    const positions: number[] = [], colors: number[] = [];
    const surfaceColor = (x: number, z: number) => {
      const { slope } = sampleTerrainSlope(x, z, this.snapshot.strokes);
      const blend = Math.min(1, THREE.MathUtils.smoothstep(x, 0.5, 5) * 0.75 + THREE.MathUtils.smoothstep(-z, 4, 8) * 0.15 + THREE.MathUtils.smoothstep(slope, 0.22, 0.55) * 0.65);
      const color = new THREE.Color(palette.grass[0]).lerp(new THREE.Color(palette.stone[1]), blend);
      color.multiplyScalar(0.97 + random() * 0.065);
      return color;
    };
    const triangle = (a: Vec3, b: Vec3, c: Vec3, color: THREE.Color) => { for (const p of [a, b, c]) { positions.push(...p); colors.push(color.r, color.g, color.b); } };
    for (let ix = 0; ix < 48; ix++) for (let iz = 0; iz < 36; iz++) {
      const x = -14 + ix * 28 / 48, z = -10 + iz * 20 / 36, dx = 28 / 48, dz = 20 / 36;
      if (((x + dx / 2) / 13.9) ** 2 + ((z + dz / 2) / 9.9) ** 2 > 1) continue;
      const a: Vec3 = [x, terrainHeight(x, z), z], b: Vec3 = [x + dx, terrainHeight(x + dx, z), z], c: Vec3 = [x, terrainHeight(x, z + dz), z + dz], d: Vec3 = [x + dx, terrainHeight(x + dx, z + dz), z + dz];
      const color = surfaceColor(x, z); triangle(a, c, b, color); triangle(b, c, d, color);
    }
    const geometry = new THREE.BufferGeometry(); geometry.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3)); geometry.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3)); geometry.computeVertexNormals();
    this.collider = new THREE.Mesh(geometry, mat(0xffffff, { vertexColors: true })); this.collider.receiveShadow = true; this.terrain.add(this.collider); this.colliderBase = new Float32Array(positions);
    const basePositions: number[] = [], baseColors: number[] = [];
    const rings = [1, 0.96, 0.69, 0.26];
    for (let ring = 0; ring < 3; ring++) for (let i = 0; i < 48; i++) {
      const a = i / 48 * Math.PI * 2, b = (i + 1) / 48 * Math.PI * 2;
      const point = (angle: number, r: number): Vec3 => { const radius = rings[r] * (1 + 0.03 * Math.sin(angle * 7)); const x = Math.cos(angle) * 13.8 * radius, z = Math.sin(angle) * 9.8 * radius; return [x, r === 0 ? terrainHeight(x, z) - 0.12 : [0, -2.1, -4.8, -6.2][r] + Math.sin(angle * 6) * 0.5, z]; };
      const col = new THREE.Color(palette.stone[Math.floor(random() * 4)]).multiplyScalar(ring === 0 ? 0.73 : 0.66);
      for (const p of [point(a, ring), point(b, ring), point(a, ring + 1), point(b, ring), point(b, ring + 1), point(a, ring + 1)]) { basePositions.push(...p); baseColors.push(col.r, col.g, col.b); }
    }
    const baseGeo = new THREE.BufferGeometry(); baseGeo.setAttribute("position", new THREE.Float32BufferAttribute(basePositions, 3)); baseGeo.setAttribute("color", new THREE.Float32BufferAttribute(baseColors, 3)); baseGeo.computeVertexNormals();
    const base = new THREE.Mesh(baseGeo, mat(0xffffff, { vertexColors: true })); base.castShadow = true; base.receiveShadow = true; this.terrain.add(base);
    const shape = new THREE.Shape(); shape.moveTo(-4.2, 0); shape.lineTo(-4.1, 3.8); shape.lineTo(-3.4, 6.2); shape.lineTo(-1.8, 7.5); shape.lineTo(0.1, 7.9); shape.lineTo(2.3, 7.1); shape.lineTo(3.8, 5.3); shape.lineTo(4, 0); shape.lineTo(2.1, 0); shape.lineTo(2, 3.4); shape.lineTo(1.4, 4.8); shape.lineTo(0, 5.2); shape.lineTo(-1.5, 4.6); shape.lineTo(-2.2, 3); shape.lineTo(-2.3, 0); shape.closePath();
    const archGeo = new THREE.ExtrudeGeometry(shape, { depth: 1.6, bevelEnabled: true, bevelSegments: 1, steps: 1, bevelSize: 0.24, bevelThickness: 0.18 });
    const archColors: number[] = [];
    const archPositions = archGeo.getAttribute("position");
    for (let i = 0; i < archPositions.count; i++) {
      const band = Math.floor((archPositions.getY(i) + 0.2) / 1.2);
      const color = new THREE.Color(palette.stone[2]).lerp(new THREE.Color(palette.stone[0]), band % 3 === 0 ? 0.38 : band % 3 === 1 ? 0.12 : 0.24);
      archColors.push(color.r, color.g, color.b);
    }
    archGeo.setAttribute("color", new THREE.Float32BufferAttribute(archColors, 3));
    const arch = new THREE.Mesh(archGeo, mat(0xffffff, { vertexColors: true })); arch.position.set(3.4, terrainHeight(3.4, -3.5), -3.5); arch.rotation.y = -0.2; arch.castShadow = true; arch.receiveShadow = true; this.terrain.add(arch);
    for (let i = 0; i < 26; i++) {
      const x = 5 + random() * 7, z = -7 + random() * 9;
      const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(1, 0), mat(palette.stone[i % 4]));
      rock.position.set(x, terrainHeight(x, z) + 0.15, z); rock.scale.set(0.5 + random() * 1.3, 0.4 + random() * 1.9, 0.6 + random()); rock.rotation.set(random(), random() * 3, random() * 0.4); rock.castShadow = true; rock.receiveShadow = true; this.terrain.add(rock);
    }
    const railAnchors = [[-10, 2], [-10, -3], [-6, -6], [0, -6.5], [7.8, -4.2], [10, 0.8], [7.5, 5.4], [0, 7], [-6.8, 5.5]].map(([x, z]) => new THREE.Vector3(x, terrainHeight(x, z) + 0.28, z));
    this.rail = new SlottedRailSystem(railAnchors); this.buildRail(this.rail, this.railGroup, true);
    const riverPoints = [[-0.5, -9], [-1.5, -5.5], [-0.2, -2], [-1.8, 1.2], [-3.4, 4], [-4.4, 7], [-5, 9]].map(([x, z]) => new THREE.Vector3(x, terrainHeight(x, z) + 0.04, z));
    const riverCurve = new THREE.CatmullRomCurve3(riverPoints); const river = ribbon(riverCurve, 1.05, palette.water); this.water.add(river);
    const waterfall = new THREE.Mesh(new THREE.PlaneGeometry(0.85, 6.7, 1, 12), mat(palette.water, { transparent: true, opacity: 0.75, side: THREE.DoubleSide, emissive: palette.water, emissiveIntensity: 0.12 })); waterfall.position.set(-5, -2.2, 9.06); waterfall.rotation.y = -0.2; this.water.add(waterfall);
    const riverSamples = Array.from({ length: 80 }, (_, i) => riverCurve.getPointAt(i / 79));
    const railSamples = Array.from({ length: 100 }, (_, i) => this.rail!.point(i / 100 * this.rail!.length));
    for (let i = 0; i < 350 && this.trees.length < 138; i++) {
      const x = -12 + random() * 17, z = -8 + random() * 15;
      if ((x / 13) ** 2 + (z / 9) ** 2 > 0.94 || x > 1.5 && z < -2 || Math.hypot(x - 2.2, z - 4.8) < 3.8 || railSamples.some(p => Math.hypot(p.x - x, p.z - z) < 1.1) || riverSamples.some(p => Math.hypot(p.x - x, p.z - z) < 0.9) || z > 4.2 && x > -0.5) continue;
      this.trees.push({ x, z, scale: 0.5 + random() * 0.7, rotation: random() * Math.PI });
    }
    const trunk = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.10, 0.15, 1.45, 5), mat(style === "lunar" ? "#6e6380" : "#685742"), this.trees.length); this.forest.add(trunk); this.treeInstances.push(trunk);
    for (let tier = 0; tier < 3; tier++) {
      const cones = new THREE.InstancedMesh(new THREE.ConeGeometry(0.82 - tier * 0.18, 1.65 - tier * 0.2, 6), mat(palette.leaf[tier]), this.trees.length); cones.castShadow = true; cones.receiveShadow = true; this.forest.add(cones); this.treeInstances.push(cones);
    }
    this.updateTrees();
    RACER_ROSTER.forEach((meta, i) => {
      const riderMesh = this.buildRider(meta.color);
      this.railGroup.add(riderMesh);
      const baseSpeed = [5.6, 5.1, 5.4][i];
      this.riders.push({
        id: meta.id,
        name: meta.name,
        color: meta.color,
        odds: meta.odds,
        mesh: riderMesh,
        distance: [0.68, 0.24, 0.45][i] * this.rail!.length,
        speed: baseSpeed,
        baseSpeed,
        boostTimer: 0,
        laps: 0,
        attached: true,
        velocity: new THREE.Vector3(),
        target: 0,
        chinCooldown: 0,
      });
    });
    this.physics(0);
    this.strokeKey = ""; this.railKey = ""; this.economyKey = "";
  }

  private updateTrees() {
    const dummy = new THREE.Object3D();
    this.trees.forEach((tree, index) => {
      const pushed = resolvePushedTreePosition(tree, this.snapshot.strokes);
      this.treeInstances.forEach((mesh, tier) => {
        dummy.position.set(pushed.x, pushed.y + (tier === 0 ? 0.7 : 1.5 + (tier - 1) * 0.67) * pushed.scale, pushed.z);
        dummy.rotation.set(0, tree.rotation, 0);
        dummy.scale.setScalar(pushed.scale);
        dummy.updateMatrix();
        mesh.setMatrixAt(index, dummy.matrix);
      });
    });
    this.treeInstances.forEach(mesh => { mesh.instanceMatrix.needsUpdate = true; mesh.computeBoundingSphere(); });
  }

  private buildRail(rail: SlottedRailSystem, group: THREE.Group, animated = false) {
    group.add(ribbon(rail.curve, 0.8, "#6a6d60"));
    const slot = ribbon(rail.curve, 0.13, "#252d29"); slot.position.y = 0.02; group.add(slot);
    const count = Math.floor(rail.length / 0.38), dummy = new THREE.Object3D();
    const plates = new THREE.InstancedMesh(new THREE.BoxGeometry(0.86, 0.08, 0.05), mat("#97967c", { metalness: 0.55, roughness: 0.5 }), count);
    const rivets = new THREE.InstancedMesh(new THREE.SphereGeometry(0.047, 6, 4), mat("#c2b693", { metalness: 0.6 }), count * 2);
    for (let i = 0; i < count; i++) {
      const d = i / count * rail.length, p = rail.point(d), t = rail.tangent(d), angle = Math.atan2(t.x, t.z);
      dummy.position.copy(p); dummy.position.y += 0.025; dummy.rotation.set(0, angle, 0); dummy.updateMatrix(); plates.setMatrixAt(i, dummy.matrix);
      for (let side = 0; side < 2; side++) { dummy.position.copy(p).add(new THREE.Vector3(t.z, 0, -t.x).multiplyScalar(side ? -0.33 : 0.33)); dummy.position.y += 0.08; dummy.updateMatrix(); rivets.setMatrixAt(i * 2 + side, dummy.matrix); }
    }
    plates.castShadow = true; plates.receiveShadow = true; group.add(plates, rivets);
    if (animated) {
      this.chain = new THREE.InstancedMesh(new THREE.BoxGeometry(0.085, 0.045, 0.13), mat("#d0bf91", { metalness: 0.8, roughness: 0.32 }), Math.floor(rail.length / 0.22)); group.add(this.chain);
    }
  }

  private buildRider(color: string) {
    const group = new THREE.Group();
    const sphere = new THREE.Mesh(new THREE.SphereGeometry(0.48, 18, 12), new THREE.MeshPhysicalMaterial({ color, metalness: 0.45, roughness: 0.25, transparent: true, opacity: 0.55 })); sphere.castShadow = true; group.add(sphere);
    for (let i = 0; i < 3; i++) { const hoop = new THREE.Mesh(new THREE.TorusGeometry(0.485, 0.028, 5, 32), mat("#aab3a0", { metalness: 0.7, roughness: 0.35 })); if (i === 1) hoop.rotation.x = Math.PI / 2; if (i === 2) hoop.rotation.y = Math.PI / 2; group.add(hoop); }
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.17, 8, 6), mat("#73934e")); head.position.y = 0.17; head.name = "legacy-pilot"; group.add(head);
    for (const side of [-1, 1]) { const ear = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.27, 4), mat("#7e9c58")); ear.position.set(side * 0.2, 0.2, 0); ear.rotation.z = side * -1.2; ear.name = "legacy-pilot"; group.add(ear); }
    return group;
  }

  private buildBrush() {
    const gel = new THREE.Mesh(new THREE.SphereGeometry(1, 32, 20), new THREE.MeshPhysicalMaterial({ color: 0xb8f58a, transparent: true, opacity: 0.20, roughness: 0.1, metalness: 0.05, side: THREE.DoubleSide, depthWrite: false })); this.brush.add(gel);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(1, 0.013, 6, 72), new THREE.MeshBasicMaterial({ color: 0xc1f899, transparent: true, opacity: 0.8 })); ring.rotation.x = Math.PI / 2; this.brush.add(ring);
    const wire = new THREE.LineSegments(new THREE.WireframeGeometry(new THREE.SphereGeometry(1.002, 12, 8)), new THREE.LineBasicMaterial({ color: 0xb6f491, transparent: true, opacity: 0.13 })); this.brush.add(wire);
    const preview = new THREE.Group();
    for (let i = 0; i < 5; i++) { const p = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.36, 5), new THREE.MeshBasicMaterial({ color: 0xc6ffa1, transparent: true, opacity: 0.55, wireframe: true })); const a = i * 2.399; p.position.set(Math.cos(a) * 0.5, 0.25 + (i % 2) * 0.13, Math.sin(a) * 0.5); preview.add(p); }
    this.brush.add(preview); this.brush.position.set(3.2, terrainHeight(3.2, 5.8) + 0.08, 5.8);
  }

  private buildMicro() {
    const random = seeded(102);
    for (let i = 0; i < 38; i++) {
      const theta = random() * Math.PI * 2, phi = Math.acos(random() * 2 - 1), radius = 3.9;
      const rock = new THREE.Mesh(new THREE.IcosahedronGeometry(0.95, 0), mat(PALETTES.verdant.stone[i % 4])); rock.position.set(Math.sin(phi) * Math.cos(theta) * radius, Math.cos(phi) * radius, Math.sin(phi) * Math.sin(theta) * radius); rock.rotation.set(random(), random(), random()); rock.castShadow = true; this.micro.add(rock);
    }
    const core = new THREE.Mesh(new THREE.IcosahedronGeometry(3.7, 2), mat("#b8a275")); core.castShadow = true; this.micro.add(core);
    const axes = new THREE.AxesHelper(7); axes.name = "gizmo"; this.micro.add(axes);
  }

  private buildUniverse() {
    const random = seeded(182), positions: number[] = [];
    for (let i = 0; i < 400; i++) { const a = random() * Math.PI * 2, r = 22 + random() * 45; positions.push(Math.cos(a) * r, (random() - 0.5) * 38, Math.sin(a) * r); }
    const geometry = new THREE.BufferGeometry(); geometry.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
    this.universe.add(new THREE.Points(geometry, new THREE.PointsMaterial({ color: 0xc6d8c6, size: 0.15, transparent: true, opacity: 0.55 })));
    for (let i = 0; i < 3; i++) {
      const planet = new THREE.Mesh(new THREE.IcosahedronGeometry(3.5 + i, 2), mat(["#b9af84", "#819f8a", "#9990ae"][i])); planet.position.set(Math.cos(i * 2.1) * (25 + i * 5), i * 2, Math.sin(i * 2.1) * (25 + i * 5)); this.universe.add(planet);
      const points = Array.from({ length: 101 }, (_, j) => new THREE.Vector3(Math.cos(j / 100 * Math.PI * 2) * (25 + i * 5), 0, Math.sin(j / 100 * Math.PI * 2) * (25 + i * 5)));
      this.universe.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(points), new THREE.LineBasicMaterial({ color: 0x6c8472, transparent: true, opacity: 0.25 })));
    }
  }

  private updateEconomyAndCrowd() {
    const econ = this.snapshot.economy;
    const scale = econ?.islandScale ?? 1.0;
    const isWater = Boolean(econ?.isWaterRacePlanet);
    const friends = econ?.joinedFriends ?? [];
    const key = `${scale.toFixed(2)}:${isWater}:${friends.join(",")}:${this.authoringKey}`;
    if (key === this.economyKey) return;
    this.economyKey = key;

    // Physically scale the island terrain & vegetation when expanded via Race Moneys or 1.5x Friend Co-Op!
    for (const grp of [this.terrain, this.forest, this.water, this.strokes]) {
      grp.scale.set(scale, 1 + (scale - 1) * 0.28, scale);
    }
    this.oceanGroup.visible = isWater;

    // Populate co-op friend goblins and trackside spectators
    [...this.crowdGroup.children].forEach(disposePresetObject);
    const state = this.snapshot.authoring;
    if (!state) return;
    const totalSpectators = (isWater ? 6 : 2) + Math.min(4, friends.length);
    const spots: [number, number][] = [
      [-5.2, -4.6], [0.8, -5.2], [6.4, -2.8], [5.8, 3.8], [-1.2, 5.6], [-7.4, 3.2], [-3.5, 1.8], [3.8, 1.9],
    ];
    for (let i = 0; i < totalSpectators && i < spots.length; i++) {
      const [sx, sz] = spots[i];
      const spec = createPresetObject(this.snapshot, state.bindings.goblin);
      spec.scale.setScalar(0.24);
      const sy = sampleCarvedTerrainHeight(sx, sz, this.snapshot.strokes);
      spec.position.set(sx, sy + 0.48, sz);
      spec.rotation.y = Math.atan2(-sx, -sz);
      spec.userData.spectatorIndex = i;
      spec.userData.baseY = sy + 0.48;
      this.crowdGroup.add(spec);
    }
  }

  private updateAuthoring() {
    const state = this.snapshot.authoring; if (!state) return;
    const key = JSON.stringify(state); if (key === this.authoringKey) return; this.authoringKey = key;
    const tree = state.presets[state.bindings.tree], leaf = childPreset(this.snapshot, tree.id, "leaf"), wood = childPreset(this.snapshot, tree.id, "wood");
    if (leaf && wood) {
      for (const [i, instance] of this.treeInstances.entries()) {
        const p = i === 0 ? wood : leaf, t = state.presets[p.textureId!]; if (!t?.texture) continue;
        const old = instance.material as THREE.MeshStandardMaterial; [old.map, old.normalMap, old.roughnessMap].forEach(texture => texture?.dispose()); old.dispose();
        instance.material = makePBRMaterial(t.texture, [...t.marks, ...p.marks.filter(m => m.target === "surface")], t.texture.normalSource ? state.presets[t.texture.normalSource]?.texture ?? null : null, 128);
      }
      [...this.detailTrees.children].forEach(disposePresetObject);
      const detail = createPresetObject(this.snapshot, tree.id); detail.scale.setScalar(0.4); detail.position.set(-6.2, terrainHeight(-6.2, 6.1) + 1.25, 6.1); this.detailTrees.add(detail);
    }
    for (const rider of this.riders) {
      [...rider.mesh.children].filter(c => c.name === "legacy-pilot" || c.name === "custom-pilot").forEach(disposePresetObject);
      const pilot = createPresetObject(this.snapshot, state.bindings.goblin); pilot.name = "custom-pilot"; pilot.scale.setScalar(0.105); pilot.position.y = 0.02; rider.mesh.add(pilot);
    }
    [...this.avatarRig.children].forEach(disposePresetObject);
    const body = createPresetObject(this.snapshot, state.bindings.goblin);
    body.name = "surface-goblin-body";
    body.scale.setScalar(0.28);
    body.position.y = 0.56;
    this.avatarRig.add(body);
    this.syncAvatarHeadVisibility();
  }

  setSnapshot(snapshot: WorldSnapshot) {
    this.snapshot = snapshot;
    const styleKey = snapshot.style + snapshot.seed;
    if (styleKey !== this.styleKey) { this.styleKey = styleKey; this.buildBase(snapshot.style); }
    const strokeKey = snapshot.strokes.map(s => s.id).join(",");
    if (strokeKey !== this.strokeKey) {
      this.strokeKey = strokeKey; [...this.strokes.children].forEach(disposeObject);
      const instances: Record<WorldStyle, { x: number; z: number; scale: number }[]> = { verdant: [], dunes: [], lunar: [] };
      let resident = 0;
      for (const stroke of snapshot.strokes.slice().reverse().filter(s => s.kind === "grow")) {
        const scale = stroke.scale ?? AutoSizeEngine.resolve(stroke.radius * 2, snapshot.settings.autoSize).scale;
        for (const [x, , z] of GelBrushSystem.samples(stroke)) {
          if (resident >= 1024 || (x / 14) ** 2 + (z / 10) ** 2 > 1 || snapshot.strokes.some(s => s.kind === "carve" && Math.hypot(s.position[0] - x, s.position[2] - z) < s.radius)) continue;
          instances[stroke.style].push({ x, z, scale }); resident++;
        }
      }
      const dummy = new THREE.Object3D();
      for (const style of ["verdant", "dunes", "lunar"] as WorldStyle[]) {
        const trees = instances[style]; if (!trees.length) continue;
        for (let tier = 0; tier < 3; tier++) {
          const mesh = new THREE.InstancedMesh(new THREE.ConeGeometry(0.7 - tier * 0.15, 1.4 - tier * 0.16, 6), mat(PALETTES[style].leaf[tier]), trees.length);
          trees.forEach((tree, i) => {
            const y = sampleCarvedTerrainHeight(tree.x, tree.z, snapshot.strokes);
            dummy.position.set(tree.x, y + (0.85 + tier * 0.6) * tree.scale, tree.z);
            dummy.scale.setScalar(tree.scale);
            dummy.updateMatrix();
            mesh.setMatrixAt(i, dummy.matrix);
          });
          mesh.castShadow = true; mesh.receiveShadow = true; mesh.computeBoundingSphere(); this.strokes.add(mesh);
        }
      }
      if (this.collider && this.colliderBase) {
        const attr = this.collider.geometry.getAttribute("position") as THREE.BufferAttribute;
        const colAttr = this.collider.geometry.getAttribute("color") as THREE.BufferAttribute;
        const palette = PALETTES[snapshot.style];
        for (let i = 0; i < attr.count; i++) {
          const x = this.colliderBase[i * 3], z = this.colliderBase[i * 3 + 2];
          const newY = sampleCarvedTerrainHeight(x, z, snapshot.strokes);
          attr.setY(i, newY);
          const { slope } = sampleTerrainSlope(x, z, snapshot.strokes);
          const blend = Math.min(1, THREE.MathUtils.smoothstep(x, 0.5, 5) * 0.75 + THREE.MathUtils.smoothstep(-z, 4, 8) * 0.15 + THREE.MathUtils.smoothstep(slope, 0.22, 0.52) * 0.75);
          const c = new THREE.Color(palette.grass[0]).lerp(new THREE.Color(palette.stone[1]), blend);
          colAttr.setXYZ(i, c.r, c.g, c.b);
        }
        attr.needsUpdate = true; colAttr.needsUpdate = true; this.collider.geometry.computeVertexNormals();
      }
      this.updateTrees();
      if (this.avatar.spawned && this.avatar.grounded && !this.avatar.wasted) {
        this.avatar.position.y = sampleCarvedTerrainHeight(this.avatar.position.x, this.avatar.position.z, snapshot.strokes);
        this.avatarGroup.position.copy(this.avatar.position);
      }
    }
    const railKey = JSON.stringify(snapshot.rails);
    if (railKey !== this.railKey) { this.railKey = railKey; [...this.customRails.children].forEach(disposeObject); if (snapshot.rails.length >= 2) this.buildRail(new SlottedRailSystem(snapshot.rails.map(p => new THREE.Vector3(...p)), false), this.customRails); }
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, snapshot.settings.quality === "performance" ? 1 : snapshot.settings.quality === "high" ? 2 : 1.6));
    this.renderer.toneMappingExposure = snapshot.settings.renderStyle === "cinematic" ? 1.5 : 1.18;
    this.world.traverse(o => { if (o instanceof THREE.Mesh) { const materials = Array.isArray(o.material) ? o.material : [o.material]; for (const m of materials) if (m instanceof THREE.MeshStandardMaterial && o !== this.brush.children[0]) m.wireframe = snapshot.settings.renderStyle === "wireframe"; } });
    this.updateAuthoring();
    this.updateEconomyAndCrowd();
    this.micro.scale.setScalar(snapshot.settings.materialScale); this.micro.rotation.y = snapshot.settings.materialRotation * Math.PI / 180;
    this.micro.position.set(...snapshot.settings.materialPosition);
    if (this.materialDetail !== snapshot.settings.materialDetail) {
      this.materialDetail = snapshot.settings.materialDetail;
      this.micro.children.forEach((object, index) => {
        if (!(object instanceof THREE.Mesh)) return;
        object.geometry.dispose();
        object.geometry = new THREE.IcosahedronGeometry(index === 38 ? 3.7 : 0.95, index === 38 ? this.materialDetail : Math.max(0, this.materialDetail - 1));
        object.visible = index === 38 || this.materialDetail > 0 || index < 20;
      });
    }
    this.micro.traverse(o => { if (o instanceof THREE.Mesh && o.material instanceof THREE.MeshStandardMaterial) o.material.roughness = snapshot.settings.roughness; });
    this.renderer.shadowMap.needsUpdate = true;
  }

  setOptions(options: SceneOptions) {
    const oldDepth = this.options.depth; this.options = options;
    if (this.currentTheme !== options.theme) this.setTheme(options.theme);
    const embodied = this.avatar.mode !== "orbit";
    this.controls.enabled = !embodied;
    this.controls.enableRotate = !embodied && (options.tool === "select" || options.tool === "move" || options.playing || options.depth >= 4);
    this.controls.enablePan = this.controls.enableRotate;
    this.renderer.domElement.style.cursor = embodied ? "grab" : options.tool === "select" || options.tool === "move" ? "grab" : "crosshair";
    const paperMode = this.paperGroup.visible || (options.theme === "paper" && this.paperBuilt);
    this.terrain.visible = options.layers.terrain !== false; this.forest.visible = options.layers.forest !== false; this.water.visible = options.layers.water !== false; this.railGroup.visible = options.layers.rail !== false;
    this.brush.visible = !embodied && !paperMode && ["brush", "erase"].includes(options.tool) && !options.playing && options.depth < 4;
    this.world.visible = options.depth < 4 && !paperMode;
    this.paperGroup.visible = options.depth < 4 && paperMode;
    this.micro.visible = options.depth >= 4; this.universe.visible = options.depth === 0 && !paperMode;
    const gizmo = this.micro.getObjectByName("gizmo"); if (gizmo) gizmo.visible = false; this.transform.enabled = options.pro && options.depth >= 4; this.transform.getHelper().visible = this.transform.enabled;
    if (oldDepth !== options.depth && !embodied) {
      const positions = [[65, 58, 76], [31, 27, 38], [28, 24, 33], [17, 15, 20], [10, 8, 12], [9, 6, 11]];
      this.depthTarget.set(...positions[Math.min(5, options.depth)] as [number, number, number])
        .multiplyScalar((this.paperGroup.visible ? 0.62 : 1) * Math.max(1, 0.95 / this.camera.aspect));
      this.lookTarget.set(options.depth === 3 ? -4 : 0, options.depth === 3 ? 1 : 0, options.depth === 3 ? 1 : 0); this.transitioning = true;
    }
    if (!options.playing && !embodied) this.cable.visible = false;
  }

  winch(active: boolean) { if (active) this.keys.add("w"); else this.keys.delete("w"); }
  setManipulator(mode: "translate" | "rotate" | "scale") { this.transform.setMode(mode); }
  zoom(direction: number) {
    if (this.avatar.mode !== "orbit") {
      this.setAvatarMode(direction > 0 ? "first" : "third");
      return;
    }
    const offset = this.camera.position.clone().sub(this.controls.target).multiplyScalar(direction > 0 ? 0.82 : 1.22);
    this.camera.position.copy(this.controls.target).add(offset);
    this.controls.update();
  }
  resetCamera() {
    if (this.avatar.mode !== "orbit") this.setAvatarMode("orbit");
    if (this.paperGroup.visible) {
      const pull = 34 * Math.max(1, 0.95 / this.camera.aspect);
      this.depthTarget.set(pull * 0.5, pull * 0.42, pull * 0.8);
      this.lookTarget.set(0.6, 0.4, 0.4);
    } else {
      this.depthTarget.set(28, 24, 33).multiplyScalar(Math.max(1, 0.95 / this.camera.aspect));
      this.lookTarget.set(0, 0, 0);
    }
    this.transitioning = true;
  }
  cameraView(view: string) {
    if (view === "first" || view === "third") {
      this.setAvatarMode(view);
      return;
    }
    if (this.avatar.mode !== "orbit") this.setAvatarMode("orbit");
    this.depthTarget.set(...(view === "top" ? [0.01, 48, 0] : view === "front" ? [0, 9, 44] : [28, 24, 33]) as [number, number, number]);
    this.lookTarget.set(0, 0, 0);
    this.transitioning = true;
  }
  bump() {
    if (!this.rail || !this.riders.length) return;
    const rider = this.riders[0]; rider.attached = false; rider.target = rider.distance;
    rider.velocity.copy(this.rail.tangent(rider.distance)).multiplyScalar(4).add(new THREE.Vector3(3, 7, 3));
    this.spawnDebris(rider.mesh.position, "#b7a078", 12);
  }

  private spawnDebris(origin: THREE.Vector3, color: string, count = 12) {
    this.chunkLife = 3.2;
    [...this.chunks.children].forEach(disposeObject);
    for (let i = 0; i < count; i++) {
      const chunk = new THREE.Mesh(new THREE.DodecahedronGeometry(0.14 + Math.random() * 0.14), mat(color));
      chunk.position.copy(origin);
      chunk.userData.velocity = new THREE.Vector3((Math.random() - 0.5) * 8, 2.5 + Math.random() * 6.5, (Math.random() - 0.5) * 8);
      this.chunks.add(chunk);
    }
  }

  private pointerMove = (event: PointerEvent) => {
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.pointer.set((event.clientX - rect.left) / rect.width * 2 - 1, -(event.clientY - rect.top) / rect.height * 2 + 1);
    if (this.avatar.mode !== "orbit") {
      if (this.pointerDown) {
        const dx = event.clientX - this.lastPointerX;
        const dy = event.clientY - this.lastPointerY;
        this.lastPointerX = event.clientX;
        this.lastPointerY = event.clientY;
        this.avatar.yaw -= dx * 0.0065;
        this.avatar.pitch = Math.max(-1.05, Math.min(1.05, this.avatar.pitch - dy * 0.0055));
      }
      return;
    }
    this.raycaster.setFromCamera(this.pointer, this.camera);
    if (this.collider && this.options.depth < 4) {
      const hit = this.raycaster.intersectObject(this.collider)[0];
      if (hit) { this.brush.position.copy(hit.point); if (this.pointerDown) this.paint(); }
    }
  };

  private pointerStart = (event: PointerEvent) => {
    this.lastPointerX = event.clientX;
    this.lastPointerY = event.clientY;
    if (this.avatar.mode !== "orbit") {
      this.pointerDown = true;
      this.pointerButton = event.button;
      return;
    }
    if (event.button === 1 || event.altKey || this.options.playing) return;
    this.pointerMove(event);
    this.pointerDown = true;
    this.pointerButton = event.button;
    this.lastPaintPoint.set(Infinity, Infinity, Infinity);
    this.paint();
  };

  private pointerEnd = () => { this.pointerDown = false; };
  private contextMenu = (event: Event) => { if (this.avatar.mode !== "orbit" || this.paperGroup.visible || ["brush", "erase", "rail"].includes(this.options.tool)) event.preventDefault(); };
  private keyDown = (event: KeyboardEvent) => {
    if (isTypingTarget(event.target)) return;
    const key = event.key.toLowerCase();
    this.keys.add(key);
    if (event.code === "Space") {
      if (this.avatar.mode !== "orbit" || this.options.playing) event.preventDefault();
      if (this.avatar.mode !== "orbit" && this.avatar.grounded && !this.avatar.wasted) {
        this.avatar.velocity.y = 5.8;
        this.avatar.grounded = false;
      }
      if (this.options.playing && !event.repeat) this.bump();
    }
    if (key === "f" && !event.repeat && this.avatar.spawned) {
      this.cheerAvatar();
      return;
    }
    if (key === "c" && !event.repeat && this.avatar.spawned) {
      this.setAvatarMode(this.avatar.mode === "first" ? "third" : "first");
      return;
    }
    if (this.avatar.mode !== "orbit" && ["w", "a", "s", "d", "arrowup", "arrowdown", "arrowleft", "arrowright"].includes(key)) {
      this.stepAvatar(0.12);
      this.updateAvatarCamera(0.16);
      this.emitAvatar();
    }
  };
  private keyUp = (event: KeyboardEvent) => { this.keys.delete(event.key.toLowerCase()); };

  private paint() {
    if (this.options.depth >= 4 || this.avatar.mode !== "orbit" || performance.now() - this.lastStroke < 100) return;
    const p = this.brush.position;
    if (p.distanceTo(this.lastPaintPoint) < this.snapshot.settings.radius * 0.32) return;
    if (this.options.tool === "rail") { if (this.snapshot.rails.length < 64) this.onRail([p.x, p.y + 0.27, p.z]); }
    else if (["brush", "erase"].includes(this.options.tool) && this.snapshot.strokes.length < 600) this.onStroke(GelBrushSystem.stroke([p.x, p.y, p.z], this.snapshot.settings, this.snapshot.style, this.options.tool === "erase" || this.pointerButton === 2));
    else return;
    this.lastStroke = performance.now(); this.lastPaintPoint.copy(p);
  }

  private currentRule() {
    const id = this.snapshot.economy?.majorityRule ?? "standard";
    return MAJORITY_RULES.find(r => r.id === id) ?? MAJORITY_RULES[0];
  }

  private stepAvatar(dt: number) {
    if (!this.avatar.spawned) return;
    const rule = this.currentRule();
    const islandScale = this.snapshot.economy?.islandScale ?? 1.0;

    if (this.avatar.cheerTimer > 0) {
      this.avatar.cheerTimer = Math.max(0, this.avatar.cheerTimer - dt);
      this.cheerAura.visible = this.avatar.cheerTimer > 0 && this.avatar.mode !== "first";
      this.cheerAura.scale.setScalar(1 + (1.6 - this.avatar.cheerTimer) * 0.8);
    }

    if (this.avatar.wasted) {
      this.avatar.wastedTimer -= dt;
      this.avatar.position.addScaledVector(this.avatar.velocity, dt);
      this.avatar.velocity.y -= dt * 13.5 * rule.gravityScale;
      const groundY = sampleCarvedTerrainHeight(this.avatar.position.x, this.avatar.position.z, this.snapshot.strokes);
      if (this.avatar.position.y <= groundY) {
        this.avatar.position.y = groundY;
        this.avatar.velocity.x *= 0.82;
        this.avatar.velocity.z *= 0.82;
        this.avatar.velocity.y = 0;
      }
      this.avatarGroup.position.copy(this.avatar.position);
      this.avatarRig.rotation.x = Math.min(Math.PI / 2, this.avatarRig.rotation.x + dt * 6);
      this.avatarRig.rotation.z = Math.sin(this.elapsed * 10) * 0.4;
      if (this.avatar.wastedTimer <= 0) {
        this.avatar.wasted = false;
        this.avatarRig.rotation.set(0, 0, 0);
        this.emitAvatar();
      }
      return;
    }

    const embodied = this.avatar.mode !== "orbit";
    let moveForward = 0;
    let moveStrafe = 0;
    if (embodied) {
      if (this.hasKey("w") || this.hasKey("arrowup")) moveForward += 1;
      if (this.hasKey("s") || this.hasKey("arrowdown")) moveForward -= 1;
      if (this.hasKey("d")) moveStrafe -= 1;
      if (this.hasKey("a")) moveStrafe += 1;
      if (this.hasKey("arrowleft") || this.hasKey("q")) this.avatar.yaw += dt * 2.2;
      if (this.hasKey("arrowright") || this.hasKey("e")) this.avatar.yaw -= dt * 2.2;
    }
    const speed = (this.hasKey("shift") ? 6.4 : 4.1);
    const fx = Math.sin(this.avatar.yaw), fz = Math.cos(this.avatar.yaw);
    const rx = Math.cos(this.avatar.yaw), rz = -Math.sin(this.avatar.yaw);
    let vx = fx * moveForward + rx * moveStrafe;
    let vz = fz * moveForward + rz * moveStrafe;
    const vLen = Math.hypot(vx, vz);
    if (vLen > 1e-4) {
      vx = (vx / vLen) * speed;
      vz = (vz / vLen) * speed;
      this.avatar.walkTime += dt * (this.hasKey("shift") ? 13 : 9);
    }
    const nextX = this.avatar.position.x + vx * dt;
    const nextZ = this.avatar.position.z + vz * dt;
    const maxR_X = 13.0 * islandScale;
    const maxR_Z = 9.1 * islandScale;
    const radial = (nextX / maxR_X) ** 2 + (nextZ / maxR_Z) ** 2;
    if (radial <= 1) {
      this.avatar.position.x = nextX;
      this.avatar.position.z = nextZ;
    } else {
      const clampScale = 1 / Math.sqrt(radial);
      this.avatar.position.x = nextX * clampScale * 0.99;
      this.avatar.position.z = nextZ * clampScale * 0.99;
    }
    const groundY = sampleCarvedTerrainHeight(this.avatar.position.x / islandScale, this.avatar.position.z / islandScale, this.snapshot.strokes);
    this.avatar.velocity.y -= dt * 15.0 * rule.gravityScale;
    this.avatar.position.y += this.avatar.velocity.y * dt;
    if (this.avatar.position.y <= groundY) {
      this.avatar.position.y = groundY;
      this.avatar.velocity.y = 0;
      this.avatar.grounded = true;
    }
    this.avatarGroup.position.copy(this.avatar.position);
    this.avatarGroup.rotation.y = this.avatar.yaw;

    const swing = vLen > 1e-4 ? Math.sin(this.avatar.walkTime) * 0.45 : 0;
    const bob = vLen > 1e-4 && this.avatar.grounded ? Math.abs(Math.cos(this.avatar.walkTime)) * 0.055 : 0;
    const body = this.avatarRig.getObjectByName("surface-goblin-body");
    if (body) {
      body.position.y = 0.56 + bob;
      const legs = body.getObjectByName("goblin-legs");
      const arms = body.getObjectByName("goblin-arms");
      if (legs) legs.rotation.x = swing;
      if (arms) {
        arms.rotation.x = this.avatar.cheerTimer > 0 ? -2.45 + Math.sin(this.elapsed * 16) * 0.35 : -swing * 0.75;
      }
    }
    if (vLen > 1e-4 || !this.avatar.grounded) {
      this.avatarEmitTime += dt;
      if (this.avatarEmitTime >= 0.1) {
        this.avatarEmitTime = 0;
        this.emitAvatar();
      }
    }
  }

  private updateAvatarCamera(dt: number) {
    if (!this.avatar.spawned || this.avatar.mode === "orbit") return;
    const pos = this.avatar.position;
    const fx = Math.sin(this.avatar.yaw), fz = Math.cos(this.avatar.yaw);
    const riderPos = this.riders[0]?.mesh.position;
    if (this.avatar.mode === "first") {
      const eye = new THREE.Vector3(pos.x + fx * 0.14, pos.y + (this.avatar.wasted ? 0.35 : 0.92), pos.z + fz * 0.14);
      const lookDir = new THREE.Vector3(
        fx * Math.cos(this.avatar.pitch),
        Math.sin(this.avatar.pitch),
        fz * Math.cos(this.avatar.pitch),
      );
      const target = this.avatar.spectateRail && riderPos
        ? riderPos.clone()
        : eye.clone().addScaledVector(lookDir, 8);
      this.camera.position.copy(eye);
      this.controls.target.copy(target);
      this.camera.lookAt(target);
    } else if (this.avatar.mode === "third") {
      const focus = new THREE.Vector3(pos.x, pos.y + 0.78, pos.z);
      if (this.avatar.spectateRail && riderPos) {
        focus.lerp(riderPos, 0.38);
      } else {
        focus.add(new THREE.Vector3(fx * 1.2, Math.sin(this.avatar.pitch) * 1.1, fz * 1.2));
      }
      const dist = 3.6;
      const camX = pos.x - fx * dist * Math.cos(this.avatar.pitch * 0.4);
      const camZ = pos.z - fz * dist * Math.cos(this.avatar.pitch * 0.4);
      const minGround = sampleCarvedTerrainHeight(camX, camZ, this.snapshot.strokes) + 0.48;
      const camY = Math.max(minGround, pos.y + 1.55 - Math.sin(this.avatar.pitch) * 1.35);
      const desired = new THREE.Vector3(camX, camY, camZ);
      this.camera.position.lerp(desired, Math.min(1, dt * 12));
      this.controls.target.lerp(focus, Math.min(1, dt * 14));
      this.camera.lookAt(this.controls.target);
    }
  }

  private triggerChinHit(rider: Rider) {
    if (!this.rail) return;
    const rule = this.currentRule();
    const chinForce = rule.id === "chin_check" ? 1.75 : 1.0;
    this.avatar.wasted = true;
    this.avatar.wastedTimer = 3.0;
    this.avatar.chinHits += 1;
    this.avatar.lastChinHitBy = rider.name;

    const tangent = this.rail.tangent(rider.distance);
    this.avatar.velocity.copy(tangent).multiplyScalar(5.5 * chinForce).add(new THREE.Vector3((Math.random() - 0.5) * 3, 5.8, (Math.random() - 0.5) * 3));

    // The spectator's chin physically derails and deflects the racing ball!
    rider.attached = false;
    rider.target = rider.distance;
    rider.chinCooldown = 2.2;
    rider.velocity.copy(tangent).multiplyScalar(-2.4 * chinForce).add(new THREE.Vector3(-tangent.z * 4.5 * chinForce, 5.2, tangent.x * 4.5 * chinForce));

    this.spawnDebris(this.avatar.position.clone().add(new THREE.Vector3(0, 0.7, 0)), "#c2ef8a", 14);
    this.onChinHit?.(rider.id, rider.name, this.avatar.chinHits);
    this.emitAvatar();
  }

  private physics(dt: number) {
    if (!this.rail) return;
    const rule = this.currentRule();
    this.stepAvatar(dt);
    const activeSim = this.options.playing || this.avatar.mode !== "orbit" || Boolean(this.snapshot.economy?.isWaterRacePlanet);
    this.spatialGrid.clear();
    if (this.avatar.spawned) {
      this.spatialGrid.insert({
        id: "avatar",
        kind: "avatar",
        position: [this.avatar.position.x, this.avatar.position.y + 0.5, this.avatar.position.z],
        radius: 0.48,
      });
    }
    for (const [i, rider] of this.riders.entries()) {
      if (rider.chinCooldown > 0) rider.chinCooldown = Math.max(0, rider.chinCooldown - dt);
      if (rider.boostTimer > 0) rider.boostTimer = Math.max(0, rider.boostTimer - dt);

      if (rider.attached) {
        const boostMult = (i === 0 && this.hasKey("shift") && this.avatar.mode === "orbit" ? 1.65 : 1) * (rider.boostTimer > 0 ? 1.42 : 1) * rule.speedScale;
        if (activeSim) {
          const nextDist = rider.distance + dt * rider.speed * boostMult;
          if (nextDist >= this.rail.length) {
            rider.laps += 1;
            rider.distance = nextDist % this.rail.length;
            if (rider.laps > 0 && rider.laps % 2 === 0) {
              this.avatar.lapWinner = rider.name;
              this.onRaceFinish?.(rider.id, rider.name, this.getStandings());
            }
          } else {
            rider.distance = nextDist;
          }
        }
        rider.mesh.position.copy(this.rail.point(rider.distance)); rider.mesh.position.y += 0.55;
        rider.mesh.rotation.z -= dt * rider.speed / 0.48;
      } else {
        rider.velocity.y -= dt * 9.8 * rule.gravityScale;
        const winching = (this.hasKey("w") && this.avatar.mode === "orbit") || rider.chinCooldown < 1.1;
        if (winching) {
          const anchor = this.rail.point(rider.target).add(new THREE.Vector3(0, 0.55, 0));
          rider.velocity.addScaledVector(this.rail.winchForce(rider.mesh.position, rider.velocity, anchor), dt);
          if (i === 0) {
            this.cable.visible = true;
            const attr = this.cable.geometry.getAttribute("position") as THREE.BufferAttribute;
            attr.setXYZ(0, ...rider.mesh.position.toArray() as Vec3);
            attr.setXYZ(1, ...anchor.toArray() as Vec3);
            attr.needsUpdate = true;
          }
          if (rider.mesh.position.distanceTo(anchor) < 0.42) {
            rider.attached = true;
            rider.distance = rider.target;
            if (i === 0) this.cable.visible = false;
          }
        } else if (i === 0) this.cable.visible = false;
        rider.mesh.position.addScaledVector(rider.velocity, dt);
        if (rider.mesh.position.y < -35) { rider.mesh.position.copy(this.rail.point(rider.target)); rider.velocity.set(0, 0, 0); rider.attached = true; rider.distance = rider.target; }
      }

      // Check Spectator Chin-Check collision ("take it to the chin & affect the balls")
      if (this.avatar.spawned && !this.avatar.wasted && rider.chinCooldown <= 0) {
        const chinPos = new THREE.Vector3(this.avatar.position.x, this.avatar.position.y + 0.62, this.avatar.position.z);
        if (rider.mesh.position.distanceTo(chinPos) < 1.18) {
          this.triggerChinHit(rider);
        }
      }

      this.spatialGrid.insert({
        id: `rider-${i}`,
        kind: "rider",
        position: rider.mesh.position.toArray() as Vec3,
        radius: 0.48,
      });
    }
    if (activeSim) {
      for (let i = 0; i < this.riders.length; i++) for (let j = i + 1; j < this.riders.length; j++) {
        const a = this.riders[i], b = this.riders[j];
        if (a.attached && b.attached && a.mesh.position.distanceTo(b.mesh.position) < 0.94) {
          const victim = b; victim.attached = false; victim.target = victim.distance;
          victim.velocity.copy(this.rail.tangent(victim.distance)).multiplyScalar(3).add(new THREE.Vector3(2, 5, 2));
        }
      }
    }
    if (this.chunkLife > 0) {
      this.chunkLife -= dt;
      this.chunks.children.forEach((chunk, idx) => {
        const v = chunk.userData.velocity as THREE.Vector3;
        v.y -= dt * 9.8 * rule.gravityScale;
        chunk.position.addScaledVector(v, dt);
        chunk.rotation.x += dt * 2;
        chunk.rotation.y += dt;
        this.spatialGrid.insert({ id: `chunk-${idx}`, kind: "chunk", position: chunk.position.toArray() as Vec3, radius: 0.18 });
      });
      if (this.chunkLife <= 0) [...this.chunks.children].forEach(disposeObject);
    }
  }

  private animate = (time: number) => {
    if (this.destroyed) return;
    const dt = Math.min(0.05, this.lastTime ? (time - this.lastTime) / 1000 : 0.016); this.lastTime = time;
    if (document.hidden) { this.accumulator = 0; return; }
    this.elapsed += dt; this.accumulator += dt;
    let steps = 0; while (this.accumulator >= 1 / 120 && steps++ < 6) { this.physics(1 / 120); this.accumulator -= 1 / 120; }
    this.brush.scale.setScalar(this.snapshot.settings.radius); this.brush.rotation.y = Math.sin(this.elapsed * 0.3) * 0.08;
    const preview = this.brush.children[3]; if (preview) { preview.rotation.y = this.elapsed * 0.15; preview.position.y = Math.sin(this.elapsed * 1.8) * 0.04; }
    if (this.chain && this.rail) { const dummy = new THREE.Object3D(); for (let i = 0; i < this.chain.count; i++) { const d = i / this.chain.count * this.rail.length + this.elapsed * 0.8, p = this.rail.point(d), t = this.rail.tangent(d); dummy.position.copy(p); dummy.position.y += 0.045; dummy.rotation.y = Math.atan2(t.x, t.z); dummy.updateMatrix(); this.chain.setMatrixAt(i, dummy.matrix); } this.chain.instanceMatrix.needsUpdate = true; }
    if (this.oceanGroup.visible && this.oceanMesh && this.oceanBasePositions) {
      const posAttr = this.oceanMesh.geometry.getAttribute("position") as THREE.BufferAttribute;
      for (let i = 0; i < posAttr.count; i++) {
        const ox = this.oceanBasePositions[i * 3], oz = this.oceanBasePositions[i * 3 + 2];
        posAttr.setY(i, Math.sin(ox * 0.18 + this.elapsed * 2.1) * 0.28 + Math.cos(oz * 0.22 + this.elapsed * 1.7) * 0.22);
      }
      posAttr.needsUpdate = true;
    }
    this.crowdGroup.children.forEach((spec, i) => {
      const hop = Math.abs(Math.sin(this.elapsed * 4.5 + i * 1.3)) * 0.14;
      spec.position.y = (spec.userData.baseY ?? 1.2) + hop;
    });
    if (this.paperGroup.visible) {
      this.riders.forEach((rider, i) => {
        const paperSphere = this.paperSpheres[i];
        if (!paperSphere) return;
        paperSphere.position.copy(rider.mesh.position);
        paperSphere.position.y -= 0.06;
        paperSphere.rotation.z = rider.mesh.rotation.z;
      });
      this.paperIsland.rotation.y = 0;
    }
    if (this.avatar.mode !== "orbit") {
      this.updateAvatarCamera(dt);
    } else {
      if (this.transitioning) { this.camera.position.lerp(this.depthTarget, 0.07); this.controls.target.lerp(this.lookTarget, 0.07); if (this.camera.position.distanceTo(this.depthTarget) < 0.06) this.transitioning = false; }
      this.controls.update(dt);
    }
    this.renderer.render(this.scene, this.camera); this.frames++; this.metricsTime += dt;
    if (this.metricsTime > 1.2) {
      this.onMetrics({
        fps: Math.round(this.frames / this.metricsTime),
        triangles: this.renderer.info.render.triangles,
        calls: this.renderer.info.render.calls,
        objects: this.renderer.info.memory.geometries,
        activeCells: this.spatialGrid.activeCellCount,
      });
      if (this.avatar.spawned || this.options.playing || this.snapshot.economy?.isWaterRacePlanet) this.emitAvatar();
      if (this.snapshot.settings.quality === "auto" && this.frames / this.metricsTime < 28) this.renderer.setPixelRatio(Math.max(0.75, this.renderer.getPixelRatio() * 0.85));
      this.frames = 0; this.metricsTime = 0;
    }
  };

  dispose() {
    this.destroyed = true; this.renderer.setAnimationLoop(null); this.resizeObserver.disconnect(); this.controls.dispose(); this.transform.dispose();
    const canvas = this.renderer.domElement; canvas.removeEventListener("pointermove", this.pointerMove); canvas.removeEventListener("pointerdown", this.pointerStart); canvas.removeEventListener("pointerup", this.pointerEnd); canvas.removeEventListener("pointerleave", this.pointerEnd); canvas.removeEventListener("contextmenu", this.contextMenu); window.removeEventListener("keydown", this.keyDown); window.removeEventListener("keyup", this.keyUp);
    disposeObject(this.scene); this.renderer.dispose(); canvas.remove();
  }
}
