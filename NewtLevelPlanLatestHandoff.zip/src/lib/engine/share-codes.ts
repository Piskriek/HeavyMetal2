import { deflateSync, inflateSync, strToU8, strFromU8 } from "fflate";
import type { PresetPackage } from "./authoring";

/**
 * Compact, shareable preset codes.
 * A package is key-shortened, deflated, then base64url encoded so a whole
 * dependency closure fits in a chat message or a URL.
 */

const KEY_MAP: Record<string, string> = {
  schemaVersion: "v", rootId: "r", nodes: "n", presets: "p", dependencies: "d",
  revision: "rv", kind: "k", name: "nm", seed: "sd", children: "ch", parameters: "pa",
  nodeId: "ni", policy: "po", transform: "tr", position: "ps", quaternion: "qt", logScale: "ls",
  textureId: "ti", texture: "tx", shape: "sh", part: "pt", marks: "mk", source: "sc", reference: "rf",
  pattern: "pn", color: "co", accent: "ac", veinCount: "vc", veinWidth: "vw", veinContrast: "vk",
  noiseScale: "ns", noiseAmount: "na", normalStrength: "nt", roughness: "ro", normalSource: "nr", normalMix: "nx",
  length: "ln", width: "wd", curl: "cl", edgeDetail: "ed", primitive: "pr", segments: "sg", taper: "tp", bevel: "bv",
  slot: "sl", variant: "va", enabled: "en", rotation: "rt", scale: "sa",
  target: "tg", point: "pi", normal: "no", uv: "uv", radius: "ra", uvRadius: "ur", strength: "st",
  positions: "px", uvs: "ux", hash: "hs", provenance: "pv", savedId: "si", id: "i",
};
const INV_MAP: Record<string, string> = Object.fromEntries(Object.entries(KEY_MAP).map(([k, v]) => [v, k]));

function remap(value: unknown, table: Record<string, string>): unknown {
  if (Array.isArray(value)) return value.map(v => remap(v, table));
  if (value && typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      out[table[k] ?? k] = remap(v, table);
    }
    return out;
  }
  // Trim float noise so codes stay small
  if (typeof value === "number" && !Number.isInteger(value)) return Math.round(value * 1000) / 1000;
  return value;
}

function toBase64Url(bytes: Uint8Array) {
  let binary = "";
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function fromBase64Url(text: string) {
  const padded = text.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - (text.length % 4)) % 4);
  const binary = atob(padded);
  return Uint8Array.from(binary, c => c.charCodeAt(0));
}

export const SHARE_PREFIX = "HM2-";

/** Encode a preset package into a compact shareable code. */
export function encodeShareCode(pkg: PresetPackage): string {
  const compact = remap(pkg, KEY_MAP);
  const bytes = deflateSync(strToU8(JSON.stringify(compact)), { level: 9 });
  return SHARE_PREFIX + toBase64Url(bytes);
}

/** Decode a share code back into a package. Throws on malformed input. */
export function decodeShareCode(code: string): PresetPackage {
  const trimmed = code.trim();
  if (!trimmed.startsWith(SHARE_PREFIX)) throw new Error("Not a HeavyMetal² preset code");
  const body = trimmed.slice(SHARE_PREFIX.length);
  if (!/^[A-Za-z0-9\-_]+$/.test(body) || body.length > 60000) throw new Error("Preset code is malformed or too large");
  let json: string;
  try {
    json = strFromU8(inflateSync(fromBase64Url(body)));
  } catch {
    throw new Error("Preset code could not be decompressed");
  }
  if (json.length > 750000) throw new Error("Preset payload exceeds the size budget");
  const restored = remap(JSON.parse(json), INV_MAP) as PresetPackage;
  if (!restored || typeof restored !== "object" || !restored.rootId) throw new Error("Preset code is missing its root");
  return restored;
}

export function shareCodeSize(code: string) {
  return new Blob([code]).size;
}
