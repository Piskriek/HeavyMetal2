import type { BrushStroke, Vec3 } from "./types";

export function baseTerrainHeight(x: number, z: number) {
  return 0.6 + 1.9 * Math.exp(-((x + 7) ** 2 + (z + 4) ** 2) / 24) + 2.6 * Math.exp(-((x - 7) ** 2 + (z + 4) ** 2) / 22) + 0.32 * Math.sin(x * 0.63) * Math.cos(z * 0.71);
}

/** Evaluates terrain elevation including non-destructive carve and grow gel strokes. */
export function sampleCarvedTerrainHeight(x: number, z: number, strokes: BrushStroke[] = []) {
  let y = baseTerrainHeight(x, z);
  let carveOffset = 0;
  let growOffset = 0;
  for (const stroke of strokes) {
    const dist = Math.hypot(x - stroke.position[0], z - stroke.position[2]);
    if (dist >= stroke.radius) continue;
    const falloff = 1 - dist / stroke.radius;
    if (stroke.kind === "carve") carveOffset += falloff * 0.65;
    else growOffset += falloff * falloff * 0.18;
  }
  return y - Math.min(3.5, carveOffset) + Math.min(1.2, growOffset);
}

/** Computes surface normal and slope [0..1] for contextual biome & cliff adaptation. */
export function sampleTerrainSlope(x: number, z: number, strokes: BrushStroke[] = []): { normal: Vec3; slope: number } {
  const eps = 0.25;
  const hx1 = sampleCarvedTerrainHeight(x + eps, z, strokes);
  const hx0 = sampleCarvedTerrainHeight(x - eps, z, strokes);
  const hz1 = sampleCarvedTerrainHeight(x, z + eps, strokes);
  const hz0 = sampleCarvedTerrainHeight(x, z - eps, strokes);
  const dx = (hx1 - hx0) / (2 * eps);
  const dz = (hz1 - hz0) / (2 * eps);
  const len = Math.hypot(dx, 1, dz);
  const nx = -dx / len, ny = 1 / len, nz = -dz / len;
  const slope = Math.acos(Math.max(-1, Math.min(1, ny))) / (Math.PI / 2);
  return { normal: [nx, ny, nz], slope };
}

/** Smoothly pushes existing props outward from brush strokes instead of clipping. */
export function resolvePushedTreePosition(
  tree: { x: number; z: number; scale: number; rotation: number },
  strokes: BrushStroke[],
): { x: number; z: number; y: number; scale: number; carved: boolean } {
  let x = tree.x;
  let z = tree.z;
  let carved = false;
  for (const stroke of strokes) {
    const dx = x - stroke.position[0];
    const dz = z - stroke.position[2];
    const dist = Math.hypot(dx, dz);
    if (stroke.kind === "carve") {
      if (dist < stroke.radius * 0.65) {
        carved = true;
      } else if (dist < stroke.radius * 1.12 && dist > 1e-4) {
        const push = (stroke.radius * 1.12 - dist) * 0.85;
        x += (dx / dist) * push;
        z += (dz / dist) * push;
      }
    } else if (stroke.kind === "grow" && dist < stroke.radius * 0.45 && dist > 1e-4) {
      const push = (stroke.radius * 0.45 - dist) * 0.4;
      x += (dx / dist) * push;
      z += (dz / dist) * push;
    }
  }
  const y = sampleCarvedTerrainHeight(x, z, strokes);
  return { x, z, y, scale: carved ? 0 : tree.scale, carved };
}

export interface SpatialEntity {
  id: string;
  kind: "avatar" | "rider" | "chunk";
  position: Vec3;
  radius: number;
}

/** Spatial hash partitioning active 1:1 physics islands separately from macro camera LOD. */
export class SpatialHashGrid {
  private cells = new Map<string, SpatialEntity[]>();
  constructor(private cellSize = 4) {}

  private key(ix: number, iy: number, iz: number) {
    return `${ix}:${iy}:${iz}`;
  }

  clear() {
    this.cells.clear();
  }

  insert(entity: SpatialEntity) {
    const [x, y, z] = entity.position;
    const r = entity.radius;
    const minX = Math.floor((x - r) / this.cellSize), maxX = Math.floor((x + r) / this.cellSize);
    const minY = Math.floor((y - r) / this.cellSize), maxY = Math.floor((y + r) / this.cellSize);
    const minZ = Math.floor((z - r) / this.cellSize), maxZ = Math.floor((z + r) / this.cellSize);
    for (let ix = minX; ix <= maxX; ix++) {
      for (let iy = minY; iy <= maxY; iy++) {
        for (let iz = minZ; iz <= maxZ; iz++) {
          const k = this.key(ix, iy, iz);
          const list = this.cells.get(k);
          if (list) list.push(entity);
          else this.cells.set(k, [entity]);
        }
      }
    }
  }

  queryNearby(position: Vec3, radius: number): SpatialEntity[] {
    const [x, y, z] = position;
    const minX = Math.floor((x - radius) / this.cellSize), maxX = Math.floor((x + radius) / this.cellSize);
    const minY = Math.floor((y - radius) / this.cellSize), maxY = Math.floor((y + radius) / this.cellSize);
    const minZ = Math.floor((z - radius) / this.cellSize), maxZ = Math.floor((z + radius) / this.cellSize);
    const seen = new Set<string>();
    const results: SpatialEntity[] = [];
    for (let ix = minX; ix <= maxX; ix++) {
      for (let iy = minY; iy <= maxY; iy++) {
        for (let iz = minZ; iz <= maxZ; iz++) {
          const list = this.cells.get(this.key(ix, iy, iz));
          if (!list) continue;
          for (const item of list) {
            if (seen.has(item.id)) continue;
            seen.add(item.id);
            if (Math.hypot(item.position[0] - x, item.position[1] - y, item.position[2] - z) <= radius + item.radius) {
              results.push(item);
            }
          }
        }
      }
    }
    return results;
  }

  get activeCellCount() {
    return this.cells.size;
  }
}
