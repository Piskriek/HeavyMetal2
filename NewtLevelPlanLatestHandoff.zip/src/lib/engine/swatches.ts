/** Tactile PBR swatches + goblin studio decals, all under one neutral studio light. */

export type SwatchKind = "dirt" | "foliage" | "iron" | "enamel" | "brass" | "basalt";

export const MATERIAL_WEDGES: { id: SwatchKind; name: string; scope: string; accent: string }[] = [
  { id: "dirt", name: "Road dirt", scope: "Terrain", accent: "#8a6a44" },
  { id: "foliage", name: "Foliage", scope: "Biome", accent: "#5c8f2f" },
  { id: "iron", name: "Black iron", scope: "Rail", accent: "#3a3d42" },
  { id: "enamel", name: "White enamel", scope: "Props", accent: "#d9d7d0" },
  { id: "brass", name: "Brass", scope: "Rivets", accent: "#c9992e" },
  { id: "basalt", name: "Rough basalt", scope: "Material", accent: "#5a5651" },
];

const rnd = (seed: number) => { let s = seed >>> 0; return () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; }; };

/** One neutral studio light: soft top-left key, faint lower-right bounce. */
function studioLight(ctx: CanvasRenderingContext2D, size: number, strength = 0.34) {
  const key = ctx.createLinearGradient(0, 0, size, size);
  key.addColorStop(0, `rgba(255,255,255,${strength})`);
  key.addColorStop(0.5, "rgba(255,255,255,0)");
  key.addColorStop(1, `rgba(0,0,0,${strength * 0.72})`);
  ctx.fillStyle = key;
  ctx.fillRect(0, 0, size, size);
}

export function materialSwatch(kind: SwatchKind, size = 96): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = c.height = size;
  const ctx = c.getContext("2d")!;
  const r = rnd(kind.length * 7717 + size);

  if (kind === "dirt") {
    ctx.fillStyle = "#8d6f4b"; ctx.fillRect(0, 0, size, size);
    for (let i = 0; i < 1400; i++) {
      const x = r() * size, y = r() * size, g = r();
      ctx.fillStyle = g > 0.7 ? "#a98a60" : g > 0.4 ? "#7b5f3f" : "#654c31";
      ctx.fillRect(x, y, 1 + r() * 2, 1 + r() * 2);
    }
    for (let i = 0; i < 26; i++) { // embedded grit
      ctx.fillStyle = "#54402a";
      ctx.beginPath(); ctx.arc(r() * size, r() * size, 1 + r() * 2.4, 0, 7); ctx.fill();
    }
  } else if (kind === "foliage") {
    ctx.fillStyle = "#3f6f28"; ctx.fillRect(0, 0, size, size);
    for (let i = 0; i < 34; i++) { // overlapping leaf blades
      const x = r() * size, y = r() * size, a = r() * Math.PI, l = size * (0.18 + r() * 0.3);
      ctx.save(); ctx.translate(x, y); ctx.rotate(a);
      const g = ctx.createLinearGradient(0, -l / 2, 0, l / 2);
      g.addColorStop(0, "#6ca23c"); g.addColorStop(1, "#2f5c20");
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.ellipse(0, 0, l * 0.19, l * 0.5, 0, 0, 7); ctx.fill();
      ctx.strokeStyle = "rgba(20,40,14,.5)"; ctx.lineWidth = 0.8;
      ctx.beginPath(); ctx.moveTo(0, -l / 2); ctx.lineTo(0, l / 2); ctx.stroke();
      ctx.restore();
    }
  } else if (kind === "iron") {
    ctx.fillStyle = "#2b2e33"; ctx.fillRect(0, 0, size, size);
    for (let i = 0; i < 300; i++) { // brushed scratch grain
      ctx.strokeStyle = r() > 0.6 ? "rgba(255,255,255,.07)" : "rgba(0,0,0,.28)";
      ctx.lineWidth = r() * 1.1;
      const y = r() * size;
      ctx.beginPath(); ctx.moveTo(r() * size * 0.3, y); ctx.lineTo(size, y + (r() - 0.5) * 3); ctx.stroke();
    }
  } else if (kind === "enamel") {
    ctx.fillStyle = "#eeece6"; ctx.fillRect(0, 0, size, size);
    for (let i = 0; i < 9; i++) { // chipped enamel edges
      ctx.fillStyle = "rgba(120,116,108,.3)";
      ctx.beginPath(); ctx.arc(r() * size, r() * size, 1 + r() * 2.6, 0, 7); ctx.fill();
    }
    for (let i = 0; i < 40; i++) {
      ctx.strokeStyle = "rgba(150,146,138,.18)"; ctx.lineWidth = 0.6;
      const x = r() * size, y = r() * size;
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + r() * 14, y + (r() - 0.5) * 5); ctx.stroke();
    }
  } else if (kind === "brass") {
    const g = ctx.createLinearGradient(0, 0, size, size);
    g.addColorStop(0, "#e8c464"); g.addColorStop(0.45, "#c9992e"); g.addColorStop(1, "#8a6519");
    ctx.fillStyle = g; ctx.fillRect(0, 0, size, size);
    for (let i = 0; i < 220; i++) { // lathe-turned streaks
      ctx.strokeStyle = r() > 0.5 ? "rgba(255,238,180,.22)" : "rgba(90,62,10,.22)";
      ctx.lineWidth = r() * 1.3;
      const y = r() * size;
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(size, y + (r() - 0.5) * 2); ctx.stroke();
    }
  } else {
    ctx.fillStyle = "#56524d"; ctx.fillRect(0, 0, size, size);
    for (let i = 0; i < 900; i++) { // porous basalt vesicles
      const x = r() * size, y = r() * size, rad = r() * 2.4;
      ctx.fillStyle = r() > 0.55 ? "#6b6660" : "#3c3935";
      ctx.beginPath(); ctx.arc(x, y, rad, 0, 7); ctx.fill();
    }
  }
  studioLight(ctx, size, kind === "enamel" ? 0.2 : 0.3);
  return c;
}

export function swatchDataUrl(kind: SwatchKind, size = 96) {
  return materialSwatch(kind, size).toDataURL("image/png");
}

/** White enamel wall panel, lived-in: goblin tags, handprints, faint scratches. */
export function graffitiWall(seed = 7, size = 512): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = c.height = size;
  const ctx = c.getContext("2d")!;
  const r = rnd(seed * 9931);
  ctx.fillStyle = "#f6f4f0"; ctx.fillRect(0, 0, size, size);

  // Faint panel seams
  ctx.strokeStyle = "rgba(35,35,31,.09)"; ctx.lineWidth = 1.5;
  for (let i = 1; i < 3; i++) { ctx.beginPath(); ctx.moveTo((size / 3) * i, 0); ctx.lineTo((size / 3) * i, size); ctx.stroke(); }

  // Restrained scratches on the clean surface
  ctx.lineWidth = 1;
  for (let i = 0; i < 26; i++) {
    ctx.strokeStyle = `rgba(35,35,31,${0.05 + r() * 0.07})`;
    const x = r() * size, y = r() * size;
    ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + (r() - 0.5) * 70, y + (r() - 0.5) * 22); ctx.stroke();
  }

  // Sprayed goblin tags — a few vivid pops, not a flood
  const tags = [
    { x: 0.14, y: 0.34, c: "#ff2d6f", s: 1.0 },
    { x: 0.62, y: 0.22, c: "#a8e600", s: 0.8 },
    { x: 0.44, y: 0.66, c: "#00c4ff", s: 0.66 },
  ];
  for (const t of tags) {
    const cx = t.x * size, cy = t.y * size, s = t.s * size * 0.2;
    ctx.save(); ctx.translate(cx, cy); ctx.rotate((r() - 0.5) * 0.3);
    ctx.globalAlpha = 0.14; // overspray halo
    ctx.fillStyle = t.c;
    for (let i = 0; i < 110; i++) {
      const a = r() * 7, d = r() * s * 1.5;
      ctx.beginPath(); ctx.arc(Math.cos(a) * d, Math.sin(a) * d * 0.55, r() * 2.2, 0, 7); ctx.fill();
    }
    ctx.globalAlpha = 1;
    // Goblin head glyph: pointed ears + grin
    ctx.strokeStyle = t.c; ctx.lineWidth = s * 0.13; ctx.lineCap = "square";
    ctx.beginPath();
    ctx.moveTo(-s * 0.6, s * 0.34); ctx.lineTo(-s * 0.46, -s * 0.2); ctx.lineTo(-s * 0.86, -s * 0.5);
    ctx.lineTo(-s * 0.2, -s * 0.42); ctx.lineTo(s * 0.2, -s * 0.42); ctx.lineTo(s * 0.86, -s * 0.5);
    ctx.lineTo(s * 0.46, -s * 0.2); ctx.lineTo(s * 0.6, s * 0.34);
    ctx.stroke();
    ctx.beginPath(); ctx.moveTo(-s * 0.36, s * 0.1); ctx.lineTo(s * 0.36, s * 0.1); ctx.stroke();
    // Drip
    ctx.lineWidth = s * 0.07;
    ctx.beginPath(); ctx.moveTo(s * 0.5, s * 0.34); ctx.lineTo(s * 0.5, s * 0.78); ctx.stroke();
    ctx.restore();
  }

  // Paint handprints where goblins leaned on the wall
  const hands = [{ x: 0.82, y: 0.52, c: "#a8e600" }, { x: 0.29, y: 0.76, c: "#ff2d6f" }];
  for (const h of hands) {
    ctx.save(); ctx.translate(h.x * size, h.y * size); ctx.rotate((r() - 0.5) * 0.5);
    ctx.globalAlpha = 0.34; ctx.fillStyle = h.c;
    ctx.beginPath(); ctx.ellipse(0, 0, size * 0.032, size * 0.042, 0, 0, 7); ctx.fill();
    for (let f = 0; f < 4; f++) { // fingers
      const a = -1.5 + f * 0.36;
      ctx.beginPath();
      ctx.ellipse(Math.cos(a) * size * 0.04, Math.sin(a) * size * 0.04 - size * 0.03, size * 0.009, size * 0.024, a, 0, 7);
      ctx.fill();
    }
    ctx.beginPath(); ctx.ellipse(-size * 0.04, size * 0.01, size * 0.011, size * 0.02, -0.7, 0, 7); ctx.fill();
    ctx.restore();
  }
  ctx.globalAlpha = 1;
  return c;
}

/** Spilled paint pool that seeds jungle growth on the white void floor. */
export function paintSpill(color: string, seed = 3, size = 256): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = c.height = size;
  const ctx = c.getContext("2d")!;
  const r = rnd(seed * 4421);
  ctx.clearRect(0, 0, size, size);
  ctx.fillStyle = color;
  ctx.beginPath();
  const half = size / 2;
  for (let i = 0; i <= 42; i++) { // organic spill edge
    const a = (i / 42) * Math.PI * 2;
    const rad = half * (0.52 + Math.sin(a * 3 + seed) * 0.09 + r() * 0.1);
    const x = half + Math.cos(a) * rad, y = half + Math.sin(a) * rad * 0.86;
    i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
  }
  ctx.closePath(); ctx.fill();
  for (let i = 0; i < 14; i++) { // splatter droplets
    const a = r() * 7, d = half * (0.55 + r() * 0.42);
    ctx.beginPath();
    ctx.ellipse(half + Math.cos(a) * d, half + Math.sin(a) * d * 0.86, 2 + r() * 6, 2 + r() * 4, a, 0, 7);
    ctx.fill();
  }
  const sheen = ctx.createRadialGradient(half * 0.72, half * 0.68, 2, half, half, half);
  sheen.addColorStop(0, "rgba(255,255,255,.34)");
  sheen.addColorStop(1, "rgba(255,255,255,0)");
  ctx.globalCompositeOperation = "source-atop";
  ctx.fillStyle = sheen; ctx.fillRect(0, 0, size, size);
  return c;
}
