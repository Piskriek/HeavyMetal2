import * as THREE from "three";
import type { SurfaceMark, TextureRecipe } from "./authoring";

const clamp = (v: number, min = 0, max = 1) => Math.max(min, Math.min(max, v));
function hash(x: number, y: number, seed: number) { const n = Math.sin(x * 127.1 + y * 311.7 + seed * 0.037) * 43758.5453; return n - Math.floor(n); }
function noise(x: number, y: number, seed: number) {
  const ix = Math.floor(x), iy = Math.floor(y), fx = x - ix, fy = y - iy, sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy);
  return (hash(ix, iy, seed) * (1 - sx) + hash(ix + 1, iy, seed) * sx) * (1 - sy) + (hash(ix, iy + 1, seed) * (1 - sx) + hash(ix + 1, iy + 1, seed) * sx) * sy;
}
export function sampleProcedural(recipe: TextureRecipe, u: number, v: number) {
  const n = noise(u * recipe.noiseScale, v * recipe.noiseScale, recipe.seed) * 0.65 + noise(u * recipe.noiseScale * 3, v * recipe.noiseScale * 3, recipe.seed + 73) * 0.35;
  const x = Math.abs(u - 0.5), width = 0.002 + recipe.veinWidth * 0.011;
  let ridge = 0;
  if (["broadleaf", "fern", "autumn"].includes(recipe.pattern)) {
    const midrib = Math.exp(-x / (width * 1.8));
    const row = v * recipe.veinCount - x * recipe.veinCount * (recipe.pattern === "fern" ? 0.34 : 0.62);
    const distance = Math.abs(row - Math.round(row)) / recipe.veinCount;
    const branch = Math.exp(-distance / width) * clamp(1 - x * 1.7);
    const fine = Math.exp(-Math.abs(Math.sin((v + x * 0.46) * 135)) / (0.04 + recipe.veinWidth * 0.12)) * 0.12;
    ridge = Math.max(midrib, branch * 0.85) + fine;
  } else if (recipe.pattern === "bark") {
    const grain = Math.sin(u * recipe.veinCount * Math.PI * 2 + n * 5 + Math.sin(v * 13) * 0.7);
    ridge = Math.pow(Math.abs(grain), 2 + recipe.veinWidth * 8) * 0.75;
  } else if (recipe.pattern === "skin") {
    const pores = noise(u * recipe.veinCount * 3, v * recipe.veinCount * 3, recipe.seed + 29);
    const threshold = 0.86 - recipe.veinWidth * 0.2;
    ridge = pores > threshold ? (pores - threshold) * 2.6 : 0;
  } else {
    ridge = Math.pow(Math.abs(Math.sin(v * recipe.veinCount * 28 + n * 2)), 8 + recipe.veinWidth * 24) * 0.32;
  }
  return { height: 0.35 + ridge * recipe.veinContrast * 0.45 + (n - 0.5) * recipe.noiseAmount * 0.3, blend: clamp(ridge * recipe.veinContrast * 0.65), shade: 0.78 + n * recipe.noiseAmount * 0.25 + (1 - recipe.noiseAmount) * 0.12 };
}
export interface TexturePixels { size: number; baseColor: Uint8ClampedArray; normal: Uint8ClampedArray; roughness: Uint8ClampedArray; height: Uint8ClampedArray; }
function rgb(hex: string): [number, number, number] { return [parseInt(hex.slice(1, 3), 16), parseInt(hex.slice(3, 5), 16), parseInt(hex.slice(5, 7), 16)]; }
export function bakeTexturePixels(recipe: TextureRecipe, marks: SurfaceMark[] = [], source: TextureRecipe | null = null, size = 256): TexturePixels {
  const baseColor = new Uint8ClampedArray(size * size * 4), normal = new Uint8ClampedArray(size * size * 4), roughness = new Uint8ClampedArray(size * size * 4), height = new Uint8ClampedArray(size * size * 4), heights = new Float32Array(size * size);
  const color = rgb(recipe.color), accent = rgb(recipe.accent);
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const i = y * size + x, u = x / (size - 1), v = 1 - y / (size - 1), sample = sampleProcedural(recipe, u, v);
    heights[i] = sample.height + (source ? (sampleProcedural(source, u, v).height - 0.35) * recipe.normalMix : 0);
    for (let c = 0; c < 3; c++) baseColor[i * 4 + c] = (color[c] * (1 - sample.blend) + accent[c] * sample.blend) * sample.shade;
    baseColor[i * 4 + 3] = 255;
    const r = clamp(recipe.roughness + (sample.height - 0.5) * 0.13) * 255;
    roughness.set([r, r, r, 255], i * 4);
  }
  // UV-space brush compositing. No decal meshes and no model dropping.
  for (const mark of marks) {
    if (!["paint", "push", "pull"].includes(mark.kind)) continue;
    const cx = mark.uv[0] * size, cy = (1 - mark.uv[1]) * size, r = Math.max(1, mark.uvRadius * size), paint = rgb(mark.color);
    for (let y = Math.max(0, Math.floor(cy - r)); y < Math.min(size, Math.ceil(cy + r)); y++) for (let dx = Math.floor(-r); dx <= Math.ceil(r); dx++) {
      const px = Math.round(cx + dx), x = (px % size + size) % size, d = Math.hypot(px - cx, y - cy) / r;
      if (d > 1) continue;
      const alpha = (1 - d * d) ** 2 * mark.strength, i = y * size + x;
      if (mark.kind === "paint") for (let c = 0; c < 3; c++) baseColor[i * 4 + c] = baseColor[i * 4 + c] * (1 - alpha) + paint[c] * alpha;
      else heights[i] += alpha * (mark.kind === "push" ? -0.15 : 0.15);
    }
  }
  const at = (x: number, y: number) => heights[clamp(y, 0, size - 1) * size + (x + size) % size];
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const i = y * size + x, dx = (at(x + 1, y) - at(x - 1, y)) * recipe.normalStrength * 8, dy = (at(x, y + 1) - at(x, y - 1)) * recipe.normalStrength * 8;
    const length = Math.hypot(dx, dy, 1);
    normal.set([(-dx / length * 0.5 + 0.5) * 255, (dy / length * 0.5 + 0.5) * 255, (1 / length * 0.5 + 0.5) * 255, 255], i * 4);
    const h = clamp(heights[i]) * 255; height.set([h, h, h, 255], i * 4);
  }
  return { size, baseColor, normal, roughness, height };
}
export function textureCanvas(pixels: TexturePixels, channel: "baseColor" | "normal" | "roughness" | "height") {
  const canvas = document.createElement("canvas"); canvas.width = pixels.size; canvas.height = pixels.size;
  const ctx = canvas.getContext("2d")!; const image = ctx.createImageData(pixels.size, pixels.size); image.data.set(pixels[channel]); ctx.putImageData(image, 0, 0); return canvas;
}
export function makePBRMaterial(recipe: TextureRecipe, marks: SurfaceMark[] = [], source: TextureRecipe | null = null, size = 256): THREE.MeshStandardMaterial {
  const pixels = bakeTexturePixels(recipe, marks, source, size);
  const map = new THREE.CanvasTexture(textureCanvas(pixels, "baseColor")); map.colorSpace = THREE.SRGBColorSpace;
  const normalMap = new THREE.CanvasTexture(textureCanvas(pixels, "normal"));
  const roughnessMap = new THREE.CanvasTexture(textureCanvas(pixels, "roughness"));
  for (const t of [map, normalMap, roughnessMap]) { t.wrapS = THREE.RepeatWrapping; t.wrapT = THREE.RepeatWrapping; t.anisotropy = 4; }
  return new THREE.MeshStandardMaterial({ map, normalMap, normalScale: new THREE.Vector2(1, 1), roughnessMap, roughness: 1, metalness: recipe.pattern === "metal" ? 0.68 : 0, side: THREE.DoubleSide, color: 0xffffff });
}
