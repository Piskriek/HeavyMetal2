import { attachAuthoringGraph, createAuthoringState, type AuthoringState } from "./authoring";

export type Vec3 = [number, number, number];
export type WorldStyle = "verdant" | "dunes" | "lunar";
export type StudioTool = "select" | "brush" | "rail" | "move" | "erase";
export type RenderStyle = "standard" | "cinematic" | "wireframe";
export type NodeKind = "universe" | "planet" | "terrain" | "biome" | "prop" | "material" | "rail";

export interface NodeTransform {
  position: Vec3;
  quaternion: [number, number, number, number];
  logScale: number;
}
export interface NodeReference {
  nodeId: string;
  revision: number;
  transform: NodeTransform;
  policy: "pinned" | "follow";
}
export interface FractalNode {
  id: string;
  revision: number;
  kind: NodeKind;
  name: string;
  seed: number;
  children: NodeReference[];
  parameters: Record<string, string | number | boolean>;
}
export interface GraphSnapshot {
  schemaVersion: 1;
  rootId: string;
  nodes: Record<string, FractalNode>;
}
export interface BrushStroke {
  id: string;
  position: Vec3;
  radius: number;
  density: number;
  style: WorldStyle;
  seed: number;
  kind: "grow" | "carve";
  scale?: number;
}
export interface StudioSettings {
  radius: number;
  density: number;
  autoSize: boolean;
  renderStyle: RenderStyle;
  quality: "auto" | "performance" | "high";
  roughness: number;
  materialScale: number;
  materialRotation: number;
  materialPosition: Vec3;
  materialDetail: number;
}
export interface WorldSnapshot {
  schemaVersion: 1;
  seed: number;
  style: WorldStyle;
  graph: GraphSnapshot;
  strokes: BrushStroke[];
  rails: Vec3[];
  settings: StudioSettings;
  authoring?: AuthoringState;
  economy?: IslandEconomy;
}
export interface SavedWorld {
  id: string;
  name: string;
  snapshot: WorldSnapshot;
  version: number;
  visibility: "private" | "public";
  parentId: string | null;
  archived: boolean;
  createdAt: string;
  updatedAt: string;
  owned?: boolean;
}
export type MajorityRuleId = "standard" | "low_gravity" | "chin_check" | "turbo_chain" | "free_anarchy";
export interface IslandEconomy {
  raceMoneys: number;
  islandScale: number;
  joinedFriends: string[];
  isWaterRacePlanet: boolean;
  majorityRule: MajorityRuleId;
  chinHits: number;
  wins: number;
}
export interface RacerStanding {
  id: string;
  name: string;
  color: string;
  odds: number;
  laps: number;
  distance: number;
  attached: boolean;
  rank: number;
}
export type AvatarCameraMode = "orbit" | "third" | "first";
export interface AvatarStatus {
  spawned: boolean;
  mode: AvatarCameraMode;
  position: Vec3;
  spectateRail: boolean;
  activeCells: number;
  cheering?: boolean;
  wasted?: boolean;
  chinHits?: number;
  lastChinHitBy?: string | null;
  standings?: RacerStanding[];
  lapWinner?: string | null;
}
export interface SceneMetrics { fps: number; triangles: number; calls: number; objects: number; activeCells?: number; }

export const RACER_ROSTER = [
  { id: "rivet", name: "Rivet", color: "#c0ec85", odds: 2.0, tagline: "Balanced iron-hook sprinter" },
  { id: "nix", name: "Nix", color: "#efac72", odds: 2.5, tagline: "Heavy brass brawler" },
  { id: "sprocket", name: "Sprocket", color: "#b5a2dc", odds: 3.0, tagline: "High-risk chaos pedaler" },
] as const;

export const MAJORITY_RULES: { id: MajorityRuleId; name: string; badge: string; description: string; gravityScale: number; speedScale: number; chinBonus: number }[] = [
  { id: "standard", name: "Scrapdome Standard", badge: "1.0G", description: "Balanced 120Hz rail kinematics, standard betting payouts, and normal chin-check physics.", gravityScale: 1, speedScale: 1, chinBonus: 25 },
  { id: "chin_check", name: "Bloodsport Chin-Check", badge: "2X CHIN", description: "Spectators on the track deflect racing balls 1.8x harder and earn +60 Scrap for taking a sphere to the chin!", gravityScale: 1, speedScale: 1.15, chinBonus: 60 },
  { id: "low_gravity", name: "Lunar Low-Gravity Chaos", badge: "0.45G", description: "Moon gravity! Huge jumps, wild orbital derailments, and long-hangtime winch recoveries.", gravityScale: 0.45, speedScale: 1.1, chinBonus: 35 },
  { id: "turbo_chain", name: "Turbo Chain Overdrive", badge: "1.5X SPD", description: "Overclocked drive chain! Spheres pedal at 1.5x speed and collisions send debris flying.", gravityScale: 1, speedScale: 1.5, chinBonus: 45 },
  { id: "free_anarchy", name: "Track Anarchy & Remix", badge: "MODS ON", description: "Community mod hooks & mid-race spectator interference enabled across the entire island.", gravityScale: 0.8, speedScale: 1.3, chinBonus: 50 },
];

export const DEFAULT_ECONOMY: IslandEconomy = {
  raceMoneys: 250,
  islandScale: 1.0,
  joinedFriends: [],
  isWaterRacePlanet: false,
  majorityRule: "standard",
  chinHits: 0,
  wins: 0,
};

export const DEFAULT_SETTINGS: StudioSettings = {
  radius: 2.4, density: 65, autoSize: true, renderStyle: "standard", quality: "auto",
  roughness: 0.82, materialScale: 1, materialRotation: 0, materialPosition: [0, 0, 0], materialDetail: 2,
};
export const STYLE_META = {
  verdant: { name: "Verdant Highlands", short: "Verdant Isle", description: "A little wilderness. A lot of possibility.", image: "/images/verdant.jpg", tag: "FOREST", color: "#b8ef73" },
  dunes: { name: "Ember Dunes", short: "Ember Dunes", description: "Sculpt something from the shifting sands.", image: "/images/dunes.jpg", tag: "DESERT", color: "#f3b373" },
  lunar: { name: "Lunar Drift", short: "Lunar Drift", description: "An otherworldly place to make your own.", image: "/images/lunar.jpg", tag: "COSMIC", color: "#b9a0ef" },
};

export function createDefaultGraph(style: WorldStyle = "verdant"): GraphSnapshot {
  const nodes: Record<string, FractalNode> = {};
  const add = (id: string, kind: NodeKind, name: string, children: string[], seed: number) => {
    nodes[id] = { id, revision: 1, kind, name, seed, parameters: {}, children: children.map(nodeId => ({
      nodeId, revision: 1, policy: "pinned", transform: { position: [0, 0, 0], quaternion: [0, 0, 0, 1], logScale: -1 },
    })) };
  };
  add("universe", "universe", "The Outer Wilds", ["planet"], 42);
  add("planet", "planet", STYLE_META[style].short, ["terrain", "rail"], 1042);
  add("terrain", "terrain", "Highland terrain", ["forest", "canyon", "water"], 12);
  add("forest", "biome", "Alpine forest", ["pine", "rock"], 26);
  add("canyon", "biome", "Sandstone cliffs", ["arch"], 38);
  add("water", "biome", "Crystal creek", [], 52);
  add("pine", "prop", "Pine cluster", ["bark"], 62);
  add("rock", "prop", "Mossy boulder", ["stone"], 72);
  add("arch", "prop", "Sandstone arch", ["stone"], 83);
  add("stone", "material", "Weathered sandstone", [], 91);
  add("bark", "material", "Alpine bark", [], 95);
  add("rail", "rail", "Slotted rail network", [], 106);
  return { schemaVersion: 1, rootId: "universe", nodes };
}
export function createDefaultSnapshot(style: WorldStyle = "verdant"): WorldSnapshot {
  const authoring = createAuthoringState();
  return {
    schemaVersion: 1,
    seed: 1042,
    style,
    graph: attachAuthoringGraph(createDefaultGraph(style), authoring),
    strokes: [],
    rails: [],
    settings: { ...DEFAULT_SETTINGS },
    authoring,
    economy: { ...DEFAULT_ECONOMY, joinedFriends: [] },
  };
}
