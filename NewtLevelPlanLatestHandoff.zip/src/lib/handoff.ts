/**
 * The handoff brief.
 *
 * Content for /handoff — everything a fresh agent needs to pick up
 * HeavyMetal² and keep building, plus the marketing summary.
 * Kept as data so the page stays presentational.
 */

export const REPO = {
  url: "https://github.com/Piskriek/HeavyMetal2",
  branch: "arena/01a0ecba-heavymetal2",
  stack: "Next.js 16 (App Router) · React 19 · TypeScript · Three.js r186 · PostgreSQL + Drizzle",
};

export const TRUTH: { label: string; body: string }[] = [
  {
    label: "This workspace is not a clone of that repo",
    body: "No agent in this session had network access to github.com/Piskriek/HeavyMetal2. Nothing here was pulled from it and nothing was pushed to it. Treat this codebase as a standalone Next.js implementation that must be reconciled with the repo, not as a branch of it.",
  },
  {
    label: "The upstream repo is a different stack",
    body: "Public documentation describes HeavyMetal2 as a React + Vite + Canvas 2D game called Goblin Rally. This workspace is Next.js App Router with a Three.js WebGL renderer and a PostgreSQL backend. Merging is a port, not a fast-forward. Decide deliberately whether to port this in, vendor it as a subdirectory, or treat it as the new trunk.",
  },
  {
    label: "Commit 5e77a65 / PR #62 were never verified",
    body: "A previous instruction referenced a PBR texture commit on that PR. It could not be fetched or inspected. Every texture in this build is procedurally generated at runtime. Verify what those assets actually contain before wiring them in.",
  },
  {
    label: "Multiplayer surfaces are local-only",
    body: "Race planet, chat, leaderboard, votes and the mod registry are real and database-backed, but single-process and session-scoped. There is no authoritative server tick, no reconciliation and no anti-cheat. Do not describe them as multiplayer in user-facing copy.",
  },
];

export interface BuiltItem { area: string; detail: string; files: string[] }

export const BUILT: BuiltItem[] = [
  {
    area: "Fractal preset graph",
    detail: "Content-addressed DAG with pinned revisions, cycle detection, depth and node budgets, fork/replace copy-on-write semantics.",
    files: ["src/lib/engine/graph.ts", "src/lib/engine/authoring.ts", "src/lib/engine/authoring-validation.ts"],
  },
  {
    area: "Preset chain",
    detail: "Six raw primitives → material → composed object → wood/leaf → tree/goblin. Each level is enterable, sculptable and saveable.",
    files: ["src/lib/engine/preset-geometry.ts", "src/components/preset-chain.tsx"],
  },
  {
    area: "Procedural PBR",
    detail: "Albedo, tangent-space normal, roughness and AO generated on canvas at 512². Vein/grain/pore algorithms driven by a live recipe.",
    files: ["src/lib/engine/textures.ts", "src/lib/engine/pbr-showcase.ts", "src/lib/engine/swatches.ts"],
  },
  {
    area: "Surface authoring",
    detail: "UV painting and real vertex sculpting at every depth. Strokes are replayable commands, so undo, branch and share all work.",
    files: ["src/lib/engine/preset-scene.ts", "src/components/preset-workbench.tsx"],
  },
  {
    area: "Interface as a preset",
    detail: "Icon set, stroke weight, density, hairlines, radius and palette are one recipe that rewrites CSS variables live. Dark mode is the Dark Room preset, not a second stylesheet.",
    files: ["src/lib/engine/interface-preset.ts", "src/lib/engine/icon-sets.ts", "src/components/interface-studio.tsx"],
  },
  {
    area: "Share codes",
    detail: "Deflated, key-shortened, base64url packages carrying a full dependency closure. Measured 2,875 B → 659 B (77% smaller). Interface codes are 65 chars.",
    files: ["src/lib/engine/share-codes.ts"],
  },
  {
    area: "Share economy",
    detail: "+40 Scrap to publish, +15 per use, +35 per remix, paid only when someone else picks it up. Auto-share, share-on-entry and share-in-chat persist server-side.",
    files: ["src/app/api/presets/route.ts", "src/db/schema.ts"],
  },
  {
    area: "Quality of life",
    detail: "Context material shelf, next-brush suggestion on E, auto-hiding drawers, branching zoomable preset network, per-preset edit buttons.",
    files: ["src/lib/engine/brush-context.ts", "src/components/quick-shelf.tsx", "src/components/preset-network.tsx"],
  },
  {
    area: "Showcase room & palette",
    detail: "Rock/tree/bush vignette under a three-point studio rig, plus a clickable paint-well palette rendered from the same generators.",
    files: ["src/lib/engine/scene.ts", "src/components/pbr-palette.tsx"],
  },
  {
    area: "Phone layout",
    detail: "Bottom sheets, thumb-reach tool rail, launcher bar, safe-area insets, coarse-pointer rules so nothing hides behind hover.",
    files: ["src/app/mobile.css"],
  },
];

export interface Task {
  n: number;
  title: string;
  why: string;
  how: string[];
  acceptance: string;
  touches: string[];
  size: "S" | "M" | "L";
}

export const TASKS: Task[] = [
  {
    n: 1,
    title: "Reconcile with the upstream repo",
    why: "Nothing else can be merged until the relationship between this codebase and github.com/Piskriek/HeavyMetal2 is decided. Doing this first avoids building more work onto an unresolved fork.",
    how: [
      "Clone the repo and read its actual tree — do not trust the summary in this brief.",
      "Inspect commit 5e77a65 and PR #62 to see what the PBR texture sets really are (file formats, resolution, channel packing, licence).",
      "Choose one: port this Next.js build in as the new trunk, vendor it under a subdirectory, or port individual systems across.",
      "Record the decision and rationale in PLAN.md before writing code.",
    ],
    acceptance: "A written decision in PLAN.md, plus a branch that builds green against the chosen structure.",
    touches: ["repo root", "public/PLAN.md"],
    size: "M",
  },
  {
    n: 2,
    title: "Wire the low-poly PBR texture sets",
    why: "The art already exists. This is the highest visual return for the least architectural risk, and the slots are already defined.",
    how: [
      "Each incoming set becomes a PbrSet of albedo / normal / roughness / AO.",
      "Register it in GENERATORS and SHOWCASE_MATERIALS in pbr-showcase.ts, which already carry per-material UV repeat, normal strength and metalness.",
      "If the art ships as image files, add a loader path alongside the canvas generators rather than replacing them — procedural stays the fallback when an asset is missing.",
      "Palette wells read from the same registry, so they populate with no extra work.",
    ],
    acceptance: "A low-poly set renders in the showcase and appears in the palette with zero changes to scene.ts.",
    touches: ["src/lib/engine/pbr-showcase.ts", "src/components/pbr-palette.tsx"],
    size: "M",
  },
  {
    n: 3,
    title: "Interface presets to the server",
    why: "The interface is already a preset in every way except persistence. It travels by code but cannot be discovered or earn Scrap, which breaks the 'everything is a preset' promise.",
    how: [
      "Add kind = 'interface' to the authoringPresets row and store the recipe in the package column.",
      "Reuse validateInterface on the POST path — never trust an incoming recipe.",
      "Surface interface presets in the community list with a live swatch preview.",
    ],
    acceptance: "An interface preset can be published, appears in the community list, and earns Scrap when someone else applies it.",
    touches: ["src/app/api/presets/route.ts", "src/db/schema.ts", "src/components/interface-studio.tsx"],
    size: "S",
  },
  {
    n: 4,
    title: "Reactive preset chemistry",
    why: "The biggest gameplay unlock on the list. Presets stop being inert and start combining, which turns the whole material library into a sandbox.",
    how: [
      "Implement ReactionRule as a declarative record — no user code, so it rides existing validation and share codes.",
      "Match on tags (liquid, combustible, mineral) rather than preset pairs to avoid N² rules.",
      "Gate behind a reactions flag in IslandEconomy, exposed as a Play-mode switch so Build stays deterministic.",
      "Propagate through the existing spatial hash with a per-tick cell budget and a hard cap on active reactions.",
      "Settle the three open questions in PLAN.md §10 before writing the resolver.",
    ],
    acceptance: "dirt + water produces mud in Play mode, mud dries back to dirt, fire spreads along connected wood and stops at the cap, and Build mode is unaffected.",
    touches: ["src/lib/engine/authoring.ts", "src/lib/engine/spatial.ts", "src/lib/engine/scene.ts", "src/lib/engine/types.ts"],
    size: "L",
  },
  {
    n: 5,
    title: "Icon set authoring",
    why: "Closes the last gap in the interface-as-preset loop. Four sets ship, but a user cannot fork one and redraw a glyph.",
    how: [
      "Let a user fork an icon set into their branch, then edit individual 24×24 path data on a grid.",
      "Reuse the sculpt/paint panel rather than building a new editor surface.",
      "Keep the Hairline fallback for any glyph a fork leaves empty.",
    ],
    acceptance: "A user forks a set, redraws one glyph, and that glyph travels inside the interface share code.",
    touches: ["src/lib/engine/icon-sets.ts", "src/components/interface-studio.tsx"],
    size: "M",
  },
  {
    n: 6,
    title: "Per-surface bake atlas",
    why: "PBR export covers one surface. A six-part goblin needs six bakes or one packed atlas, which blocks real asset export.",
    how: [
      "Pack named surfaces into a single atlas with a UV offset table recorded in the preset package.",
      "Emit the atlas plus a manifest so downstream tools can unpack it.",
    ],
    acceptance: "A goblin exports one atlas covering all six parts, and re-importing it reproduces the original surfaces.",
    touches: ["src/lib/engine/textures.ts", "src/components/preset-workbench.tsx"],
    size: "M",
  },
  {
    n: 7,
    title: "Server-authoritative race tick",
    why: "Precondition for honest multiplayer. Everything race-related currently resolves client-side.",
    how: [
      "Move the fixed 120 Hz rail step behind an authoritative endpoint.",
      "Send coordinates and seeds, never rendered state.",
      "Add reconciliation with client prediction, then revisit the anti-cheat story.",
    ],
    acceptance: "Two clients observing the same race agree on standings and chin-check outcomes without trusting either client.",
    touches: ["src/lib/engine/scene.ts", "src/app/api/race-planet/route.ts"],
    size: "L",
  },
];

export const AGREEMENTS: { rule: string; detail: string }[] = [
  { rule: "Everything is a preset", detail: "If you add a new kind of content, give it a recipe, a revision, a share code and an edit path. No privileged engine-only tier." },
  { rule: "Preserve the flat language", detail: "Zero rounded corners by default, hairline charcoal, warm white. Tactile PBR belongs in the radial wedges, palette wells and small previews — not flooded across the chrome." },
  { rule: "Clamp, then validate", detail: "Clamp client-side for resilience, validate server-side for safety. Never trust a share code, an imported GLB or a pasted recipe." },
  { rule: "Context over configuration", detail: "The shelf and the next-brush suggestion derive from where the user is standing. Prefer inference to another settings toggle." },
  { rule: "Say what is not built", detail: "Any surface that looks multiplayer-ready must be honest in its copy. Do not let a prototype imply a product." },
  { rule: "Verify before you claim", detail: "Run npm run verify. It covers typegen, TypeScript, production build and 20 engine assertions. Do not report work as done without it." },
];

export const BUDGETS: { limit: string; value: string }[] = [
  { limit: "Graph nodes per world", value: "4,096" },
  { limit: "Traversal depth", value: "32 levels" },
  { limit: "Authoring documents", value: "256" },
  { limit: "Surface marks per world", value: "1,400" },
  { limit: "Saved presets per workspace", value: "200" },
  { limit: "Request payload", value: "750 KB" },
];

export interface Feature { name: string; pitch: string }

export const MARKETING: { headline: string; sub: string; features: Feature[]; closer: string } = {
  headline: "A world you can open all the way down.",
  sub: "HeavyMetal² is a procedural world studio disguised as a goblin racing sandbox. Every rock, leaf, texture, goblin ear — and the interface itself — is a preset you can enter, sculpt, paint, fork and share as a single line of text.",
  features: [
    { name: "Open anything", pitch: "Click into a tree and you are inside the tree. Click into its leaf and you are inside the leaf. Click again and you are editing the texture recipe that makes it green. Six levels deep, and the brush changes meaning at every one." },
    { name: "Cube to canopy", pitch: "Start with an untextured cube. Add bark. Tweak it. Save it as your own. Now it is a building block — drop it into a branch, grow leaves on it, and save the whole thing as a tree." },
    { name: "Real PBR, generated live", pitch: "Albedo, normals, roughness and ambient occlusion, generated as you move the sliders. Fracture lines bite into stone. Moss reads rougher than the ridge beside it. Veins catch the light." },
    { name: "A palette of wet paint", pitch: "Materials sit in circular wells like a real paint holder, each rendered from the same generator that textures the world. Click one and it is on your brush." },
    { name: "Build a goblin from parts", pitch: "Six sockets — head, ears, body, arms, legs, armour. Swap silhouettes, transform sockets, then paint and sculpt the actual mesh. Your goblin rides the rails and walks the island." },
    { name: "Walk into your own world", pitch: "Spawn on the surface in first or third person. Walk, jump, cheer. Step onto the track and take a racing sphere to the chin — you will wipe out, and so will the ball." },
    { name: "The interface is a preset too", pitch: "Four icon sets. Sculpt the stroke weight, density and hairlines. Paint the ink and accent. Share your whole workshop as a 65-character code and someone else wears it." },
    { name: "Share codes that fit in a message", pitch: "A preset and its entire dependency closure compress 77% into one line. Paste it in chat. Paste it in a URL. It rebuilds exactly." },
    { name: "Sharing pays", pitch: "+40 Scrap when you publish, +15 every time someone uses your preset, +35 every remix — paid only when someone else picks it up. Scrap buys island space." },
    { name: "More people, more space", pitch: "Trade winnings for terrain, or link islands with a friend and you both get 1.5×. The more of you there are, the bigger you can build." },
    { name: "Majority rules", pitch: "On the water race planet everyone plays by whatever the community voted in — low gravity, turbo chain, or bloodsport chin-check." },
    { name: "Open source by design", pitch: "A declarative mod registry with upstream hooks, so modders extend the thing rather than forking away from it." },
  ],
  closer: "Small worlds. Infinite possibility. Every detail is a door.",
};
