import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import type { worlds } from "@/db/schema";

export async function sessionToken() {
  const jar = await cookies();
  const existing = jar.get("hm2_session")?.value;
  if (existing && /^[0-9a-f-]{36}$/i.test(existing)) return existing;
  const token = crypto.randomUUID();
  jar.set("hm2_session", token, { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 60 * 60 * 24 * 365, path: "/" });
  return token;
}
export function serializeWorld(row: typeof worlds.$inferSelect, token: string) {
  const { ownerToken, ...world } = row;
  return { ...world, owned: ownerToken === token };
}
export function validId(id: string) { return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id); }
export async function readBody(request: Request): Promise<Record<string, unknown>> {
  if (Number(request.headers.get("content-length") ?? 0) > 750000) throw new Error("World payload is too large");
  const text = await request.text();
  if (text.length > 750000) throw new Error("World payload is too large");
  const body = JSON.parse(text);
  if (!body || typeof body !== "object" || Array.isArray(body)) throw new Error("Invalid request body");
  return body;
}
export function apiError(error: unknown) {
  console.error("World API:", error instanceof Error ? error.message : error);
  return NextResponse.json({ error: error instanceof Error && !/database|relation|connect|query/i.test(error.message) ? error.message : "World storage is temporarily unavailable. Please try again." }, { status: 400 });
}
