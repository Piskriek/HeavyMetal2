import "dotenv/config";
import { db, pool } from "@/db";
import { worlds, authoringPresets } from "@/db/schema";
import { inArray } from "drizzle-orm";
async function main() {
  const presets = await db.delete(authoringPresets).where(inArray(authoringPresets.name, ["Browser authoring emerald", "Browser authoring copper"])).returning({ id: authoringPresets.id });
  const worldRows = await db.delete(worlds).where(inArray(worlds.name, ["Browser authoring world"])).returning({ id: worlds.id });
  console.log(`Removed ${presets.length} temporary preset packages and ${worldRows.length} temporary test worlds.`);
  await pool.end();
}
void main().catch(async error => { console.error(error); await pool.end(); process.exitCode = 1; });
