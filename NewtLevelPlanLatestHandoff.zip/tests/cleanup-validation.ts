import "dotenv/config";
import { db, pool } from "@/db";
import { worlds } from "@/db/schema";
import { inArray } from "drizzle-orm";

async function main() {
  const removed = await db.delete(worlds).where(inArray(worlds.name, ["Browser validation world", "Browser validation remix", "Cookie transport check"])).returning({ id: worlds.id });
  console.log(`Removed ${removed.length} temporary browser-validation worlds; revision rows cascade.`);
  await pool.end();
}
void main().catch(async error => { console.error(error); await pool.end(); process.exitCode = 1; });
