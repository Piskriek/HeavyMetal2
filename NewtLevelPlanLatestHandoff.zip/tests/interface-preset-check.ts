import assert from "node:assert/strict";
import {
  DEFAULT_INTERFACE, INTERFACE_PRESETS, decodeInterface, encodeInterface,
  interfaceVars, normaliseInterface, validateInterface,
} from "../src/lib/engine/interface-preset";
import { ICON_SETS, ICON_SET_IDS, iconPaths } from "../src/lib/engine/icon-sets";
import { shelfForContext, suggestNextBrush } from "../src/lib/engine/brush-context";
import { createDefaultSnapshot } from "../src/lib/engine/types";

// Every icon set covers every icon the UI asks for
const names = Object.keys(ICON_SETS.hairline.paths) as (keyof typeof ICON_SETS.hairline.paths)[];
for (const set of ICON_SET_IDS) {
  for (const name of names) {
    const paths = iconPaths(set, name);
    assert.ok(paths.length > 0, `${set}/${name} has no geometry`);
    assert.ok(paths.every(d => /^[MmLlCcAaZzHhVvQq0-9eE., \-]+$/.test(d)), `${set}/${name} has malformed path data`);
  }
}
console.log(`PASS ${ICON_SET_IDS.length} icon sets each cover all ${names.length} interface icons with valid path data`);

// Interface recipe round-trips through a compact one-line code
const custom = { ...DEFAULT_INTERFACE, iconSet: "chisel" as const, iconWeight: 2.4, density: "roomy" as const, accent: "#00c4ff", radius: 4, grain: 0.6 };
const code = encodeInterface(custom);
assert.ok(code.startsWith("HM2UI-"));
assert.ok(code.length < 120, `interface code should stay chat-sized, got ${code.length}`);
const back = decodeInterface(code);
validateInterface(back);
assert.equal(back.iconSet, "chisel");
assert.equal(back.density, "roomy");
assert.equal(back.accent, "#00c4ff");
assert.equal(back.radius, 4);
console.log(`PASS interface round-trips as a ${code.length}-char code and re-validates`);

// Out-of-range values are clamped, never crash the studio
const wild = normaliseInterface({ iconWeight: 99, radius: -40, grain: 12, accent: "not-a-colour", iconSet: "nope" as never });
assert.equal(wild.iconWeight, 3.5);
assert.equal(wild.radius, 0);
assert.equal(wild.grain, 1);
assert.equal(wild.accent, DEFAULT_INTERFACE.accent);
assert.equal(wild.iconSet, "hairline");
console.log("PASS hostile interface values are clamped to safe ranges");

// Malformed codes are rejected rather than silently applied
assert.throws(() => decodeInterface("nope"), /Not an interface code/);
assert.throws(() => decodeInterface("HM2UI-a~b"), /malformed/);
console.log("PASS malformed interface codes rejected");

// Every shipped preset is valid and produces usable CSS variables
for (const p of INTERFACE_PRESETS) {
  validateInterface(p.recipe);
  const vars = interfaceVars(p.recipe);
  assert.ok(vars["--ink"].startsWith("#"), `${p.id} ink`);
  assert.ok(vars["--hair"].startsWith("rgba("), `${p.id} hairline`);
  assert.ok(Number(vars["--ui-density"]) >= 1, `${p.id} density`);
}
console.log(`PASS ${INTERFACE_PRESETS.length} shipped interface presets validate and emit CSS variables`);

// Flat language is preserved by default: zero radius on the shipped build skin
assert.equal(interfaceVars(DEFAULT_INTERFACE)["--ui-radius"], "0px");
console.log("PASS default interface keeps the zero-radius cut-out language");

// Context shelf still reacts to preset kind (guards the QoL layer)
const world = createDefaultSnapshot();
const leafShelf = shelfForContext("leaf", "paint").map(e => e.id);
const woodShelf = shelfForContext("wood", "paint").map(e => e.id);
assert.notDeepEqual(leafShelf, woodShelf);
const leaf = world.authoring!.presets.leaf;
const first = suggestNextBrush("leaf", "orbit", leaf).tool;
const second = suggestNextBrush("leaf", first, leaf).tool;
assert.notEqual(first, second, "next-brush must advance");
console.log(`PASS context shelf and next-brush stay context-aware (leaf: ${leafShelf.join("/")}, rhythm ${first} → ${second})`);
