import assert from "node:assert/strict";
import { createDefaultSnapshot } from "../src/lib/engine/types";
import { makePresetPackage, PRIMITIVES, editPreset } from "../src/lib/engine/authoring";
import { encodeShareCode, decodeShareCode, shareCodeSize } from "../src/lib/engine/share-codes";
import { validatePresetPackage } from "../src/lib/engine/authoring-validation";
import { validateSnapshot } from "../src/lib/engine/graph";

const world = createDefaultSnapshot();
validateSnapshot(world);

// Primitives exist at the base of the chain
for (const p of PRIMITIVES) assert.ok(world.authoring!.presets[`shape-${p.id}`], `missing ${p.id}`);
assert.equal(world.authoring!.presets["shape-cube"].textureId, null, "raw cube must be untextured");
console.log("PASS six raw primitives seeded, cube starts untextured");

// Object slot composes primitive + material
const obj = world.authoring!.presets[world.authoring!.bindings.object!];
assert.equal(obj.kind, "object");
assert.equal(obj.shape.primitive, "cylinder");
assert.ok(obj.textureId, "object must carry a material");
console.log("PASS composable object = primitive + material");

// Round-trip a share code through compression
const pkg = makePresetPackage(world, "pine");
const code = encodeShareCode(pkg);
assert.ok(code.startsWith("HM2-"));
const back = decodeShareCode(code);
validatePresetPackage(back);
assert.equal(back.rootId, pkg.rootId);
assert.equal(Object.keys(back.presets).length, Object.keys(pkg.presets).length);
assert.deepEqual(back.presets[pkg.rootId].shape, pkg.presets[pkg.rootId].shape);
const raw = JSON.stringify(pkg).length, small = shareCodeSize(code);
assert.ok(small < raw * 0.5, `code ${small}B should be <50% of raw ${raw}B`);
console.log(`PASS share code round-trips and validates (${raw}B raw -> ${small}B code, ${Math.round((1 - small / raw) * 100)}% smaller)`);

// Tweak then re-encode: codes track edits
const tweaked = editPreset(world, "shape-cube", { shape: { ...world.authoring!.presets["shape-cube"].shape, primitive: "cube", bevel: 0.3 } });
const code2 = encodeShareCode(makePresetPackage(tweaked, "shape-cube"));
assert.notEqual(code, code2);
assert.equal(decodeShareCode(code2).presets["shape-cube"].shape.bevel, 0.3);
console.log("PASS tweaks survive the encode/decode round trip");

// Malformed codes are rejected
assert.throws(() => decodeShareCode("nope"), /Not a HeavyMetal/);
assert.throws(() => decodeShareCode("HM2-!!!!"), /malformed/);
assert.throws(() => decodeShareCode("HM2-AAAA"), /decompressed/);
console.log("PASS malformed share codes rejected");
